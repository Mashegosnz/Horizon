/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
    './app/**/*.{js,jsx}',
    './src/**/*.{js,jsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '2rem',
      screens: {
        '2xl': '1400px',
      },
    },
    extend: {
      colors: {
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
        // Tesla/SpaceX Inspired Palette
        'deep-space': {
          DEFAULT: '#0a0e27',
          light: '#151b40',
        },
        'electric-cyan': {
          DEFAULT: '#00d9ff',
          dim: '#008ba3',
        },
        'metallic-silver': {
          DEFAULT: '#e8e8e8',
          dim: '#a0a0a0',
        },
        'deep-purple': {
          DEFAULT: '#1a0033',
          light: '#2d0059',
        },
        'neon-blue': {
          DEFAULT: '#0080ff',
          glow: '#4d9fff',
        },
        'dark-charcoal': {
          DEFAULT: '#1a1a2e',
          light: '#252542',
        },
        // Legacy support (mapped to new palette where appropriate or kept for safety)
        indigo: {
          DEFAULT: '#1a0033', // mapped to deep-purple
          dark: '#0a0e27',   // mapped to deep-space
          light: '#1a1a2e',  // mapped to dark-charcoal
        },
        teal: {
          DEFAULT: '#00d9ff', // mapped to electric-cyan
          dark: '#0080ff',    // mapped to neon-blue
          light: '#4d9fff',
        },
        gold: {
          DEFAULT: '#0080ff', // mapped to neon-blue for consistency
          dark: '#0060bf',
          light: '#e8e8e8',   // mapped to metallic-silver
        },
        charcoal: {
          DEFAULT: '#1a1a2e', // mapped to dark-charcoal
          dark: '#0a0e27',    // mapped to deep-space
        },
        offwhite: {
          DEFAULT: '#e8e8e8', // mapped to metallic-silver
        },
      },
      boxShadow: {
        'neon': '0 0 10px rgba(0, 217, 255, 0.5), 0 0 20px rgba(0, 217, 255, 0.3)',
        'neon-blue': '0 0 10px rgba(0, 128, 255, 0.5), 0 0 20px rgba(0, 128, 255, 0.3)',
        'metallic': '0 4px 6px -1px rgba(232, 232, 232, 0.1), 0 2px 4px -1px rgba(232, 232, 232, 0.06)',
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
      },
      keyframes: {
        'accordion-down': {
          from: { height: 0 },
          to: { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: 0 },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        'pulse-glow': {
          '0%, 100%': { opacity: 1, filter: 'brightness(100%)' },
          '50%': { opacity: 0.8, filter: 'brightness(150%)' },
        },
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'float': 'float 3s ease-in-out infinite',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
};