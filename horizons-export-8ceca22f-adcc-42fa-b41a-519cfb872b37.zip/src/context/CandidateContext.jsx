
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const CandidateContext = createContext();

export const useCandidate = () => useContext(CandidateContext);

const MOCK_JOBS = Array.from({ length: 25 }, (_, i) => ({
  id: `job_${i + 1}`,
  title: ['Senior React Developer', 'UX/UI Designer', 'Data Scientist', 'Marketing Manager', 'Project Manager', 'Frontend Developer', 'Legal Counsel', 'HR Business Partner', 'Financial Analyst', 'DevOps Engineer'][i % 10],
  company: ['TechFlow SA', 'Creative Minds', 'InsightCorp', 'RetailGiant', 'BuildIt', 'WebWiz', 'LawFirm SA', 'PeopleFirst', 'CapitalInvest', 'CloudScale'][i % 10],
  location: ['Cape Town', 'Johannesburg', 'Remote', 'Durban', 'Pretoria'][i % 5],
  type: ['Full-time', 'Contract', 'Hybrid', 'Remote'][i % 4],
  salary: `R${50 + (i * 5)}k - R${70 + (i * 5)}k`,
  posted: new Date(Date.now() - i * 86400000).toISOString().split('T')[0],
  industry: ['Technology', 'Design', 'Data Science', 'Marketing', 'Construction', 'Legal', 'HR', 'Finance'][i % 8],
  description: 'Join our dynamic team to drive innovation and excellence. We offer competitive benefits and a great culture.',
  matchScore: Math.floor(Math.random() * 30) + 70,
  requirements: ['React', 'Node.js', 'Problem Solving', 'Agile', 'Communication'].slice(0, 3 + (i % 2)),
  benefits: ['Medical Aid', 'Remote Work', 'Pension', 'Bonus'].slice(0, 2 + (i % 2)),
  workArrangement: ['Remote', 'Hybrid', 'On-site'][i % 3]
}));

const DEFAULT_CANDIDATE = {
  id: 'cand_demo_1',
  fullName: 'Jane Doe',
  email: 'jane.doe@example.com',
  phone: '082 123 4567',
  location: 'Cape Town',
  title: 'Senior Frontend Engineer',
  completeness: 85,
  skills: ['React', 'JavaScript', 'CSS', 'Tailwind', 'Node.js'],
  experience: [{ title: 'Frontend Dev', company: 'TechCorp', years: '3' }],
  education: [{ degree: 'BSc Computer Science', institution: 'UCT', year: '2020' }]
};

export const CandidateProvider = ({ children }) => {
  const [candidateUser, setCandidateUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const [allJobs, setAllJobs] = useState(MOCK_JOBS);
  const [applications, setApplications] = useState([]);
  const [savedJobs, setSavedJobs] = useState([]);
  const [messages, setMessages] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [assessments, setAssessments] = useState([]);
  const [notifications, setNotifications] = useState([]);

  const { toast } = useToast();

  useEffect(() => {
    // Demo Seeding
    const initData = () => {
      let storedUser = localStorage.getItem('indira_candidate');
      if (!storedUser) {
        localStorage.setItem('indira_candidate', JSON.stringify(DEFAULT_CANDIDATE));
        storedUser = JSON.stringify(DEFAULT_CANDIDATE);
      }
      setCandidateUser(JSON.parse(storedUser));

      setApplications(Array.from({ length: 5 }, (_, i) => ({ id: `app_${i}`, jobId: `job_${i+1}`, jobTitle: MOCK_JOBS[i].title, company: MOCK_JOBS[i].company, status: ['Applied', 'Reviewing', 'Interview', 'Offered', 'Rejected'][i], appliedDate: new Date().toISOString() })));
      setSavedJobs(MOCK_JOBS.slice(5, 13));
      setMessages(Array.from({ length: 3 }, (_, i) => ({ id: `msg_${i}`, sender: MOCK_JOBS[i].company, subject: 'Interview Invitation', preview: 'We would like to invite you...', date: new Date().toISOString(), unread: i === 0 })));
      setInterviews(Array.from({ length: 2 }, (_, i) => ({ id: `int_${i}`, company: MOCK_JOBS[i].company, role: MOCK_JOBS[i].title, date: new Date(Date.now() + 86400000 * (i+1)).toISOString(), type: 'Video Call' })));
      setDocuments(Array.from({ length: 12 }, (_, i) => ({ id: `doc_${i}`, name: `Document_${i+1}.pdf`, type: ['CV', 'Certificate', 'ID', 'Other'][i % 4], uploadDate: new Date().toISOString() })));
      setAssessments(Array.from({ length: 3 }, (_, i) => ({ id: `ass_${i}`, name: ['React Basics', 'Cognitive Ability', 'Culture Fit'][i], score: 85 + (i*5), status: 'Completed', date: new Date().toISOString() })));
      setNotifications(Array.from({ length: 5 }, (_, i) => ({ id: `notif_${i}`, title: 'Application Update', message: `Your application for ${MOCK_JOBS[i].title} was updated.`, read: false, date: new Date().toISOString() })));
      
      setLoading(false);
    };
    initData();
  }, []);

  const login = (email, password) => {
    if (email === 'jane.doe@example.com' || password.length > 0) {
      const user = JSON.parse(localStorage.getItem('indira_candidate')) || DEFAULT_CANDIDATE;
      setCandidateUser(user);
      localStorage.setItem('indira_candidate', JSON.stringify(user));
      return user;
    }
    throw new Error('Invalid credentials');
  };

  const signup = (userData) => {
    const newUser = { id: Date.now().toString(), completeness: 20, ...userData };
    setCandidateUser(newUser);
    localStorage.setItem('indira_candidate', JSON.stringify(newUser));
    return newUser;
  };

  const logout = () => {
    setCandidateUser(null);
    localStorage.removeItem('indira_candidate');
    toast({ title: "Logged Out", description: "Successfully logged out." });
  };

  const updateProfile = (data) => {
    const updated = { ...candidateUser, ...data, completeness: Math.min(100, (candidateUser.completeness || 20) + 20) };
    setCandidateUser(updated);
    localStorage.setItem('indira_candidate', JSON.stringify(updated));
  };

  const applyToJob = (job, appData) => {
    const newApp = { id: Date.now().toString(), jobId: job.id, jobTitle: job.title, company: job.company, status: 'Applied', appliedDate: new Date().toISOString(), ...appData };
    setApplications([newApp, ...applications]);
    toast({ title: "Application Submitted", description: `You have successfully applied to ${job.company}.` });
  };

  const saveJob = (job) => {
    if (savedJobs.find(j => j.id === job.id)) {
      setSavedJobs(savedJobs.filter(j => j.id !== job.id));
      toast({ title: "Removed from Saved", description: "Job removed from your saved list." });
    } else {
      setSavedJobs([...savedJobs, job]);
      toast({ title: "Job Saved", description: "Job added to your saved list." });
    }
  };

  const isJobSaved = (jobId) => savedJobs.some(j => j.id === jobId);

  return (
    <CandidateContext.Provider value={{
      candidateUser, loading, login, signup, logout, updateProfile,
      allJobs, applications, savedJobs, messages, interviews, documents, assessments, notifications,
      applyToJob, saveJob, isJobSaved
    }}>
      {children}
    </CandidateContext.Provider>
  );
};
