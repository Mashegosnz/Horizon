
import React, { createContext, useContext, useState } from 'react';

const EmployerDataContext = createContext();

export const useEmployerData = () => useContext(EmployerDataContext);

const seedPackages = [
  { id: 'starter', name: 'Indira Starter', monthlyPrice: 497, yearlyPrice: 4797, employees: 50, adminSeats: 1, features: ['Core HR Admin', 'Basic Compliance', 'Standard Support'] },
  { id: 'growth', name: 'Indira Growth', monthlyPrice: 987, yearlyPrice: 9987, employees: 200, adminSeats: 5, features: ['Performance Management', 'B-BBEE Tracking', 'Priority Support'] },
  { id: 'enterprise', name: 'Indira Enterprise', monthlyPrice: 1987, yearlyPrice: 19987, employees: 'Unlimited', adminSeats: 'Unlimited', features: ['Succession Planning', 'Predictive Risk', 'Dedicated Account Manager'] }
];

const seedEmployers = [
  { employer_id: 'emp_1', user_id: 'user_1', purchase_id: 'purch_1', package_id: 'growth', company_name: 'TechCorp Solutions', industry: 'Technology', company_size: '201-500', employee_count: 350, locations_count: 3, primary_location: 'Johannesburg', payroll_system: 'Sage', status: 'complete' }
];

const seedJobs = [
  { job_id: 'job_1', employer_id: 'emp_1', title: 'Senior Developer', location: 'Remote', salary_range: 'R80k - R120k', description: 'Full stack developer needed.', requirements: '5+ years React', status: 'Active', created_at: '2026-03-01' },
  { job_id: 'job_2', employer_id: 'emp_1', title: 'HR Manager', location: 'Cape Town', salary_range: 'R60k - R90k', description: 'Experienced HR professional.', requirements: 'SABPP registered', status: 'Active', created_at: '2026-03-02' },
  { job_id: 'job_3', employer_id: 'emp_1', title: 'Sales Representative', location: 'Durban', salary_range: 'R30k + Comm', description: 'B2B sales.', requirements: '2+ years sales', status: 'Active', created_at: '2026-03-05' }
];

const seedCandidates = Array.from({ length: 12 }, (_, i) => ({
  candidate_id: `cand_${i}`, job_id: `job_${(i % 3) + 1}`, employer_id: 'emp_1', name: `Candidate ${i+1}`, email: `cand${i}@example.com`, phone: '0821234567', stage: ['Applied', 'Shortlisted', 'Interview', 'Offer'][i % 4], resume_url: '#', created_at: `2026-03-0${(i%9)+1}`
}));

const seedInterviews = [
  { interview_id: 'int_1', candidate_id: 'cand_2', employer_id: 'emp_1', scheduled_date: '2026-03-10T10:00:00Z', interviewer_name: 'John Smith', status: 'Scheduled', notes: 'First round', created_at: '2026-03-08' },
  { interview_id: 'int_2', candidate_id: 'cand_6', employer_id: 'emp_1', scheduled_date: '2026-03-11T14:00:00Z', interviewer_name: 'Sarah Lee', status: 'Scheduled', notes: 'Technical', created_at: '2026-03-08' },
  { interview_id: 'int_3', candidate_id: 'cand_10', employer_id: 'emp_1', scheduled_date: '2026-03-12T09:00:00Z', interviewer_name: 'Mike Johnson', status: 'Completed', notes: 'Good fit', created_at: '2026-03-08' },
  { interview_id: 'int_4', candidate_id: 'cand_3', employer_id: 'emp_1', scheduled_date: '2026-03-13T11:00:00Z', interviewer_name: 'John Smith', status: 'Scheduled', notes: '', created_at: '2026-03-09' },
  { interview_id: 'int_5', candidate_id: 'cand_7', employer_id: 'emp_1', scheduled_date: '2026-03-14T15:00:00Z', interviewer_name: 'Sarah Lee', status: 'Scheduled', notes: '', created_at: '2026-03-09' }
];

const seedDocuments = Array.from({ length: 45 }, (_, i) => ({
  document_id: `doc_${i}`, employer_id: 'emp_1', name: `HR_Document_${i}.pdf`, type: ['Contracts', 'Policies', 'Compliance', 'Other'][i % 4], file_url: '#', created_at: '2026-02-15'
}));

const seedTemplates = [
  { template_id: 'tpl_1', employer_id: 'emp_1', name: 'Standard Employment Contract', content: '...', created_at: '2026-01-10' },
  { template_id: 'tpl_2', employer_id: 'emp_1', name: 'Executive Offer Letter', content: '...', created_at: '2026-01-15' },
  { template_id: 'tpl_3', employer_id: 'emp_1', name: 'Contractor Agreement', content: '...', created_at: '2026-01-20' }
];

const seedNotifications = [
  { notification_id: 'notif_1', employer_id: 'emp_1', message: 'New candidate applied for Senior Developer', type: 'hiring', created_at: '2026-03-09T08:00:00Z' },
  { notification_id: 'notif_2', employer_id: 'emp_1', message: 'Compliance risk alert: EE Report due in 30 days', type: 'compliance', created_at: '2026-03-08T09:00:00Z' },
  { notification_id: 'notif_3', employer_id: 'emp_1', message: 'Leave request pending approval', type: 'admin', created_at: '2026-03-08T14:00:00Z' }
];

const seedOnboarding = [
  { checklist_id: 'chk_1', employee_name: 'Alice Cooper', tasks: [{ name: 'IT Setup', done: true }, { name: 'Welcome Lunch', done: false }], completion: 50 },
  { checklist_id: 'chk_2', employee_name: 'Bob Martin', tasks: [{ name: 'Contract Signed', done: true }, { name: 'Payroll Setup', done: true }], completion: 100 }
];

const seedPerformance = [
  { cycle_id: 'cyc_1', employer_id: 'emp_1', name: 'Q1 2026 Review', status: 'Active', created_at: '2026-02-01' }
];

const seedTraining = [
  { recommendation_id: 'trn_1', employer_id: 'emp_1', title: 'Leadership Masterclass', description: 'For mid-level managers', created_at: '2026-03-01' },
  { recommendation_id: 'trn_2', employer_id: 'emp_1', title: 'POPIA Compliance 101', description: 'Required for all staff', created_at: '2026-03-02' },
  { recommendation_id: 'trn_3', employer_id: 'emp_1', title: 'Advanced React', description: 'Tech team upskilling', created_at: '2026-03-03' },
  { recommendation_id: 'trn_4', employer_id: 'emp_1', title: 'Conflict Resolution', description: 'HR Team', created_at: '2026-03-04' },
  { recommendation_id: 'trn_5', employer_id: 'emp_1', title: 'Sales Negotiation', description: 'Sales Team', created_at: '2026-03-05' }
];

const seedBbbee = { scorecard_id: 'bee_1', employer_id: 'emp_1', current_level: 'Level 3', score: 65, created_at: '2026-01-01' };

const seedSuccession = [
  { role_id: 'role_1', employer_id: 'emp_1', title: 'CEO', successor_name: 'Jane Doe', status: 'Ready in 1-2 years', created_at: '2026-01-15' },
  { role_id: 'role_2', employer_id: 'emp_1', title: 'CTO', successor_name: 'Mark Tech', status: 'Ready now', created_at: '2026-01-15' },
  { role_id: 'role_3', employer_id: 'emp_1', title: 'Sales Director', successor_name: 'Sarah Sell', status: 'Needs training', created_at: '2026-01-15' },
  { role_id: 'role_4', employer_id: 'emp_1', title: 'HR Director', successor_name: 'Pending', status: 'At risk', created_at: '2026-01-15' },
  { role_id: 'role_5', employer_id: 'emp_1', title: 'CFO', successor_name: 'John Finance', status: 'Ready in 3-5 years', created_at: '2026-01-15' }
];

const seedRisk = [
  { alert_id: 'risk_1', employer_id: 'emp_1', title: 'High Turnover Risk in Sales', severity: 'High', created_at: '2026-03-01' },
  { alert_id: 'risk_2', employer_id: 'emp_1', title: 'Upcoming BCEA Audit', severity: 'Medium', created_at: '2026-03-05' }
];

export const EmployerDataProvider = ({ children }) => {
  const [data, setData] = useState({
    packages: seedPackages,
    employers: seedEmployers,
    jobs: seedJobs,
    candidates: seedCandidates,
    interviews: seedInterviews,
    documents: seedDocuments,
    templates: seedTemplates,
    notifications: seedNotifications,
    onboarding: seedOnboarding,
    performance_cycles: seedPerformance,
    training_recommendations: seedTraining,
    bbbee_scorecard: seedBbbee,
    succession_roles: seedSuccession,
    risk_alerts: seedRisk,
    purchases: [] // Will be populated dynamically
  });

  const addPurchase = (purchase) => {
    setData(prev => ({ ...prev, purchases: [...prev.purchases, purchase] }));
  };

  const addEmployerProfile = (profile) => {
    setData(prev => ({ ...prev, employers: [...prev.employers, profile] }));
  };

  const updateEmployerProfile = (id, updates) => {
      setData(prev => ({
          ...prev, 
          employers: prev.employers.map(e => e.employer_id === id ? { ...e, ...updates } : e)
      }));
  }

  return (
    <EmployerDataContext.Provider value={{ data, addPurchase, addEmployerProfile, updateEmployerProfile }}>
      {children}
    </EmployerDataContext.Provider>
  );
};
