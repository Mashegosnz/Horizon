import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const EmployerContext = createContext();

export const useEmployer = () => useContext(EmployerContext);

export const PLANS = {
  Starter: {
    id: 'Starter',
    name: 'Indira Assistant',
    jobs: 5,
    candidates: 50,
    seats: 1,
    monthlyPrice: 497,
    yearlyPrice: 4797,
    features: ['recruitment', 'contracts', 'payroll_leave', 'compliance_basic'],
    description: 'Autonomous recruiting coordinator & basic compliance.'
  },
  Growth: {
    id: 'Growth',
    name: 'Indira Partner',
    jobs: 20,
    candidates: 200,
    seats: 5,
    monthlyPrice: 987,
    yearlyPrice: 9987,
    features: [
      'recruitment', 'contracts', 'payroll_leave', 'compliance_basic',
      'performance', 'learning', 'compliance_advanced', 'analytics_advanced',
      'bbbee'
    ],
    description: 'Full-suite HR partner managing ops, payroll & EE.'
  },
  Enterprise: {
    id: 'Enterprise',
    name: 'Indira Enterprise',
    jobs: 9999,
    candidates: 9999,
    seats: 9999,
    monthlyPrice: 1987,
    yearlyPrice: 19987,
    features: [
      'recruitment', 'contracts', 'payroll_leave', 'compliance_basic',
      'performance', 'learning', 'compliance_advanced', 'analytics_advanced',
      'bbbee', 'succession', 'risk', 'analytics_full'
    ],
    description: 'Deep organizational intelligence & strategic automation.'
  },
};

export const getPlanSavings = (planKey) => {
  const plan = PLANS[planKey];
  if (!plan) return null;
  const annualCostMonthly = plan.monthlyPrice * 12;
  const savings = annualCostMonthly - plan.yearlyPrice;
  return {
    amount: savings,
    monthsFree: Math.round(savings / plan.monthlyPrice)
  };
};

export const EmployerProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // New State for Full Features
  const [employees, setEmployees] = useState([]);
  const [integrations, setIntegrations] = useState({});
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [onboardingTasks, setOnboardingTasks] = useState([]);

  // Payment State
  const [paymentHistory, setPaymentHistory] = useState([]);

  const { toast } = useToast();

  useEffect(() => {
    // Load User
    const storedUser = localStorage.getItem('indira_current_employer');
    if (storedUser) setUser(JSON.parse(storedUser));
    
    // Load Data
    setJobs(JSON.parse(localStorage.getItem('indira_jobs') || '[]'));
    setEmployees(JSON.parse(localStorage.getItem('indira_employees') || '[]'));
    setIntegrations(JSON.parse(localStorage.getItem('indira_integrations') || '{}'));
    setLeaveRequests(JSON.parse(localStorage.getItem('indira_leave') || '[]'));
    setAttendance(JSON.parse(localStorage.getItem('indira_attendance') || '[]'));
    setContracts(JSON.parse(localStorage.getItem('indira_contracts') || '[]'));
    setPaymentHistory(JSON.parse(localStorage.getItem('indira_payments') || '[]'));
    
    setLoading(false);
  }, []);

  // Save changes helper
  const save = (key, data, setter) => {
      setter(data);
      localStorage.setItem(key, JSON.stringify(data));
  };

  const signup = (userData) => {
    const users = JSON.parse(localStorage.getItem('indira_employers_db') || '[]');
    if (users.find(u => u.email === userData.email)) {
      throw new Error('Email already exists');
    }

    const billingPeriod = userData.billingPeriod || 'monthly';
    const planKey = userData.plan || 'Starter';
    const plan = PLANS[planKey];
    
    const newUser = {
      id: Date.now().toString(),
      ...userData,
      plan: planKey,
      billingPeriod,
      subscriptionAmount: billingPeriod === 'yearly' ? plan.yearlyPrice : plan.monthlyPrice,
      nextBillingDate: new Date(Date.now() + (billingPeriod === 'yearly' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString(),
      joinedDate: new Date().toISOString(),
      setupComplete: false,
      billingStatus: 'Trial', // Default to trial
      paymentMethod: null,
      lastPaymentDate: null,
      lastPaymentAmount: 0
    };

    users.push(newUser);
    localStorage.setItem('indira_employers_db', JSON.stringify(users));
    
    setUser(newUser);
    localStorage.setItem('indira_current_employer', JSON.stringify(newUser));
    return newUser;
  };

  const login = (email, password) => {
    const users = JSON.parse(localStorage.getItem('indira_employers_db') || '[]');
    const foundUser = users.find(u => u.email === email && u.password === password);

    if (!foundUser) throw new Error('Invalid credentials');

    setUser(foundUser);
    localStorage.setItem('indira_current_employer', JSON.stringify(foundUser));
    return foundUser;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('indira_current_employer');
    toast({ title: "Logged Out", description: "Successfully logged out." });
  };

  const completeSetup = (setupData) => {
      if (!user) return;
      const updatedUser = { ...user, ...setupData, setupComplete: true };
      setUser(updatedUser);
      localStorage.setItem('indira_current_employer', JSON.stringify(updatedUser));
      
      // Update in DB
      const users = JSON.parse(localStorage.getItem('indira_employers_db') || '[]');
      const idx = users.findIndex(u => u.id === user.id);
      if (idx !== -1) {
          users[idx] = updatedUser;
          localStorage.setItem('indira_employers_db', JSON.stringify(users));
      }
  };

  const postJob = (jobData) => {
    if (!user) return;
    const newJob = {
      id: Date.now().toString(),
      employerId: user.id,
      status: 'Active',
      postedDate: new Date().toISOString(),
      applicants: 0,
      pipeline: { applied: [], shortlisted: [], interview: [], offer: [], hired: [] },
      ...jobData
    };
    const updated = [...jobs, newJob];
    save('indira_jobs', updated, setJobs);
    toast({ title: "Job Posted!", description: "Role is now live." });
    return newJob;
  };
  
  const updateIntegration = (key, status) => {
      const updated = { ...integrations, [key]: { status, lastSync: new Date().toISOString() } };
      save('indira_integrations', updated, setIntegrations);
  };

  const addEmployee = (empData) => {
      const newEmp = { id: Date.now().toString(), employerId: user.id, ...empData };
      const updated = [...employees, newEmp];
      save('indira_employees', updated, setEmployees);
      return newEmp;
  };

  const isFeatureAvailable = (featureKey) => {
    if (!user) return false;
    const plan = PLANS[user.plan];
    if (!plan) return false;
    if (featureKey === 'basic') return true;
    return plan.features.includes(featureKey);
  };

  // Payment Functions
  const updatePaymentMethod = (method) => {
    if (!user) return;
    const updatedUser = { ...user, paymentMethod: method };
    setUser(updatedUser);
    localStorage.setItem('indira_current_employer', JSON.stringify(updatedUser));
    
    // Update DB
    const users = JSON.parse(localStorage.getItem('indira_employers_db') || '[]');
    const idx = users.findIndex(u => u.id === user.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
      localStorage.setItem('indira_employers_db', JSON.stringify(users));
    }
    toast({ title: "Success", description: "Payment method updated." });
  };

  const recordPayment = (amount, method, transactionId) => {
    if (!user) return;
    const date = new Date().toISOString();
    
    // Create transaction record
    const transaction = {
      id: transactionId || `txn_${Date.now()}`,
      employerId: user.id,
      date,
      amount,
      method,
      plan: user.plan,
      billingPeriod: user.billingPeriod,
      status: 'Completed'
    };
    
    const newHistory = [transaction, ...paymentHistory];
    setPaymentHistory(newHistory);
    localStorage.setItem('indira_payments', JSON.stringify(newHistory));

    // Update user billing status
    const updatedUser = {
      ...user,
      billingStatus: 'Active',
      lastPaymentDate: date,
      lastPaymentAmount: amount,
      paymentMethod: method,
      nextBillingDate: new Date(Date.now() + (user.billingPeriod === 'yearly' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString()
    };
    
    setUser(updatedUser);
    localStorage.setItem('indira_current_employer', JSON.stringify(updatedUser));
    
    // Update DB
    const users = JSON.parse(localStorage.getItem('indira_employers_db') || '[]');
    const idx = users.findIndex(u => u.id === user.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
      localStorage.setItem('indira_employers_db', JSON.stringify(users));
    }

    return transaction;
  };

  const changePlan = (newPlanKey, newBillingPeriod) => {
    if (!user) return;
    const plan = PLANS[newPlanKey];
    
    const updatedUser = {
      ...user,
      plan: newPlanKey,
      billingPeriod: newBillingPeriod,
      subscriptionAmount: newBillingPeriod === 'yearly' ? plan.yearlyPrice : plan.monthlyPrice,
    };
    
    setUser(updatedUser);
    localStorage.setItem('indira_current_employer', JSON.stringify(updatedUser));
    
    // Update DB
    const users = JSON.parse(localStorage.getItem('indira_employers_db') || '[]');
    const idx = users.findIndex(u => u.id === user.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
      localStorage.setItem('indira_employers_db', JSON.stringify(users));
    }
  };

  const cancelPlan = () => {
    if (!user) return;
    const updatedUser = {
      ...user,
      billingStatus: 'Cancelled',
      nextBillingDate: null
    };
    
    setUser(updatedUser);
    localStorage.setItem('indira_current_employer', JSON.stringify(updatedUser));
    
    // Update DB
    const users = JSON.parse(localStorage.getItem('indira_employers_db') || '[]');
    const idx = users.findIndex(u => u.id === user.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
      localStorage.setItem('indira_employers_db', JSON.stringify(users));
    }
    toast({ title: "Plan Cancelled", description: "Your subscription has been cancelled." });
  };

  return (
    <EmployerContext.Provider value={{ 
      user, loading, signup, login, logout, completeSetup,
      postJob, jobs, employees, addEmployee,
      integrations, updateIntegration,
      leaveRequests, attendance, contracts, onboardingTasks,
      paymentHistory, updatePaymentMethod, recordPayment, changePlan, cancelPlan,
      currentPlanLimits: user ? PLANS[user.plan] : PLANS['Starter'],
      allPlans: PLANS,
      isFeatureAvailable
    }}>
      {children}
    </EmployerContext.Provider>
  );
};