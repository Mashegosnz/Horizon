import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Slider } from '@/components/ui/slider';
import { Check } from 'lucide-react';

const PricingCalculator = () => {
  const [employees, setEmployees] = useState(50);

  const pricingTiers = [
    {
      name: 'Assistant',
      basePrice: 2500,
      perEmployee: 25,
      maxEmployees: 100,
      features: [
        'AI Recruitment Basics',
        'Compliance Monitoring',
        'Email Support',
        'Basic Analytics'
      ]
    },
    {
      name: 'Partner',
      basePrice: 5000,
      perEmployee: 20,
      maxEmployees: 1000,
      features: [
        'Everything in Assistant',
        'Advanced AI Recruitment',
        'Full Compliance Suite',
        'Performance Management',
        'Payroll Integration',
        'Priority Support',
        'Advanced Analytics'
      ],
      recommended: true
    },
    {
      name: 'Enterprise',
      basePrice: 12000,
      perEmployee: 15,
      maxEmployees: 5000,
      features: [
        'Everything in Partner',
        'Custom AI Training',
        'Dedicated Account Manager',
        'Custom Integrations',
        'White-label Options',
        'SLA Guarantees',
        'On-premise Deployment'
      ]
    }
  ];

  const calculatePrice = (tier) => {
    const cappedEmployees = Math.min(employees, tier.maxEmployees);
    return tier.basePrice + (cappedEmployees * tier.perEmployee);
  };

  return (
    <section className="py-24 bg-dark-charcoal relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-1/4 w-[800px] h-[800px] bg-deep-purple/20 rounded-full blur-[120px]" />
      <div className="absolute bottom-0 right-1/4 w-[800px] h-[800px] bg-electric-cyan/5 rounded-full blur-[120px]" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="text-metallic-silver">Calculate Your </span>
            <span className="gradient-text">Investment</span>
          </h2>
          <p className="text-xl text-metallic-silver/70 max-w-3xl mx-auto">
            Transparent pricing for autonomous HR that scales with your business velocity.
          </p>
        </motion.div>

        {/* Company Size Slider */}
        <motion.div
          className="max-w-3xl mx-auto mb-20 bg-deep-space/60 backdrop-blur-xl border border-white/10 rounded-3xl p-10 shadow-2xl"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center mb-10">
            <label className="text-lg font-semibold text-metallic-silver block mb-3 uppercase tracking-wider">
              Company Size
            </label>
            <div className="text-6xl font-bold text-electric-cyan mb-2 drop-shadow-lg font-mono">
              {employees}
            </div>
            <div className="text-metallic-silver/60">employees</div>
          </div>
          
          <Slider
            value={[employees]}
            onValueChange={(value) => setEmployees(value[0])}
            min={10}
            max={5000}
            step={10}
            className="w-full mb-4"
          />
          
          <div className="flex justify-between text-sm text-metallic-silver/40 font-mono">
            <span>10</span>
            <span>5000</span>
          </div>
        </motion.div>

        {/* Pricing Comparison Table */}
        <motion.div
          className="overflow-x-auto rounded-2xl border border-white/5"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="min-w-[900px]">
            <div className="grid grid-cols-4 bg-deep-space">
              {/* Header */}
              <div className="col-span-1 p-8 border-r border-white/5">
                <div className="h-full flex items-end">
                  <h3 className="text-lg font-bold text-metallic-silver uppercase tracking-wider">Features</h3>
                </div>
              </div>

              {/* Tier Headers */}
              {pricingTiers.map((tier, index) => (
                <motion.div
                  key={index}
                  className={`col-span-1 p-8 border-r border-white/5 last:border-r-0 relative overflow-hidden ${
                    tier.recommended ? 'bg-deep-space/80' : 'bg-deep-space'
                  }`}
                  whileHover={{ backgroundColor: 'rgba(0, 217, 255, 0.05)' }}
                >
                  {tier.recommended && (
                    <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-electric-cyan to-neon-blue" />
                  )}
                  {tier.recommended && (
                     <div className="absolute top-4 right-4 text-[10px] font-bold text-deep-space bg-electric-cyan px-2 py-0.5 rounded-full uppercase tracking-widest">
                       Recommended
                     </div>
                  )}
                  <h3 className="text-2xl font-bold text-metallic-silver mb-2">{tier.name}</h3>
                  <div className="mb-4">
                    <div className="text-3xl font-bold text-electric-cyan">
                      R{calculatePrice(tier).toLocaleString()}
                    </div>
                    <div className="text-sm text-metallic-silver/60">/month</div>
                  </div>
                  <div className="text-xs text-metallic-silver/50 space-y-1 font-mono">
                    <div>Base: R{tier.basePrice.toLocaleString()}</div>
                    <div>+ R{tier.perEmployee}/emp</div>
                    <div>Max: {tier.maxEmployees}</div>
                  </div>
                </motion.div>
              ))}

              {/* Feature Rows */}
              {Array.from({ length: Math.max(...pricingTiers.map(t => t.features.length)) }).map((_, featureIndex) => (
                <React.Fragment key={featureIndex}>
                  <div className="col-span-1 p-5 border-t border-r border-white/5 bg-dark-charcoal/30 flex items-center">
                    <span className="text-metallic-silver/80 text-sm font-medium">
                      {pricingTiers.find(t => t.features[featureIndex])?.features[featureIndex] || ''}
                    </span>
                  </div>
                  
                  {pricingTiers.map((tier, tierIndex) => (
                    <div
                      key={tierIndex}
                      className={`col-span-1 p-5 border-t border-r border-white/5 last:border-r-0 flex items-center justify-center ${
                        tier.recommended ? 'bg-electric-cyan/5' : 'bg-dark-charcoal/30'
                      }`}
                    >
                      {tier.features[featureIndex] && (
                        <Check className="h-5 w-5 text-electric-cyan drop-shadow-[0_0_5px_rgba(0,217,255,0.5)]" />
                      )}
                    </div>
                  ))}
                </React.Fragment>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default PricingCalculator;