import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, Clock, FileText, Users, CheckCircle, Zap, Shield } from 'lucide-react';

const ProblemSolution = () => {
  const problems = [
    {
      icon: Clock,
      title: 'Recruitment Delays',
      description: 'Weeks spent screening CVs and scheduling interviews, slowing down hiring velocity.'
    },
    {
      icon: FileText,
      title: 'Compliance Complexity',
      description: 'Navigating BBBEE, employment equity, and labour law requirements manually.'
    },
    {
      icon: Users,
      title: 'Talent Retention',
      description: 'High turnover due to lack of engagement insights and performance tracking.'
    }
  ];

  const solutions = [
    {
      icon: Zap,
      title: 'AI-Powered Automation',
      description: 'Automated CV screening, interview scheduling, and candidate ranking in minutes, part of autonomous HR.',
    },
    {
      icon: Shield,
      title: 'Built-in Compliance',
      description: 'Automatic adherence to SA labour laws, BBBEE scoring, and equity reporting for autonomous HR.',
    },
    {
      icon: CheckCircle,
      title: 'Smart Retention',
      description: 'Real-time analytics, performance insights, and engagement predictions driven by autonomous HR.',
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: 'easeOut'
      }
    }
  };

  return (
    <section className="py-24 bg-dark-charcoal relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-electric-cyan/5 rounded-full blur-[100px]" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-deep-purple/20 rounded-full blur-[100px]" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">
            <span className="text-metallic-silver">From </span>
            <span className="gradient-text">Friction</span>
            <span className="text-metallic-silver"> to </span>
            <span className="gradient-text">Flow</span>
          </h2>
          <p className="text-xl text-metallic-silver/70 max-w-2xl mx-auto">
            See how Indira transforms common HR pain points into streamlined, automated processes with autonomous HR.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 lg:gap-24 max-w-7xl mx-auto">
          {/* Problems Column */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-4 mb-10">
              <div className="p-3 rounded-full bg-red-500/10 border border-red-500/20">
                <AlertCircle className="h-6 w-6 text-red-400" />
              </div>
              <h3 className="text-2xl font-bold text-metallic-silver">HR Challenges</h3>
            </div>
            <div className="space-y-6">
              {problems.map((problem, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  className="bg-deep-space/50 rounded-2xl p-6 shadow-lg border border-red-500/10 hover:border-red-500/40 transition-all duration-300 hover:shadow-[0_0_20px_rgba(248,113,113,0.1)] hover:-translate-y-1 backdrop-blur-sm"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center flex-shrink-0 border border-red-500/20">
                      <problem.icon className="h-6 w-6 text-red-400" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold text-metallic-silver mb-2">
                        {problem.title}
                      </h4>
                      <p className="text-metallic-silver/60">
                        {problem.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Solutions Column */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-4 mb-10">
              <div className="p-3 rounded-full bg-electric-cyan/10 border border-electric-cyan/20">
                <CheckCircle className="h-6 w-6 text-electric-cyan" />
              </div>
              <h3 className="text-2xl font-bold text-metallic-silver">Indira's Solutions (Autonomous HR)</h3>
            </div>
            <div className="space-y-6">
              {solutions.map((solution, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  className="bg-gradient-to-r from-deep-purple/30 to-deep-space/30 rounded-2xl p-6 shadow-lg border border-electric-cyan/20 hover:border-electric-cyan/60 transition-all duration-300 hover:shadow-neon hover:-translate-y-1 backdrop-blur-sm"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-electric-cyan/10 flex items-center justify-center flex-shrink-0 border border-electric-cyan/20">
                      <solution.icon className="h-6 w-6 text-electric-cyan" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold text-metallic-silver mb-2">
                        {solution.title}
                      </h4>
                      <p className="text-metallic-silver/60">
                        {solution.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSolution;