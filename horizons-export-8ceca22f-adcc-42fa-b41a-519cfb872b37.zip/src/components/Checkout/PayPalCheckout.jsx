import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useEmployer } from '@/context/EmployerContext';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';

const PayPalCheckout = ({ amount, planId, billingPeriod, employerDetails }) => {
  const [processing, setProcessing] = useState(false);
  const { recordPayment } = useEmployer();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handlePayment = () => {
    setProcessing(true);
    
    // Simulate PayPal processing delay
    setTimeout(() => {
      // Simulate success probability
      const success = true; 

      if (success) {
        const txnId = `PAYPAL_${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
        recordPayment(amount, 'PayPal', txnId);
        toast({ title: "Payment Successful", description: "Your transaction was completed via PayPal." });
        navigate(`/checkout-success?gateway=paypal&transaction_id=${txnId}&amount=${amount}&plan=${planId}`);
      } else {
        navigate('/checkout-error?message=PayPal transaction declined');
      }
      setProcessing(false);
    }, 2000);
  };

  return (
    <div className="text-center p-6 bg-white/5 rounded-xl border border-white/10">
      <h3 className="text-lg font-bold mb-4 text-white">Pay with PayPal</h3>
      <p className="text-slate-400 mb-6 text-sm">
        You will be redirected to PayPal securely to complete your payment of <strong>R{amount}</strong>.
      </p>
      
      <Button 
        onClick={handlePayment} 
        disabled={processing}
        className="w-full bg-[#003087] hover:bg-[#003087]/90 text-white font-bold h-12"
      >
        {processing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
          </>
        ) : (
          'Proceed to PayPal'
        )}
      </Button>
      <div className="mt-4 flex justify-center gap-2 opacity-50">
         <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="Visa" className="h-6" />
      </div>
    </div>
  );
};

export default PayPalCheckout;