import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useEmployer } from '@/context/EmployerContext';
import { useNavigate } from 'react-router-dom';
import { Loader2, Lock } from 'lucide-react';

const PayFastCheckout = ({ amount, planId, billingPeriod, employerDetails }) => {
  const [processing, setProcessing] = useState(false);
  const { recordPayment } = useEmployer();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handlePayment = () => {
    setProcessing(true);
    
    // Simulate PayFast redirect and webhook processing
    setTimeout(() => {
      const txnId = `PF_${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      recordPayment(amount, 'PayFast', txnId);
      toast({ title: "Payment Successful", description: "Your transaction was completed via PayFast." });
      navigate(`/checkout-success?gateway=payfast&m_payment_id=${txnId}&amount=${amount}&plan=${planId}`);
      setProcessing(false);
    }, 2500);
  };

  return (
    <div className="text-center p-6 bg-white/5 rounded-xl border border-white/10">
      <h3 className="text-lg font-bold mb-4 text-white">Pay with PayFast</h3>
      <p className="text-slate-400 mb-6 text-sm">
        Secure South African payment gateway supporting Cards, EFT, and more. Total: <strong>R{amount}</strong>.
      </p>
      
      <Button 
        onClick={handlePayment} 
        disabled={processing}
        className="w-full bg-[#bf0711] hover:bg-[#bf0711]/90 text-white font-bold h-12"
      >
        {processing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Redirecting...
          </>
        ) : (
          <>
            <Lock className="mr-2 h-4 w-4" /> Pay with PayFast
          </>
        )}
      </Button>
       <div className="mt-4 flex justify-center gap-2 opacity-50 grayscale hover:grayscale-0 transition-all">
         <div className="text-xs text-slate-500">Secured by PayFast</div>
      </div>
    </div>
  );
};

export default PayFastCheckout;