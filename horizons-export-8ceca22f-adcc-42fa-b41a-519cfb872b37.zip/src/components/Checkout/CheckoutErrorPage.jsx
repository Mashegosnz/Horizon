import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AlertCircle, RefreshCw } from 'lucide-react';
import Navigation from '@/components/Navigation';

const CheckoutErrorPage = () => {
  const [searchParams] = useSearchParams();
  const message = searchParams.get('message') || 'Payment processing failed.';

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans flex flex-col">
       <Navigation />
       <div className="flex-grow flex items-center justify-center p-6 pt-24">
           <div className="max-w-lg w-full bg-slate-900 border border-white/10 rounded-2xl p-8 text-center shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 to-orange-500" />
               
               <div className="w-24 h-24 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-red-500">
                   <AlertCircle className="w-12 h-12" />
               </div>

               <h1 className="text-3xl font-bold mb-2 text-white">Payment Failed</h1>
               <p className="text-slate-400 mb-8">
                   {message} Please check your payment details or try a different method.
               </p>

               <div className="flex flex-col gap-3">
                   <Link to="/checkout">
                       <Button className="w-full h-12 bg-white text-slate-950 font-bold hover:bg-slate-200">
                           <RefreshCw className="mr-2 w-4 h-4" /> Try Again
                       </Button>
                   </Link>
                   <Link to="/contact">
                       <Button variant="ghost" className="text-slate-400 hover:text-white">
                           Contact Support
                       </Button>
                   </Link>
               </div>
           </div>
       </div>
    </div>
  );
};

export default CheckoutErrorPage;