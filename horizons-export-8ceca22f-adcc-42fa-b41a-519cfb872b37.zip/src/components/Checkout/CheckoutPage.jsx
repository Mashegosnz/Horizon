import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { useEmployer, PLANS } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import Navigation from '@/components/Navigation';
import { ShieldCheck, ArrowRight, CreditCard, CheckCircle } from 'lucide-react';
import PayPalCheckout from './PayPalCheckout';
import PayFastCheckout from './PayFastCheckout';

const CheckoutPage = () => {
  const [searchParams] = useSearchParams();
  const planId = searchParams.get('plan') || 'Starter';
  const billingPeriod = searchParams.get('period') || 'monthly';
  
  const { user } = useEmployer();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [gateway, setGateway] = useState('payfast');
  const [config, setConfig] = useState({ paypalEnabled: true, payfastEnabled: true });
  const [employerDetails, setEmployerDetails] = useState({
    companyName: user?.companyName || '',
    email: user?.email || '',
    phone: '',
    fullName: user?.fullName || ''
  });

  useEffect(() => {
    const savedConfig = localStorage.getItem('indira_admin_billing_config');
    if (savedConfig) {
      const parsed = JSON.parse(savedConfig);
      setConfig(parsed);
      setGateway(parsed.defaultGateway || 'payfast');
    }
  }, []);

  const plan = PLANS[planId] || PLANS['Starter'];
  const price = billingPeriod === 'yearly' ? plan.yearlyPrice : plan.monthlyPrice;
  
  // Simple form validation logic
  const isFormValid = user || (employerDetails.companyName && employerDetails.email && employerDetails.fullName);

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans flex flex-col">
      <Navigation />
      
      <div className="flex-grow pt-24 pb-12 container mx-auto px-6">
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Left Column: Plan & Form */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">Checkout</h1>
              <p className="text-slate-400">Complete your subscription to activate autonomous HR.</p>
            </div>

            {/* User Details Form (if not logged in) */}
            {!user && (
              <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4">Your Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <input 
                      placeholder="Company Name" 
                      className="bg-slate-950 border border-white/10 rounded p-3 text-white"
                      value={employerDetails.companyName}
                      onChange={e => setEmployerDetails({...employerDetails, companyName: e.target.value})}
                   />
                   <input 
                      placeholder="Full Name" 
                      className="bg-slate-950 border border-white/10 rounded p-3 text-white"
                      value={employerDetails.fullName}
                      onChange={e => setEmployerDetails({...employerDetails, fullName: e.target.value})}
                   />
                   <input 
                      placeholder="Email Address" 
                      type="email"
                      className="bg-slate-950 border border-white/10 rounded p-3 text-white"
                      value={employerDetails.email}
                      onChange={e => setEmployerDetails({...employerDetails, email: e.target.value})}
                   />
                   <input 
                      placeholder="Phone Number" 
                      className="bg-slate-950 border border-white/10 rounded p-3 text-white"
                      value={employerDetails.phone}
                      onChange={e => setEmployerDetails({...employerDetails, phone: e.target.value})}
                   />
                </div>
              </div>
            )}

            {/* Payment Method Selection */}
            <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <h3 className="text-xl font-bold mb-4">Select Payment Method</h3>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {config.payfastEnabled && (
                    <div 
                      onClick={() => setGateway('payfast')}
                      className={`cursor-pointer border rounded-xl p-4 flex items-center gap-4 transition-all ${gateway === 'payfast' ? 'border-[#00D9FF] bg-[#00D9FF]/5' : 'border-white/10 hover:border-white/30'}`}
                    >
                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${gateway === 'payfast' ? 'border-[#00D9FF]' : 'border-slate-500'}`}>
                            {gateway === 'payfast' && <div className="w-2.5 h-2.5 rounded-full bg-[#00D9FF]" />}
                        </div>
                        <div>
                            <div className="font-bold">PayFast</div>
                            <div className="text-xs text-slate-400">Cards, Instant EFT, SnapScan</div>
                        </div>
                    </div>
                  )}

                  {config.paypalEnabled && (
                    <div 
                      onClick={() => setGateway('paypal')}
                      className={`cursor-pointer border rounded-xl p-4 flex items-center gap-4 transition-all ${gateway === 'paypal' ? 'border-[#00D9FF] bg-[#00D9FF]/5' : 'border-white/10 hover:border-white/30'}`}
                    >
                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${gateway === 'paypal' ? 'border-[#00D9FF]' : 'border-slate-500'}`}>
                            {gateway === 'paypal' && <div className="w-2.5 h-2.5 rounded-full bg-[#00D9FF]" />}
                        </div>
                        <div>
                            <div className="font-bold">PayPal</div>
                            <div className="text-xs text-slate-400">International Credit Cards</div>
                        </div>
                    </div>
                  )}
               </div>

               <div className="mt-8">
                  {isFormValid ? (
                      gateway === 'paypal' ? (
                          <PayPalCheckout amount={price} planId={plan.id} billingPeriod={billingPeriod} employerDetails={employerDetails} />
                      ) : (
                          <PayFastCheckout amount={price} planId={plan.id} billingPeriod={billingPeriod} employerDetails={employerDetails} />
                      )
                  ) : (
                      <div className="text-center p-4 bg-red-500/10 text-red-400 rounded-lg text-sm">
                          Please complete your details above to proceed with payment.
                      </div>
                  )}
               </div>
            </div>
          </div>

          {/* Right Column: Order Summary */}
          <div className="space-y-6">
            <div className="bg-slate-900 border border-white/10 rounded-xl p-6 sticky top-24">
                <h3 className="text-xl font-bold mb-6">Order Summary</h3>
                <div className="flex justify-between items-start mb-4 pb-4 border-b border-white/5">
                    <div>
                        <div className="font-bold text-lg">{plan.name}</div>
                        <div className="text-sm text-slate-400 capitalize">{billingPeriod} Billing</div>
                    </div>
                    <div className="font-bold text-xl">R{price.toLocaleString()}</div>
                </div>
                
                <div className="space-y-2 mb-6 text-sm text-slate-400">
                    <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span>R{price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>VAT (15%)</span>
                        <span>R{(price * 0.15).toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                    </div>
                    <div className="flex justify-between font-bold text-white text-lg pt-4 border-t border-white/5">
                        <span>Total Due</span>
                        <span>R{(price * 1.15).toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                    </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-950 p-3 rounded-lg">
                    <ShieldCheck className="w-4 h-4 text-emerald-500" />
                    <span>Secure encrypted payment processing</span>
                </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;