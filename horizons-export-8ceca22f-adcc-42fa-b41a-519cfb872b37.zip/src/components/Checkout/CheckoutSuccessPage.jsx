import React, { useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle, Download, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import Navigation from '@/components/Navigation';

const CheckoutSuccessPage = () => {
  const [searchParams] = useSearchParams();
  const transactionId = searchParams.get('transaction_id') || searchParams.get('m_payment_id') || 'UNKNOWN';
  const amount = searchParams.get('amount');
  const plan = searchParams.get('plan');

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans flex flex-col">
       <Navigation />
       <div className="flex-grow flex items-center justify-center p-6 pt-24">
           <motion.div 
             initial={{ scale: 0.9, opacity: 0 }}
             animate={{ scale: 1, opacity: 1 }}
             className="max-w-xl w-full bg-slate-900 border border-white/10 rounded-2xl p-8 text-center shadow-2xl relative overflow-hidden"
           >
               <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-emerald-500 to-[#00D9FF]" />
               
               <div className="w-24 h-24 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-emerald-500">
                   <CheckCircle className="w-12 h-12" />
               </div>

               <h1 className="text-3xl font-bold mb-2 text-white">Payment Successful!</h1>
               <p className="text-slate-400 mb-8">
                   Your subscription is now active. Welcome to autonomous HR.
               </p>

               <div className="bg-slate-950 rounded-xl p-6 mb-8 text-left space-y-3 text-sm">
                   <div className="flex justify-between border-b border-white/5 pb-2">
                       <span className="text-slate-500">Transaction ID</span>
                       <span className="font-mono text-white">{transactionId}</span>
                   </div>
                   <div className="flex justify-between border-b border-white/5 pb-2">
                       <span className="text-slate-500">Plan</span>
                       <span className="text-white font-bold">{plan}</span>
                   </div>
                   <div className="flex justify-between">
                       <span className="text-slate-500">Amount Paid</span>
                       <span className="text-[#00D9FF] font-bold">R{amount}</span>
                   </div>
               </div>

               <div className="flex flex-col gap-3">
                   <Link to="/employer-dashboard">
                       <Button className="w-full h-12 bg-[#00D9FF] text-slate-950 font-bold hover:bg-[#00D9FF]/90">
                           Go to Dashboard <ArrowRight className="ml-2 w-4 h-4" />
                       </Button>
                   </Link>
                   <Button variant="outline" className="w-full border-white/10">
                       <Download className="ml-2 w-4 h-4" /> Download Invoice
                   </Button>
               </div>
           </motion.div>
       </div>
    </div>
  );
};

export default CheckoutSuccessPage;