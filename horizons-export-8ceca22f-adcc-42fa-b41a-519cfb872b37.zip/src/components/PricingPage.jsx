import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Helmet } from 'react-helmet';
import PricingTiers from '@/components/PricingTiers';
import AutomationComparison from '@/components/AutomationComparison';
import IndiraExperienceLevels from '@/components/IndiraExperienceLevels';
import HowItWorksPractice from '@/components/HowItWorksPractice';

const FAQItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border border-white/10 rounded-lg bg-slate-900/50 overflow-hidden mb-4">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-6 text-left hover:bg-white/5 transition-colors"
      >
        <span className="text-lg font-semibold text-white">{question}</span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <ChevronDown className="w-5 h-5 text-[#00D9FF]" />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="p-6 pt-0 text-slate-400 leading-relaxed border-t border-white/5">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const PricingPage = () => {
  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white">
      <Helmet>
        <title>Pricing | Indira Jobs - Autonomous HR</title>
        <meta name="description" content="Flexible HR solutions for South African businesses. Choose the level of autonomy that fits your needs. Cancel anytime." />
      </Helmet>
      
      <Navigation />

      <main className="pt-24">
        {/* Pricing Tiers Section */}
        <PricingTiers />
        
        {/* Automation Comparison */}
        <div className="bg-slate-900/30 border-y border-white/5">
           <AutomationComparison />
        </div>

        {/* Experience Levels */}
        <div className="py-12">
           <IndiraExperienceLevels />
        </div>

        {/* How It Works */}
        <HowItWorksPractice />

        {/* Plan Limits at a Glance */}
        <div className="py-24 px-6 bg-slate-900/20">
            <div className="max-w-7xl mx-auto">
              <h3 className="text-center mb-12 text-3xl font-bold">Plan Limits at a Glance</h3>
              <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden shadow-2xl">
                 <div className="grid grid-cols-4 bg-slate-950 p-6 border-b border-white/10 text-sm font-bold text-slate-400 hidden md:grid">
                    <div className="col-span-1">Feature</div>
                    <div className="text-center text-white">Assistant</div>
                    <div className="text-center text-[#00D9FF]">Partner</div>
                    <div className="text-center text-white">Enterprise</div>
                 </div>
                 {[
                    { label: "Max Active Employees", a: "Up to 50", p: "Up to 500", e: "Unlimited" },
                    { label: "Active Job Slots", a: "5", p: "20", e: "Unlimited" },
                    { label: "Locations Supported", a: "1", p: "5", e: "Unlimited" },
                    { label: "Admin/HR Seats", a: "1", p: "5", e: "Unlimited" },
                    { label: "Analytics Depth", a: "Core Metrics", p: "Advanced Reports", e: "Full Predictive Suite" },
                 ].map((row, i) => (
                    <div key={i} className="grid grid-cols-1 md:grid-cols-4 p-6 border-b border-white/5 text-sm hover:bg-white/5 transition-colors gap-4 md:gap-0">
                       <div className="font-medium text-slate-300 md:col-span-1 flex justify-between md:block">
                          <span>{row.label}</span>
                       </div>
                       <div className="flex justify-between md:block md:text-center">
                          <span className="md:hidden text-slate-500 text-xs uppercase">Assistant</span>
                          <span className="text-slate-400">{row.a}</span>
                       </div>
                       <div className="flex justify-between md:block md:text-center">
                          <span className="md:hidden text-[#00D9FF] text-xs uppercase">Partner</span>
                          <span className="text-white font-medium">{row.p}</span>
                       </div>
                       <div className="flex justify-between md:block md:text-center">
                          <span className="md:hidden text-slate-500 text-xs uppercase">Enterprise</span>
                          <span className="text-slate-400">{row.e}</span>
                       </div>
                    </div>
                 ))}
                 <div className="p-6 bg-slate-950 text-center text-xs text-slate-500">
                    * Limits are typical usage per plan and can be customized for your needs.
                 </div>
              </div>
           </div>
        </div>

        {/* FAQ Section */}
        <div className="max-w-4xl mx-auto py-24 px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-slate-400 text-lg">Everything you need to know about our plans and billing.</p>
          </div>
          
          <div className="space-y-4">
            <FAQItem 
              question="What's included in each plan?" 
              answer="Each plan is designed for a specific stage of business growth. The Assistant plan covers recruitment and basic compliance. Partner adds full operations like payroll and performance management. Enterprise includes strategic tools like predictive risk and succession planning. See the feature comparison table above for full details." 
            />
            <FAQItem 
              question="Can I change my billing period?" 
              answer="Yes! You can switch between monthly and yearly billing at any time. If you switch to yearly, we'll prorate your remaining monthly payment towards the annual cost, instantly saving you money." 
            />
            <FAQItem 
              question="What's your cancellation policy?" 
              answer="We believe in earning your business every month. You can cancel your subscription at any time with no questions asked. Your access will continue until the end of your current billing cycle." 
            />
            <FAQItem 
              question="Do you offer discounts for annual billing?" 
              answer="Absolutely. Our annual plans offer significant savings: 2 months free on Assistant and Partner plans, and 4 months free on the Enterprise plan." 
            />
            <FAQItem 
              question="Is there a setup fee?" 
              answer="No. There are no setup fees, implementation fees, or hidden charges. The price you see is the price you pay." 
            />
            <FAQItem 
              question="Can I add extra users/seats?" 
              answer="Yes. While our plans come with generous seat allocations, you can add additional admin seats. Please contact our sales team for custom add-on pricing." 
            />
            <FAQItem 
              question="What payment methods do you accept?" 
              answer="We accept all major credit cards via Stripe, PayPal, and dLocal Go for secure local payments (EFT/Card). Enterprise clients can also request invoice billing." 
            />
            <FAQItem 
              question="Do you offer a free trial?" 
              answer="We offer a 14-day money-back guarantee for all new subscriptions. If you're an Enterprise customer, please contact sales to arrange a guided demo and pilot program." 
            />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PricingPage;