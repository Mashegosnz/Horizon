import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const CallToActionSection = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Email Required",
        description: "Please enter your email address",
        variant: "destructive",
      });
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Success! 🎉",
        description: "Thank you for your interest! We'll be in touch soon with more information about Indira.",
        duration: 6000,
      });
      setEmail('');
      setIsLoading(false);
    }, 1500);
  };

  return (
    <section className="py-24 bg-gradient-to-br from-deep-space via-deep-purple/20 to-deep-space relative overflow-hidden">
      {/* Animated Background Elements */}
      <motion.div
        className="absolute top-0 left-0 w-full h-full opacity-30"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
      >
        <div className="absolute top-20 left-20 w-64 h-64 bg-electric-cyan rounded-full blur-[100px] animate-float" />
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-neon-blue rounded-full blur-[100px] animate-float" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-deep-purple rounded-full blur-[100px] animate-float" style={{ animationDelay: '2s' }} />
      </motion.div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="max-w-4xl mx-auto text-center"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {/* Icon */}
          <motion.div
            className="inline-block mb-10"
            initial={{ scale: 0, rotate: -180 }}
            whileInView={{ scale: 1, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, type: 'spring' }}
          >
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-electric-cyan to-neon-blue flex items-center justify-center shadow-neon">
              <Sparkles className="h-12 w-12 text-white" />
            </div>
          </motion.div>

          {/* Headline */}
          <motion.h2
            className="text-5xl md:text-7xl font-black mb-8 leading-tight tracking-tight"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <span className="gradient-text">Ready to Transform</span>
            <br />
            <span className="text-metallic-silver">Your HR Operations?</span>
          </motion.h2>

          {/* Subheading */}
          <motion.p
            className="text-xl md:text-2xl text-metallic-silver/80 mb-12 max-w-2xl mx-auto font-light"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Join hundreds of South African businesses already using Indira to streamline their HR processes with autonomous HR.
          </motion.p>

          {/* Email Form */}
          <motion.form
            onSubmit={handleSubmit}
            className="max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <div className="glassmorphism rounded-full p-2 shadow-2xl">
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your work email"
                  className="flex-1 px-8 py-5 bg-transparent border-none text-white placeholder:text-metallic-silver/40 focus:outline-none focus:ring-0 text-lg rounded-full"
                  disabled={isLoading}
                />
                <Button
                  type="submit"
                  size="lg"
                  disabled={isLoading}
                  className="bg-electric-cyan text-deep-space hover:bg-neon-blue hover:text-white font-bold px-10 py-5 rounded-full shadow-lg hover:shadow-neon transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed text-lg h-auto"
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <motion.div
                        className="w-5 h-5 border-2 border-deep-space border-t-transparent rounded-full"
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      />
                      Processing...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      Get Started Free
                      <ArrowRight className="h-5 w-5" />
                    </span>
                  )}
                </Button>
              </div>
            </div>
          </motion.form>

          {/* Trust Indicators */}
          <motion.div
            className="mt-16 flex flex-wrap justify-center items-center gap-10 text-metallic-silver/50 uppercase tracking-widest text-xs font-semibold"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-electric-cyan rounded-full shadow-[0_0_5px_#00d9ff]" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-neon-blue rounded-full shadow-[0_0_5px_#0080ff]" />
              <span>30-day free trial</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-electric-cyan rounded-full shadow-[0_0_5px_#00d9ff]" />
              <span>Cancel anytime</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CallToActionSection;