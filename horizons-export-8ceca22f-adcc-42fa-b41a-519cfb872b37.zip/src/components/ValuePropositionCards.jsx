import React from 'react';
import { motion } from 'framer-motion';
import { FileText, ShieldCheck, Sparkles } from 'lucide-react';

const Card = ({ icon: Icon, title, description, delay }) => (
  <motion.div
    className="group relative p-8 rounded-xl bg-slate-900 border border-white/5 hover:border-cyan-500/50 transition-all duration-300 shadow-lg hover:shadow-2xl hover:shadow-cyan-500/20 overflow-hidden h-full"
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay, ease: "easeOut" }}
    whileHover={{ y: -5, scale: 1.02 }}
  >
    {/* Glow Background Effect */}
    <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
    
    <div className="relative z-10 flex flex-col h-full items-start text-left">
      <div className="w-14 h-14 rounded-lg bg-slate-950 border border-white/10 flex items-center justify-center mb-6 group-hover:border-cyan-500/50 group-hover:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all duration-300">
        <Icon className="w-7 h-7 text-cyan-400 group-hover:text-cyan-300" />
      </div>
      
      <h3 className="text-xl font-semibold text-white mb-4 group-hover:text-cyan-400 transition-colors">{title}</h3>
      <p className="text-slate-300 leading-relaxed text-base">
        {description}
      </p>
    </div>
  </motion.div>
);

const ValuePropositionCards = () => {
  return (
    <section className="py-16 md:py-24 bg-slate-950 relative overflow-hidden">
      {/* Grid Pattern Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20 pointer-events-none" />

      <div className="container mx-auto px-4 md:px-8 lg:px-16 relative z-10">
        <div className="text-center mb-16 md:mb-20">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Why Choose <span className="text-cyan-400 drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]">Indira?</span>
          </motion.h2>
          <motion.p 
            className="text-slate-300 text-lg max-w-2xl mx-auto font-light"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            We're reimagining the hiring process to put human potential first.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          <Card 
            icon={FileText}
            title="Beyond the Resume"
            description="Static documents can't capture your drive. Express your full potential through dynamic profiling that highlights your personality, soft skills, and unique strengths."
            delay={0.1}
          />
          <Card 
            icon={ShieldCheck}
            title="Verified & Authentic"
            description="Stand out in a crowded market. Our blockchain-backed verification for ID and qualifications builds instant trust with employers, fast-tracking your application."
            delay={0.2}
          />
          <Card 
            icon={Sparkles}
            title="Intelligent Matching"
            description="Stop applying into the void. Our AI connects you with opportunities that match not just your skills, but your career goals, culture fit, and salary expectations."
            delay={0.3}
          />
        </div>
      </div>
    </section>
  );
};

export default ValuePropositionCards;