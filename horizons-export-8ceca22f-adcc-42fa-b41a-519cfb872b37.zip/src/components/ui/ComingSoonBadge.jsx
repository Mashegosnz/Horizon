import React from 'react';

const ComingSoonBadge = ({ className }) => {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 ${className}`}>
      Coming Soon
    </span>
  );
};

export default ComingSoonBadge;