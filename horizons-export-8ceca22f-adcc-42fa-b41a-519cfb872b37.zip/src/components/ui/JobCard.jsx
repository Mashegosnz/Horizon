import React from 'react';
import { MapPin, Building, Banknote, Percent } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ComingSoonBadge from './ComingSoonBadge';

const JobCard = ({ title, company, location, salary, match, tags }) => {
  return (
    <div className="group relative bg-slate-900 border border-white/5 rounded-xl p-6 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10 hover:-translate-y-1">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">{title}</h3>
          <div className="flex items-center gap-2 text-slate-400 text-sm mt-1">
            <Building className="w-4 h-4" />
            <span>{company}</span>
          </div>
        </div>
        <div className="flex items-center gap-1 bg-cyan-500/10 text-cyan-400 px-3 py-1 rounded-full text-sm font-bold border border-cyan-500/20">
          <Percent className="w-3 h-3" />
          <span>{match}%</span>
        </div>
      </div>

      <div className="space-y-3 mb-6">
        <div className="flex items-center gap-2 text-slate-300 text-sm">
          <MapPin className="w-4 h-4 text-cyan-500/50" />
          <span>{location}</span>
        </div>
        <div className="flex items-center gap-2 text-slate-300 text-sm">
          <Banknote className="w-4 h-4 text-cyan-500/50" />
          <span>{salary}</span>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {tags && tags.map((tag, i) => (
          <span key={i} className="text-xs text-slate-500 bg-slate-950 px-2 py-1 rounded border border-white/5">
            {tag}
          </span>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <Button variant="outline" className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 hover:text-cyan-300 w-full group-hover:bg-cyan-500 group-hover:text-slate-950 group-hover:border-cyan-500 transition-all font-semibold">
          View Details
        </Button>
      </div>
      
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <ComingSoonBadge />
      </div>
    </div>
  );
};

export default JobCard;