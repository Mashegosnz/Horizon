import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import Card from '@/components/ui/Card';

const MetricCard = ({ title, value, trend, trendUp, icon: Icon }) => {
  return (
    <Card className="bg-slate-900/50 backdrop-blur-sm border border-white/5 hover:bg-slate-900 hover:border-cyan-500/30 transition-all duration-300">
      <div className="flex justify-between items-start mb-4">
        <div className="p-3 bg-slate-950 rounded-lg border border-white/5">
          <Icon className="w-6 h-6 text-cyan-400" />
        </div>
        {trend && (
          <div className={`flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-full border ${trendUp ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border-rose-500/20'}`}>
            {trendUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
            <span>{trend}</span>
          </div>
        )}
      </div>
      <h3 className="text-slate-400 text-sm font-medium mb-1">{title}</h3>
      <p className="text-3xl font-bold text-white">{value}</p>
    </Card>
  );
};

export default MetricCard;