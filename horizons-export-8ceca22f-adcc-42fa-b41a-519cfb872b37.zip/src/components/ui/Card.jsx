import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const Card = ({ children, className, hoverEffect = true, ...props }) => {
  return (
    <motion.div
      whileHover={hoverEffect ? { y: -5, scale: 1.01 } : {}}
      className={cn(
        "bg-slate-900 border border-white/5 rounded-xl p-6 shadow-lg transition-all duration-300",
        hoverEffect && "hover:shadow-2xl hover:shadow-cyan-500/10 hover:border-cyan-500/30",
        className
      )}
      {...props}
    >
      {children}
    </motion.div>
  );
};

export default Card;