import React from 'react';
import { cn } from '@/lib/utils';

const Badge = ({ children, variant = "default", className }) => {
  const variants = {
    default: "bg-slate-800 text-slate-300 border-slate-700",
    cyan: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
    outline: "border-white/10 text-slate-400 bg-transparent",
    success: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    warning: "bg-amber-500/10 text-amber-400 border-amber-500/20"
  };

  return (
    <span className={cn(
      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border transition-colors",
      variants[variant],
      className
    )}>
      {children}
    </span>
  );
};

export default Badge;