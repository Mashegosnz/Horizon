import { cn } from '@/lib/utils';
import { Slot } from '@radix-ui/react-slot';
import { cva } from 'class-variance-authority';
import React from 'react';

const buttonVariants = cva(
  'inline-flex items-center justify-center rounded-lg text-sm font-semibold transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background',
  {
    variants: {
      variant: {
        default: 'bg-[#00D9FF] text-slate-950 hover:shadow-lg hover:shadow-[#00D9FF]/50 hover:scale-[1.02]',
        outline: 'border-2 border-[#00D9FF] bg-transparent text-white hover:bg-[#00D9FF]/10 hover:shadow-lg hover:shadow-[#00D9FF]/30 hover:scale-[1.02]',
        secondary: 'bg-slate-800 text-white hover:bg-slate-700',
        ghost: 'hover:bg-slate-800 hover:text-white',
        link: 'text-[#00D9FF] underline-offset-4 hover:underline',
      },
      size: {
        default: 'h-11 px-6 py-3',
        sm: 'h-9 px-4',
        lg: 'h-14 px-8 text-lg',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
);

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : 'button';
  return (
    <Comp
      className={cn(buttonVariants({ variant, size, className }))}
      ref={ref}
      {...props}
    />
  );
});
Button.displayName = 'Button';

export { Button, buttonVariants };