import React from 'react';
import { MapPin, Briefcase, Award, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Badge from '@/components/ui/Badge';
import Card from '@/components/ui/Card';

const CandidateCard = ({ name, role, skills, match, image }) => {
  return (
    <Card className="group border border-white/5 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10 hover:scale-[1.02]">
      <div className="flex items-start gap-4 mb-4">
        <div className="relative">
          <img 
            src={image || "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop"} 
            alt={name}
            className="w-16 h-16 rounded-full object-cover border-2 border-slate-800 group-hover:border-cyan-500 transition-colors"
          />
          <div className="absolute -bottom-1 -right-1 bg-cyan-500 text-slate-950 rounded-full p-1">
             <CheckCircle className="w-3 h-3" />
          </div>
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">{name}</h3>
            <span className="text-cyan-400 font-bold text-sm">{match}% Match</span>
          </div>
          <div className="flex items-center gap-2 text-slate-400 text-sm mt-1">
            <Briefcase className="w-3 h-3" />
            <span>{role}</span>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          {skills && skills.map((skill, i) => (
            <span key={i} className="text-xs bg-slate-950 text-slate-300 px-2 py-1 rounded border border-white/5">
              {skill}
            </span>
          ))}
        </div>
      </div>

      <div className="flex gap-3">
        <Button className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-lg shadow-cyan-500/20">
          View Profile
        </Button>
        <Button variant="outline" className="px-3 border-white/10 hover:border-cyan-500/50 hover:bg-cyan-500/5">
          <Award className="w-4 h-4 text-cyan-400" />
        </Button>
      </div>
      
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <Badge variant="cyan">Coming Soon</Badge>
      </div>
    </Card>
  );
};

export default CandidateCard;