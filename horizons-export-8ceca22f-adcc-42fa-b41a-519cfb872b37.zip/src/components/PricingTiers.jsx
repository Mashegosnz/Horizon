import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Check, Star, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

const PricingTiers = () => {
  const [billingPeriod, setBillingPeriod] = useState('monthly'); // 'monthly' or 'yearly'

  const tiers = [
    {
      name: 'Assistant',
      id: 'Starter',
      audience: 'Best for 5–50 employees',
      monthlyPrice: 497,
      yearlyPrice: 4797,
      features: [
        '5 Active Job Slots',
        'AI Candidate Screening',
        'Basic Contracts (BCEA)',
        'Leave Management',
        'Document Storage',
        'Email Support'
      ],
      buttonColor: 'bg-slate-800 border border-white/10 hover:border-white/30 text-white',
      neonColor: 'group-hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]'
    },
    {
      name: 'Partner',
      id: 'Growth',
      audience: 'Best for 50–500 employees',
      monthlyPrice: 987,
      yearlyPrice: 9987,
      features: [
        'Everything in Assistant',
        '20 Active Job Slots',
        'Full Payroll Integration',
        'Performance Cycles',
        'Legislative Updates',
        'Priority Support'
      ],
      buttonColor: 'bg-[#00D9FF] text-slate-950 hover:bg-white',
      recommended: true,
      neonColor: 'shadow-[0_0_30px_rgba(0,217,255,0.15)]'
    },
    {
      name: 'Enterprise',
      id: 'Enterprise',
      audience: 'Best for 500+ employees',
      monthlyPrice: 1987,
      yearlyPrice: 19987,
      features: [
        'Everything in Partner',
        'Unlimited Job Slots',
        'Predictive Risk Analytics',
        'B-BBEE Optimization',
        'Succession Planning',
        'Dedicated Success Manager'
      ],
      buttonColor: 'bg-slate-800 border border-[#00D9FF]/30 text-white hover:bg-[#00D9FF]/10',
      neonColor: 'group-hover:shadow-[0_0_30px_rgba(0,217,255,0.1)]'
    }
  ];

  return (
    <section className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-[#00D9FF]/5 rounded-full blur-[100px]" />
      <div className="absolute bottom-1/4 left-0 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[100px]" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
            Simple, Transparent <span className="text-[#00D9FF]">Pricing</span>
          </h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-8">
            Choose the autonomy level that fits your business. No hidden fees.
          </p>

          {/* Toggle Switch */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <span className={`text-sm font-medium ${billingPeriod === 'monthly' ? 'text-white' : 'text-slate-500'}`}>Monthly</span>
            <button
              onClick={() => setBillingPeriod(billingPeriod === 'monthly' ? 'yearly' : 'monthly')}
              className="relative w-16 h-8 bg-slate-800 rounded-full p-1 transition-colors duration-300 border border-white/10"
            >
              <motion.div
                className="w-6 h-6 bg-[#00D9FF] rounded-full shadow-md"
                layout
                transition={{ type: "spring", stiffness: 700, damping: 30 }}
                style={{
                  x: billingPeriod === 'yearly' ? 32 : 0
                }}
              />
            </button>
            <span className={`text-sm font-medium ${billingPeriod === 'yearly' ? 'text-white' : 'text-slate-500'}`}>
              Yearly <span className="text-[#00D9FF] text-xs font-bold ml-1">(Save up to 4 months)</span>
            </span>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {tiers.map((tier, index) => {
            const price = billingPeriod === 'monthly' ? tier.monthlyPrice : tier.yearlyPrice;
            const savingsText = tier.id === 'Enterprise' ? 'Save 4 months' : 'Save 2 months';
            
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.02, y: -5 }}
                className="relative group h-full"
              >
                {tier.recommended && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20 w-full max-w-[200px]">
                    <div className="bg-gradient-to-r from-[#00D9FF] to-cyan-400 text-slate-950 px-4 py-1.5 rounded-full text-xs font-bold flex items-center justify-center gap-1 shadow-lg uppercase tracking-wider">
                      <Star className="h-3 w-3 fill-current" />
                      Most Popular
                    </div>
                  </div>
                )}

                <div
                  className={`h-full rounded-2xl p-8 transition-all duration-300 relative overflow-hidden flex flex-col ${
                    tier.recommended
                      ? 'bg-slate-900 border-2 border-[#00D9FF] shadow-[0_0_30px_rgba(0,217,255,0.1)]'
                      : 'bg-slate-900 border border-white/10 hover:border-[#00D9FF]/50'
                  } ${tier.neonColor}`}
                >
                  {/* Header */}
                  <div className="mb-6 relative z-10 text-center">
                    <h3 className={`text-2xl font-bold mb-2 ${tier.recommended ? 'text-[#00D9FF]' : 'text-white'}`}>{tier.name}</h3>
                    <p className="text-slate-400 text-sm mb-6">{tier.audience}</p>
                    
                    <div className="mb-2 flex items-baseline justify-center gap-1">
                      <span className="text-sm text-slate-400 font-medium">R</span>
                      <span className="text-5xl font-bold text-white tracking-tight">
                        {price.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-slate-400 text-sm mb-2">
                      {billingPeriod === 'monthly' ? 'per month, billed monthly' : 'per year, billed yearly'}
                    </div>
                    
                    {billingPeriod === 'yearly' && (
                      <div className="inline-block bg-emerald-500/10 text-emerald-400 text-xs font-bold px-2 py-1 rounded">
                        {savingsText}
                      </div>
                    )}
                  </div>

                  <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent w-full mb-6" />

                  {/* Features */}
                  <ul className="space-y-4 mb-8 relative z-10 flex-grow">
                    {tier.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start gap-3">
                        <div className="mt-0.5 w-5 h-5 rounded-full bg-[#00D9FF]/10 flex items-center justify-center flex-shrink-0">
                           <Check className="h-3 w-3 text-[#00D9FF]" />
                        </div>
                        <span className="text-slate-300 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <div className="mt-auto pt-4 relative z-10 space-y-3">
                    <Link to={`/subscription-confirmation?plan=${tier.id}&billing=${billingPeriod}`}>
                      <Button
                        className={`w-full ${tier.buttonColor} h-12 font-bold rounded-xl shadow-lg transition-all duration-300 uppercase tracking-widest text-sm`}
                      >
                        Subscribe {billingPeriod === 'monthly' ? 'Monthly' : 'Yearly'}
                      </Button>
                    </Link>
                    <div className="text-center">
                      <span className="text-xs text-slate-500">Cancel anytime, no commitment</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default PricingTiers;