import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Briefcase, MapPin, DollarSign, TrendingUp, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ProfileDashboard = () => {
  const matches = [
    { id: 1, role: 'Junior React Dev', company: 'TechFlow', match: 95, salary: 'R 25k', loc: 'Cape Town' },
    { id: 2, role: 'Frontend Engineer', company: 'InnovateX', match: 88, salary: 'R 35k', loc: 'Remote' },
    { id: 3, role: 'Web Developer', company: 'Studio 42', match: 82, salary: 'R 22k', loc: 'Durban' },
  ];

  return (
    <div className="min-h-screen pt-24 px-4 container mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-1 lg:grid-cols-3 gap-8"
      >
        {/* Profile Strength */}
        <div className="bg-charcoal border border-electric-cyan/30 p-8 rounded-2xl shadow-[0_0_30px_rgba(0,217,255,0.1)] text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10"><Trophy className="w-32 h-32" /></div>
          
          <div className="relative z-10">
            <h3 className="text-gray-400 uppercase tracking-widest text-sm mb-6">Profile Strength</h3>
            <div className="w-40 h-40 mx-auto rounded-full border-8 border-deep-space relative flex items-center justify-center bg-electric-cyan/10 mb-6">
              <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-gray-700" />
                <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="8" fill="transparent" strokeDasharray="440" strokeDashoffset="44" className="text-electric-cyan transition-all duration-1000" />
              </svg>
              <span className="text-4xl font-bold text-white">90%</span>
            </div>
            <p className="text-green-400 font-medium flex items-center justify-center gap-2">
              <CheckCircle className="w-4 h-4" /> Ready for Employers
            </p>
          </div>
        </div>

        {/* AI Matches */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <TrendingUp className="text-electric-cyan" /> Top Matches
            </h2>
            <Button variant="ghost" className="text-electric-cyan hover:text-white">View All</Button>
          </div>

          <div className="grid gap-4">
            {matches.map((job, i) => (
              <motion.div 
                key={job.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-charcoal p-6 rounded-xl border border-white/5 hover:border-electric-cyan/50 transition-all flex justify-between items-center group hover:bg-white/5"
              >
                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-electric-cyan transition-colors">{job.role}</h3>
                  <p className="text-gray-400 mb-2">{job.company}</p>
                  <div className="flex gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {job.loc}</span>
                    <span className="flex items-center gap-1 text-green-400/80"><DollarSign className="w-3 h-3" /> {job.salary}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-electric-cyan mb-2">{job.match}%</div>
                  <Button size="sm" className="bg-white/10 hover:bg-electric-cyan hover:text-deep-space text-white">Quick Apply</Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ProfileDashboard;