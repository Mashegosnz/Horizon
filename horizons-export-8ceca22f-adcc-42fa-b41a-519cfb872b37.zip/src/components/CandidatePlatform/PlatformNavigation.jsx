import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Globe, MessageSquare, Shield, Lock, Menu, X, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const languages = [
  "English", "IsiZulu", "IsiXhosa", "Afrikaans", "Sepedi", "Setswana", 
  "Sesotho", "Xitsonga", "SiSwati", "Tshivenda", "IsiNdebele"
];

const PlatformNavigation = ({ toggleMenu }) => {
  const [currentLang, setCurrentLang] = useState("English");
  const [showLangMenu, setShowLangMenu] = useState(false);

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-white/5 transition-all duration-300">
        <div className="container mx-auto px-4 md:px-8 h-20 flex justify-between items-center">
          {/* Logo - Navigate back to WelcomeHero (Landing) */}
          <Link to="/" className="flex items-center gap-2 group">
            <span className="font-['Great_Vibes'] text-3xl text-cyan-400 drop-shadow-[0_0_10px_rgba(6,182,212,0.8)] group-hover:drop-shadow-[0_0_15px_rgba(6,182,212,1)] transition-all">i</span>
            <span className="font-['Playfair_Display'] italic text-xl font-bold text-white tracking-wide">Indira<span className="text-cyan-400">Jobs</span></span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            <div className="relative">
              <button 
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="flex items-center gap-2 text-sm font-medium text-slate-300 hover:text-cyan-400 transition-colors"
              >
                <Globe className="w-4 h-4" />
                {currentLang}
              </button>
              {showLangMenu && (
                <div className="absolute top-full right-0 mt-3 w-40 bg-slate-900 border border-white/10 rounded-lg shadow-xl py-2 max-h-60 overflow-y-auto z-50">
                  {languages.map(lang => (
                    <button
                      key={lang}
                      onClick={() => { setCurrentLang(lang); setShowLangMenu(false); }}
                      className="w-full text-left px-4 py-2.5 text-sm text-slate-300 hover:bg-cyan-500/10 hover:text-cyan-400 transition-colors"
                    >
                      {lang}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button className="text-sm font-medium text-slate-300 hover:text-white transition-colors">Data-Free Mode</button>
            
            <Button variant="outline" size="sm" className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 hover:border-cyan-400 hover:text-cyan-300 transition-all">
              <MessageSquare className="w-4 h-4 mr-2" /> Support
            </Button>
            
            <Link to="/">
               <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-white/5 transition-colors">
                 <ArrowLeft className="w-4 h-4 mr-2" /> Back
               </Button>
            </Link>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden text-white p-2" onClick={toggleMenu}>
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </nav>

      {/* Trust Footer (Persistent at bottom of view or section) */}
      <div className="hidden md:flex fixed bottom-0 left-0 right-0 z-40 pointer-events-none justify-between items-end px-8 py-4">
         <div className="flex gap-6 text-[11px] font-medium text-slate-500 uppercase tracking-wider pointer-events-auto bg-slate-950/90 backdrop-blur rounded-t-lg px-6 py-2 border-t border-x border-white/5 shadow-lg">
            <span className="flex items-center gap-1.5"><Shield className="w-3 h-3 text-cyan-500/50" /> POPIA Compliant</span>
            <span className="flex items-center gap-1.5"><Lock className="w-3 h-3 text-cyan-500/50" /> 256-bit Encryption</span>
            <span className="flex items-center gap-1.5"><Shield className="w-3 h-3 text-cyan-500/50" /> SAQA Verified</span>
         </div>
      </div>
    </>
  );
};

export default PlatformNavigation;