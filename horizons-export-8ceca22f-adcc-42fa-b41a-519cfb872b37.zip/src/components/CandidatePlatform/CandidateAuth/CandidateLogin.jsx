import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useCandidate } from '@/context/CandidateContext';
import Navigation from '@/components/Navigation';

const CandidateLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useCandidate();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      login(email, password);
      toast({ title: "Welcome back!", description: "Logged in successfully." });
      navigate('/candidate-dashboard');
    } catch (error) {
      toast({ title: "Login Failed", description: "Invalid email or password.", variant: "destructive" });
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white">
      <Navigation />
      <div className="pt-24 pb-12 flex items-center justify-center min-h-[80vh]">
        <div className="w-full max-w-md p-8 bg-slate-900 border border-white/10 rounded-xl shadow-2xl">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold mb-2">Candidate Login</h1>
            <p className="text-slate-400 text-sm">Access your job matches and applications</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Email</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white focus:border-[#00D9FF] outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Password</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white focus:border-[#00D9FF] outline-none"
                required
              />
            </div>

            <div className="flex justify-end">
              <Link to="#" className="text-xs text-[#00D9FF] hover:underline">Forgot password?</Link>
            </div>

            <Button type="submit" className="w-full bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 font-bold" disabled={loading}>
              {loading ? 'Logging in...' : 'Log In'}
            </Button>
          </form>

          <div className="mt-6 text-center text-xs text-slate-500">
            Don't have an account? <Link to="/candidate-signup" className="text-[#00D9FF] hover:underline">Sign up</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateLogin;