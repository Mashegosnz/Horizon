import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, ArrowRight, Check, Upload, CheckCircle } from 'lucide-react';
import Navigation from '@/components/Navigation';

const steps = [
  { id: 1, title: 'Basic Info' },
  { id: 2, title: 'Career Goals' },
  { id: 3, title: 'Experience' },
  { id: 4, title: 'Finalize' },
];

const CandidateSignup = () => {
  const [step, setStep] = useState(1);
  const { signup } = useCandidate();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '', password: '', confirmPassword: '',
    location: '', desiredRole: '', industry: '', seniority: '', salaryMin: 20000, salaryMax: 50000,
    employmentType: [], noticePeriod: '',
    yearsExperience: '', lastJobTitle: '', lastCompany: '', educationLevel: '', skills: [], languages: [],
    visibility: true, termsAccepted: false
  });

  const [skillInput, setSkillInput] = useState('');

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === 'checkbox' && name === 'employmentType') {
      const updated = checked 
        ? [...formData.employmentType, value]
        : formData.employmentType.filter(t => t !== value);
      setFormData({ ...formData, employmentType: updated });
    } else if (type === 'checkbox' && name === 'languages') {
        const updated = checked
            ? [...formData.languages, value]
            : formData.languages.filter(l => l !== value);
        setFormData({ ...formData, languages: updated });
    } else if (type === 'checkbox') {
        setFormData({ ...formData, [name]: checked });
    } else {
        setFormData({ ...formData, [name]: value });
    }
  };

  const addSkill = (e) => {
    if ((e.key === 'Enter' || e.type === 'click') && skillInput.trim()) {
      e.preventDefault();
      if (!formData.skills.includes(skillInput.trim())) {
        setFormData({ ...formData, skills: [...formData.skills, skillInput.trim()] });
      }
      setSkillInput('');
    }
  };

  const removeSkill = (skillToRemove) => {
    setFormData({ ...formData, skills: formData.skills.filter(s => s !== skillToRemove) });
  };

  const validateStep = (currentStep) => {
    if (currentStep === 1) {
       if (!formData.firstName || !formData.lastName || !formData.email || !formData.phone || !formData.password) {
           toast({ title: "Missing Fields", description: "Please fill in all required fields.", variant: "destructive" });
           return false;
       }
       if (formData.password !== formData.confirmPassword) {
           toast({ title: "Passwords Mismatch", description: "Passwords do not match.", variant: "destructive" });
           return false;
       }
       if (formData.password.length < 8) {
           toast({ title: "Weak Password", description: "Password must be at least 8 characters.", variant: "destructive" });
           return false;
       }
    }
    if (currentStep === 2) {
        if (!formData.location || !formData.desiredRole || !formData.industry) {
            toast({ title: "Missing Fields", description: "Please complete your career preferences.", variant: "destructive" });
            return false;
        }
    }
    if (currentStep === 3) {
        if (!formData.yearsExperience || !formData.educationLevel) {
            toast({ title: "Missing Fields", description: "Please provide your experience details.", variant: "destructive" });
            return false;
        }
    }
    if (currentStep === 4) {
        if (!formData.termsAccepted) {
            toast({ title: "Terms Required", description: "You must accept the terms and conditions.", variant: "destructive" });
            return false;
        }
    }
    return true;
  };

  const nextStep = () => {
    if (validateStep(step)) setStep(step + 1);
  };

  const prevStep = () => setStep(step - 1);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateStep(4)) return;
    
    setLoading(true);
    try {
        await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API
        signup(formData);
        toast({ title: "Profile Created!", description: "Welcome to Indira Jobs." });
        navigate('/candidate-dashboard');
    } catch (err) {
        toast({ title: "Error", description: err.message, variant: "destructive" });
        setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white">
      <Navigation />
      <div className="pt-24 pb-12 container mx-auto px-4 max-w-3xl">
        <div className="mb-8">
            <h1 className="text-3xl font-bold mb-4 text-center">Create Candidate Profile</h1>
            <div className="flex justify-between relative">
                <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-800 -z-10" />
                {steps.map((s) => (
                    <div key={s.id} className="flex flex-col items-center gap-2 bg-slate-950 px-2">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${step >= s.id ? 'bg-[#00D9FF] text-slate-950' : 'bg-slate-800 text-slate-500'}`}>
                            {step > s.id ? <Check className="w-4 h-4" /> : s.id}
                        </div>
                        <span className={`text-xs ${step >= s.id ? 'text-[#00D9FF]' : 'text-slate-500'}`}>{s.title}</span>
                    </div>
                ))}
            </div>
        </div>

        <div className="bg-slate-900 border border-white/10 rounded-xl p-8 shadow-2xl">
            <AnimatePresence mode="wait">
                <motion.div
                    key={step}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                >
                    {step === 1 && (
                        <div className="space-y-4">
                            <h2 className="text-xl font-bold mb-4">Basic Details</h2>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs text-slate-400 mb-1">First Name</label>
                                    <input name="firstName" value={formData.firstName} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none" placeholder="Jane" />
                                </div>
                                <div>
                                    <label className="block text-xs text-slate-400 mb-1">Last Name</label>
                                    <input name="lastName" value={formData.lastName} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none" placeholder="Doe" />
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs text-slate-400 mb-1">Email Address</label>
                                <input name="email" type="email" value={formData.email} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none" placeholder="jane@example.com" />
                            </div>
                            <div>
                                <label className="block text-xs text-slate-400 mb-1">Phone Number</label>
                                <input name="phone" value={formData.phone} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none" placeholder="+27 82 123 4567" />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs text-slate-400 mb-1">Password</label>
                                    <input name="password" type="password" value={formData.password} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none" placeholder="••••••••" />
                                </div>
                                <div>
                                    <label className="block text-xs text-slate-400 mb-1">Confirm Password</label>
                                    <input name="confirmPassword" type="password" value={formData.confirmPassword} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none" placeholder="••••••••" />
                                </div>
                            </div>
                        </div>
                    )}

                    {step === 2 && (
                        <div className="space-y-4">
                            <h2 className="text-xl font-bold mb-4">Career Preferences</h2>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs text-slate-400 mb-1">Current Location</label>
                                    <select name="location" value={formData.location} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none">
                                        <option value="">Select City</option>
                                        <option value="Johannesburg">Johannesburg</option>
                                        <option value="Cape Town">Cape Town</option>
                                        <option value="Durban">Durban</option>
                                        <option value="Pretoria">Pretoria</option>
                                        <option value="Remote">Remote</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs text-slate-400 mb-1">Desired Role</label>
                                    <input name="desiredRole" value={formData.desiredRole} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none" placeholder="e.g. Frontend Developer" />
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs text-slate-400 mb-1">Industry</label>
                                <select name="industry" value={formData.industry} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none">
                                    <option value="">Select Industry</option>
                                    <option value="Technology">Technology</option>
                                    <option value="Finance">Finance</option>
                                    <option value="Healthcare">Healthcare</option>
                                    <option value="Retail">Retail</option>
                                    <option value="Manufacturing">Manufacturing</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs text-slate-400 mb-1">Seniority Level</label>
                                <select name="seniority" value={formData.seniority} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none">
                                    <option value="">Select Level</option>
                                    <option value="Entry">Entry-level</option>
                                    <option value="Mid">Mid-level</option>
                                    <option value="Senior">Senior</option>
                                    <option value="Executive">Executive</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs text-slate-400 mb-2">Employment Type</label>
                                <div className="flex flex-wrap gap-4">
                                    {['Full-time', 'Part-time', 'Contract', 'Freelance'].map(type => (
                                        <label key={type} className="flex items-center gap-2 cursor-pointer">
                                            <input type="checkbox" name="employmentType" value={type} checked={formData.employmentType.includes(type)} onChange={handleChange} className="accent-[#00D9FF]" />
                                            <span className="text-sm">{type}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {step === 3 && (
                        <div className="space-y-4">
                             <h2 className="text-xl font-bold mb-4">Experience & Skills</h2>
                             <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs text-slate-400 mb-1">Years of Experience</label>
                                    <input name="yearsExperience" type="number" value={formData.yearsExperience} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none" />
                                </div>
                                <div>
                                    <label className="block text-xs text-slate-400 mb-1">Education Level</label>
                                    <select name="educationLevel" value={formData.educationLevel} onChange={handleChange} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white focus:border-[#00D9FF] outline-none">
                                        <option value="">Select Education</option>
                                        <option value="Matric">Matric / Grade 12</option>
                                        <option value="Diploma">Diploma</option>
                                        <option value="Bachelor">Bachelor's Degree</option>
                                        <option value="Master">Master's Degree</option>
                                        <option value="PhD">PhD</option>
                                    </select>
                                </div>
                             </div>
                             <div>
                                <label className="block text-xs text-slate-400 mb-1">Skills</label>
                                <div className="flex flex-wrap gap-2 mb-2 p-2 bg-slate-950 border border-white/10 rounded min-h-[50px]">
                                    {formData.skills.map(s => (
                                        <span key={s} className="bg-[#00D9FF]/10 text-[#00D9FF] px-2 py-1 rounded text-xs flex items-center gap-1">
                                            {s} <button onClick={() => removeSkill(s)} className="hover:text-white">&times;</button>
                                        </span>
                                    ))}
                                    <input 
                                        value={skillInput} 
                                        onChange={(e) => setSkillInput(e.target.value)} 
                                        onKeyDown={addSkill}
                                        placeholder="Type skill & press Enter"
                                        className="bg-transparent outline-none text-sm text-white flex-grow min-w-[120px]" 
                                    />
                                </div>
                             </div>
                             <div>
                                <label className="block text-xs text-slate-400 mb-2">Languages</label>
                                <div className="grid grid-cols-3 gap-2">
                                    {['English', 'Afrikaans', 'Zulu', 'Xhosa', 'Sotho'].map(lang => (
                                         <label key={lang} className="flex items-center gap-2 cursor-pointer">
                                            <input type="checkbox" name="languages" value={lang} checked={formData.languages.includes(lang)} onChange={handleChange} className="accent-[#00D9FF]" />
                                            <span className="text-sm">{lang}</span>
                                        </label>
                                    ))}
                                </div>
                             </div>
                        </div>
                    )}

                    {step === 4 && (
                        <div className="space-y-6">
                            <h2 className="text-xl font-bold mb-4">Finalize Profile</h2>
                            
                            <div className="bg-slate-950 border border-dashed border-white/20 rounded-xl p-8 flex flex-col items-center justify-center text-center hover:border-[#00D9FF]/50 transition-colors cursor-pointer">
                                <Upload className="w-10 h-10 text-slate-500 mb-4" />
                                <h3 className="font-bold text-white mb-2">Upload your CV</h3>
                                <p className="text-xs text-slate-400 mb-4">PDF, DOCX up to 5MB</p>
                                <Button size="sm" variant="outline">Select File</Button>
                            </div>

                            <div className="flex items-center justify-between bg-slate-950 p-4 rounded-lg border border-white/5">
                                <div>
                                    <div className="font-bold text-white">Profile Visibility</div>
                                    <div className="text-xs text-slate-400">Allow employers to find you</div>
                                </div>
                                <div className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-colors ${formData.visibility ? 'bg-[#00D9FF]' : 'bg-slate-700'}`} onClick={() => setFormData({...formData, visibility: !formData.visibility})}>
                                    <div className={`w-4 h-4 rounded-full bg-white transition-transform ${formData.visibility ? 'translate-x-6' : 'translate-x-0'}`} />
                                </div>
                            </div>

                            <label className="flex items-start gap-3 cursor-pointer">
                                <input type="checkbox" name="termsAccepted" checked={formData.termsAccepted} onChange={handleChange} className="mt-1 accent-[#00D9FF]" />
                                <span className="text-xs text-slate-400">I agree to the Terms of Service and Privacy Policy. I confirm that the information provided is accurate.</span>
                            </label>
                        </div>
                    )}
                </motion.div>
            </AnimatePresence>

            <div className="flex justify-between mt-8 pt-4 border-t border-white/10">
                {step > 1 ? (
                    <Button variant="outline" onClick={prevStep}><ArrowLeft className="w-4 h-4 mr-2" /> Back</Button>
                ) : <div />}
                
                {step < 4 ? (
                    <Button onClick={nextStep} className="bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90">Next <ArrowRight className="w-4 h-4 ml-2" /></Button>
                ) : (
                    <Button onClick={handleSubmit} disabled={loading} className="bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90">
                        {loading ? 'Creating...' : 'Create Profile'}
                    </Button>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateSignup;