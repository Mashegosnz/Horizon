
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import Navigation from '@/components/Navigation';

export const CandidateForgotPassword = () => {
  const [email, setEmail] = useState('');
  const { toast } = useToast();
  
  const handleSubmit = (e) => {
    e.preventDefault();
    toast({ title: "Email Sent", description: "Check your email for password reset link." });
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col text-white font-sans">
        <Navigation />
        <div className="flex-grow flex items-center justify-center p-6">
            <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl p-8">
                <h1 className="text-2xl font-bold mb-4">Reset Password</h1>
                <p className="text-slate-400 text-sm mb-6">Enter your email address and we'll send you a link to reset your password.</p>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                        <Label>Email Address</Label>
                        <Input type="email" required className="bg-slate-950 border-white/10 text-white" value={email} onChange={e=>setEmail(e.target.value)} />
                    </div>
                    <Button type="submit" className="w-full bg-[#00D9FF] text-slate-950">Send Reset Link</Button>
                </form>
                <p className="text-center text-sm mt-6"><Link to="/candidates/login" className="text-[#00D9FF]">Back to Login</Link></p>
            </div>
        </div>
    </div>
  );
};

export const CandidateResetPassword = () => {
  const [pass, setPass] = useState('');
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const handleSubmit = (e) => {
    e.preventDefault();
    toast({ title: "Success", description: "Password reset successful. Redirecting..." });
    setTimeout(() => navigate('/candidates/login'), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col text-white font-sans">
        <Navigation />
        <div className="flex-grow flex items-center justify-center p-6">
            <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl p-8">
                <h1 className="text-2xl font-bold mb-6">Set New Password</h1>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                        <Label>New Password</Label>
                        <Input type="password" required className="bg-slate-950 border-white/10 text-white" value={pass} onChange={e=>setPass(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label>Confirm Password</Label>
                        <Input type="password" required className="bg-slate-950 border-white/10 text-white" />
                    </div>
                    <Button type="submit" className="w-full bg-[#00D9FF] text-slate-950">Reset Password</Button>
                </form>
            </div>
        </div>
    </div>
  );
};
