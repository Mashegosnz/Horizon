
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCandidate } from '@/context/CandidateContext';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import Navigation from '@/components/Navigation';

const CandidateSignup = () => {
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);
  const { signup } = useCandidate();
  const navigate = useNavigate();
  const { toast } = useToast();

  const strength = form.password.length === 0 ? 0 : form.password.length < 8 ? 1 : /[A-Z]/.test(form.password) && /[0-9]/.test(form.password) ? 3 : 2;
  const strengthColors = ['bg-slate-800', 'bg-red-500', 'bg-yellow-500', 'bg-emerald-500'];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) return toast({ title: "Error", description: "Passwords do not match.", variant: "destructive" });
    if (strength < 2) return toast({ title: "Error", description: "Please use a stronger password.", variant: "destructive" });

    setLoading(true);
    setTimeout(() => {
      try {
        signup(form);
        toast({ title: "Account Created!", description: "Welcome to Indira." });
        navigate('/candidates/profile-setup');
      } catch (err) {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col">
      <Navigation />
      <div className="flex-grow flex items-center justify-center p-6 pt-24">
        <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl p-8 shadow-2xl relative">
          <div className="absolute top-0 left-0 w-full h-1 bg-[#00D9FF]" />
          <h1 className="text-2xl font-bold text-center mb-2">Create Candidate Account</h1>
          <p className="text-slate-400 text-center text-sm mb-8">Join the talent network.</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input required className="bg-slate-950 border-white/10 text-white" value={form.fullName} onChange={e=>setForm({...form, fullName: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>Email Address</Label>
              <Input type="email" required className="bg-slate-950 border-white/10 text-white" value={form.email} onChange={e=>setForm({...form, email: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>Phone Number</Label>
              <Input type="tel" required className="bg-slate-950 border-white/10 text-white" value={form.phone} onChange={e=>setForm({...form, phone: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" required className="bg-slate-950 border-white/10 text-white" value={form.password} onChange={e=>setForm({...form, password: e.target.value})} />
              <div className="flex gap-1 mt-1">
                {[1,2,3].map(i => <div key={i} className={`h-1 flex-1 rounded-full ${i <= strength ? strengthColors[strength] : 'bg-slate-800'}`} />)}
              </div>
            </div>
            <div className="space-y-2">
              <Label>Confirm Password</Label>
              <Input type="password" required className="bg-slate-950 border-white/10 text-white" value={form.confirmPassword} onChange={e=>setForm({...form, confirmPassword: e.target.value})} />
            </div>
            
            <Button type="submit" disabled={loading} className="w-full bg-[#00D9FF] text-slate-950 font-bold mt-4">
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null} Create Account
            </Button>
          </form>

          <p className="text-center text-sm text-slate-400 mt-6">
            Already have an account? <Link to="/candidates/login" className="text-[#00D9FF] hover:underline">Log in</Link>
          </p>
        </div>
      </div>
    </div>
  );
};
export default CandidateSignup;
