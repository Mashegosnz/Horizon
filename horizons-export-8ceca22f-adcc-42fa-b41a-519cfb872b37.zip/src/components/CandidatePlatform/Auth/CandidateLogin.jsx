
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCandidate } from '@/context/CandidateContext';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import Navigation from '@/components/Navigation';

const CandidateLogin = () => {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useCandidate();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      try {
        login(form.email, form.password);
        toast({ title: "Welcome back!", description: "Successfully logged in." });
        navigate('/candidates/dashboard');
      } catch (err) {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col">
      <Navigation />
      <div className="flex-grow flex items-center justify-center p-6 pt-24">
        <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl p-8 shadow-2xl relative">
          <div className="absolute top-0 left-0 w-full h-1 bg-[#00D9FF]" />
          <h1 className="text-2xl font-bold text-center mb-2">Welcome Back</h1>
          <p className="text-slate-400 text-center text-sm mb-8">Log in to your candidate portal.</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Email Address</Label>
              <Input type="email" required className="bg-slate-950 border-white/10 text-white" value={form.email} onChange={e=>setForm({...form, email: e.target.value})} />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label>Password</Label>
                <Link to="/candidates/forgot-password" className="text-xs text-[#00D9FF] hover:underline">Forgot password?</Link>
              </div>
              <Input type="password" required className="bg-slate-950 border-white/10 text-white" value={form.password} onChange={e=>setForm({...form, password: e.target.value})} />
            </div>
            
            <Button type="submit" disabled={loading} className="w-full bg-[#00D9FF] text-slate-950 font-bold mt-4">
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null} Log In
            </Button>
          </form>

          <p className="text-center text-sm text-slate-400 mt-6">
            Don't have an account? <Link to="/candidates/signup" className="text-[#00D9FF] hover:underline">Sign up</Link>
          </p>
        </div>
      </div>
    </div>
  );
};
export default CandidateLogin;
