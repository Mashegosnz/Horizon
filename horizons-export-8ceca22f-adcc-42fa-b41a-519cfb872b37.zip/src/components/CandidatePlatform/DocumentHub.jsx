import React from 'react';
import { motion } from 'framer-motion';
import { UploadCloud, CheckCircle, File, AlertCircle, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DocumentHub = ({ onNext }) => {
  return (
    <div className="min-h-screen pt-24 px-4 container mx-auto max-w-5xl">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-white mb-2">Verified Document Hub</h2>
        <p className="text-metallic-silver">Upload your documents for blockchain verification.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Verified Docs */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-charcoal border border-green-500/30 p-6 rounded-2xl relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-green-500" />
          <div className="flex items-center gap-2 mb-6 text-green-400 font-bold">
            <Shield className="w-5 h-5" /> Mandatory Verification
          </div>

          <div className="space-y-4">
            <div className="border-2 border-dashed border-white/10 rounded-xl p-8 flex flex-col items-center justify-center text-center hover:border-green-500/50 hover:bg-green-500/5 transition-all cursor-pointer group">
              <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-3 group-hover:bg-green-500/20 group-hover:text-green-400 transition-colors">
                 <UploadCloud className="w-6 h-6" />
              </div>
              <p className="text-white font-medium">Upload ID / Passport</p>
              <p className="text-xs text-gray-500 mt-1">For identity verification</p>
            </div>
            
            <div className="bg-deep-space/50 p-4 rounded-lg flex items-center justify-between border border-white/5">
              <div className="flex items-center gap-3">
                 <CheckCircle className="w-5 h-5 text-green-500" />
                 <span className="text-gray-300">Matric Certificate</span>
              </div>
              <span className="text-xs bg-green-500/10 text-green-500 px-2 py-1 rounded">Verified</span>
            </div>
          </div>
        </motion.div>

        {/* Supporting Docs */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-charcoal border border-electric-cyan/30 p-6 rounded-2xl relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-electric-cyan" />
          <div className="flex items-center gap-2 mb-6 text-electric-cyan font-bold">
            <File className="w-5 h-5" /> Supporting Documents
          </div>

          <div className="space-y-4">
            <div className="border-2 border-dashed border-white/10 rounded-xl p-8 flex flex-col items-center justify-center text-center hover:border-electric-cyan/50 hover:bg-electric-cyan/5 transition-all cursor-pointer group">
              <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-3 group-hover:bg-electric-cyan/20 group-hover:text-electric-cyan transition-colors">
                 <UploadCloud className="w-6 h-6" />
              </div>
              <p className="text-white font-medium">Drop files here</p>
              <p className="text-xs text-gray-500 mt-1">CV, Portfolio, References</p>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="mt-8 flex justify-end">
        <Button onClick={onNext} size="lg" className="bg-electric-cyan text-deep-space hover:bg-neon-blue font-bold px-8 shadow-[0_0_20px_rgba(0,217,255,0.4)]">
          Continue to Video Profile
        </Button>
      </div>
    </div>
  );
};

export default DocumentHub;