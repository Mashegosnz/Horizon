
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Briefcase, FileText, MonitorPlay, Folder, Users, Award, CheckCircle, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';

const CandidateLandingPage = () => {
  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col">
      <Navigation />
      
      {/* Hero */}
      <section className="relative pt-32 pb-20 px-6 min-h-[90vh] flex flex-col justify-center items-center overflow-hidden text-center">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1681909623271-b5d90dd4c163?q=80&w=2070&auto=format&fit=crop" alt="Hero background" className="w-full h-full object-cover opacity-20 mix-blend-overlay" />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-950/90 to-slate-950" />
        </div>
        <div className="relative z-10 max-w-5xl mx-auto">
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-5xl md:text-7xl font-extrabold mb-6 tracking-tight">
            Your Career Starts Here – <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D9FF] to-white">Indira Candidate Portal</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-xl text-slate-300 mb-10 max-w-3xl mx-auto leading-relaxed">
            AI-powered job matching, automated CV building, and comprehensive interview prep to land your dream job in South Africa.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/candidates/signup">
              <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-lg font-bold bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 shadow-[0_0_20px_rgba(0,217,255,0.3)]">Sign Up Now</Button>
            </Link>
            <Link to="/candidates/portal/jobs">
              <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 text-lg border-white/20 hover:bg-white/10 backdrop-blur-sm">Browse Jobs</Button>
            </Link>
          </motion.div>
          
          <div className="flex flex-wrap justify-center gap-6 mt-16 text-sm font-semibold text-slate-400">
             <span className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" /> POPIA Compliant</span>
             <span className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" /> Secure Data Vault</span>
             <span className="flex items-center gap-2"><Briefcase className="w-4 h-4 text-[#00D9FF]" /> AI-Powered Matches</span>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-24 px-6 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Everything You Need to Succeed</h2>
            <p className="text-slate-400 text-lg">One portal for your entire career journey.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: "CV/Resume Builder", icon: FileText, desc: "Create ATS-friendly CVs tailored to South African standards.", link: "/candidates/portal/cv-builder", btn: "Build Your CV" },
              { title: "Smart Job Board", icon: Briefcase, desc: "Get matched with top employers based on your true skills and potential.", link: "/candidates/portal/jobs", btn: "Browse Jobs" },
              { title: "Interview Prep", icon: MonitorPlay, desc: "Practice with AI-driven mock interviews and get instant feedback.", link: "/candidates/portal/interview-prep", btn: "Start Prep" },
              { title: "Document Vault", icon: Folder, desc: "Securely store your ID, qualifications, and references in one place.", link: "/candidates/portal/documents", btn: "Access Vault" },
              { title: "Career Coaching", icon: Users, desc: "Connect with industry experts for personalized career guidance.", link: "/candidates/portal/coaching", btn: "Book Session" },
              { title: "Skills Assessments", icon: Award, desc: "Prove your abilities with verified assessments to stand out to employers.", link: "/candidates/portal/assessments", btn: "Take Assessment" }
            ].map((s, i) => (
              <div key={i} className="bg-slate-950 border border-white/10 rounded-2xl p-8 hover:border-[#00D9FF]/40 transition-all hover:-translate-y-1">
                <s.icon className="w-10 h-10 text-[#00D9FF] mb-6" />
                <h3 className="text-xl font-bold mb-3">{s.title}</h3>
                <p className="text-slate-400 mb-8 min-h-[60px]">{s.desc}</p>
                <Link to={s.link}><Button variant="outline" className="w-full border-white/10 hover:text-[#00D9FF]">{s.btn}</Button></Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 px-6 bg-slate-950">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="space-y-6">
            <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
              <h4 className="font-bold text-lg mb-2">How does it work?</h4>
              <p className="text-slate-400">Sign up, complete your profile, and our AI immediately starts matching your skills with open roles across our employer network.</p>
            </div>
            <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
              <h4 className="font-bold text-lg mb-2">Is it free?</h4>
              <p className="text-slate-400">Yes! The Indira Candidate Portal is completely free for job seekers. Our goal is to connect you with the right opportunities.</p>
            </div>
            <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
              <h4 className="font-bold text-lg mb-2">How do I apply for jobs?</h4>
              <p className="text-slate-400">Once your profile is set up, you can apply to any job with a single click. Your profile and stored documents are sent directly to the employer.</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default CandidateLandingPage;
