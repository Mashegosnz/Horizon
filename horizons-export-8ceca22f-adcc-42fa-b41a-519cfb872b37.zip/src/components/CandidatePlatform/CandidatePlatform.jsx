import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PlatformNavigation from './PlatformNavigation';
import HeroPlatform from './HeroPlatform';
import ValueProposition from './ValueProposition';
import HowItWorks from './HowItWorks';
import SuccessStories from './SuccessStories';
import CandidateSignUp from './CandidateSignUp';
import SmartCV from './SmartCV';
import DocumentHub from './DocumentHub';
import VideoStudio from './VideoStudio';
import ProfileDashboard from './ProfileDashboard';

const CandidatePlatform = () => {
  // Simple state management for demo purposes
  // In production, use Context or Redux
  const [view, setView] = useState('landing'); // landing, signup, cv, docs, video, dashboard
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // Check local storage for existing session
    const saved = localStorage.getItem('indira_candidate_state');
    if (saved) {
      // Restore state logic would go here
      // For now, we start fresh or stay on landing
    }
  }, []);

  const handleStartJourney = () => {
    setView('signup');
    window.scrollTo(0, 0);
  };

  const handleSignUpComplete = (data) => {
    setUserData(data);
    localStorage.setItem('indira_user', JSON.stringify(data));
    setView('cv');
    window.scrollTo(0, 0);
  };

  const handleCVComplete = () => {
    setView('docs');
    window.scrollTo(0, 0);
  };

  const handleDocsComplete = () => {
    setView('video');
    window.scrollTo(0, 0);
  };

  const handleVideoComplete = () => {
    setView('dashboard');
    window.scrollTo(0, 0);
  };

  return (
    <div className="bg-charcoal min-h-screen font-sans text-white selection:bg-electric-cyan selection:text-deep-space">
      <PlatformNavigation />

      <AnimatePresence mode="wait">
        {view === 'landing' && (
          <motion.div key="landing" exit={{ opacity: 0 }}>
            <HeroPlatform onFindJob={handleStartJourney} onFindTalent={() => {}} />
            <ValueProposition />
            <HowItWorks />
            <SuccessStories />
          </motion.div>
        )}

        {view === 'signup' && (
          <motion.div key="signup" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <CandidateSignUp onComplete={handleSignUpComplete} />
          </motion.div>
        )}

        {view === 'cv' && (
          <motion.div key="cv" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <SmartCV onNext={handleCVComplete} />
          </motion.div>
        )}

        {view === 'docs' && (
          <motion.div key="docs" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <DocumentHub onNext={handleDocsComplete} />
          </motion.div>
        )}

        {view === 'video' && (
          <motion.div key="video" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <VideoStudio onNext={handleVideoComplete} />
          </motion.div>
        )}

        {view === 'dashboard' && (
          <motion.div key="dashboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <ProfileDashboard />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CandidatePlatform;