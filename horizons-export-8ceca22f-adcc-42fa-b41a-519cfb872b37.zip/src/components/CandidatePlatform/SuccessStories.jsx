import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: "Thabo M.",
    role: "Software Developer",
    company: "FinTech SA",
    image: "https://images.unsplash.com/photo-1519480729348-c0545cfe5f0a",
    quote: "Indira allowed me to show who I really am. My CV didn't do justice to my passion for coding. The video profile changed everything.",
    stats: "Hired in 5 days"
  },
  {
    id: 2,
    name: "Sarah L.",
    role: "Marketing Manager",
    company: "Global Brands",
    image: "https://images.unsplash.com/photo-1589216701983-4ea27aead7c1",
    quote: "I was struggling to get interviews despite my experience. Indira's AI matching connected me with a company that values my specific skillset.",
    stats: "40% Salary Increase"
  },
  {
    id: 3,
    name: "Nolwazi K.",
    role: "Customer Success",
    company: "TechRetail",
    image: "https://images.unsplash.com/photo-1572192879653-7027091bed17",
    quote: "The verification process was so smooth. Employers trusted my profile immediately, and I got offers without endless screening calls.",
    stats: "3 Offers in 1 week"
  }
];

const SuccessStories = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <section className="py-24 bg-charcoal relative">
      <div className="container mx-auto px-4 max-w-6xl">
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Success Stories</h2>
          <div className="w-24 h-1 bg-electric-cyan mx-auto rounded-full" />
        </motion.div>

        <div className="relative bg-deep-space/50 rounded-3xl p-8 md:p-16 border border-white/5 backdrop-blur-xl">
          <button onClick={prev} className="absolute left-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-white/10 hover:bg-electric-cyan/20 text-white transition-all">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button onClick={next} className="absolute right-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-white/10 hover:bg-electric-cyan/20 text-white transition-all">
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="h-[400px] md:h-[300px] relative overflow-hidden">
            <AnimatePresence mode='wait'>
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0 flex flex-col md:flex-row items-center gap-8 md:gap-16"
              >
                <div className="relative w-32 h-32 md:w-64 md:h-64 flex-shrink-0">
                  <div className="absolute inset-0 bg-electric-cyan/20 rounded-full blur-2xl animate-pulse" />
                  <img 
                    src={testimonials[current].image} 
                    alt={testimonials[current].name} 
                    className="w-full h-full object-cover rounded-full border-4 border-white/10 relative z-10"
                  />
                  <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-electric-cyan text-deep-space px-4 py-1 rounded-full text-xs font-bold whitespace-nowrap z-20 shadow-lg">
                    {testimonials[current].stats}
                  </div>
                </div>

                <div className="text-center md:text-left flex-1">
                  <Quote className="w-12 h-12 text-electric-cyan/20 mb-4 mx-auto md:mx-0" />
                  <p className="text-xl md:text-3xl text-white font-light italic mb-6 leading-relaxed">
                    "{testimonials[current].quote}"
                  </p>
                  <div>
                    <h4 className="text-xl font-bold text-electric-cyan">{testimonials[current].name}</h4>
                    <p className="text-metallic-silver">{testimonials[current].role} at {testimonials[current].company}</p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrent(idx)}
                className={`w-3 h-3 rounded-full transition-all ${idx === current ? 'bg-electric-cyan w-6' : 'bg-white/20'}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;