
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';

const CandidateProfileSetupWizard = () => {
    const { candidateUser, updateProfile } = useCandidate();
    const navigate = useNavigate();
    const { toast } = useToast();
    const [step, setStep] = useState(1);
    
    // Step States
    const [personal, setPersonal] = useState({ fullName: candidateUser?.fullName || '', email: candidateUser?.email || '', phone: candidateUser?.phone || '', location: '', dob: '' });
    const [work, setWork] = useState({ currentTitle: '', company: '', yearsExp: '', industry: '' });
    const [edu, setEdu] = useState({ level: '', field: '', institution: '', year: '' });
    const [skills, setSkills] = useState({ skillsList: '', publicProfile: true });

    const handleNext = (e) => {
        e.preventDefault();
        if (step < 4) setStep(step + 1);
        else {
            updateProfile({ ...personal, experience: [work], education: [edu], skills: skills.skillsList.split(',') });
            toast({ title: "Profile setup complete!", description: "Welcome to your portal." });
            navigate('/candidates/dashboard');
        }
    };

    return (
        <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col items-center justify-center p-6">
            <div className="w-full max-w-2xl bg-slate-900 border border-white/10 rounded-2xl p-8 shadow-2xl">
                <div className="mb-8">
                    <div className="flex justify-between text-xs font-bold text-slate-500 mb-2 px-1">
                        <span>Step {step} of 4</span>
                        <span className="text-[#00D9FF]">{Math.round((step/4)*100)}%</span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-2">
                        <div className="bg-[#00D9FF] h-2 rounded-full transition-all" style={{ width: `${(step/4)*100}%` }} />
                    </div>
                </div>

                <form onSubmit={handleNext}>
                    {step === 1 && (
                        <div className="space-y-4">
                            <h2 className="text-2xl font-bold mb-4">Personal Details</h2>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2"><Label>Full Name</Label><Input required value={personal.fullName} onChange={e=>setPersonal({...personal, fullName: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                                <div className="space-y-2"><Label>Phone</Label><Input required value={personal.phone} onChange={e=>setPersonal({...personal, phone: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                            </div>
                            <div className="space-y-2"><Label>Location</Label><Input required placeholder="City, Province" value={personal.location} onChange={e=>setPersonal({...personal, location: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                        </div>
                    )}
                    {step === 2 && (
                        <div className="space-y-4">
                            <h2 className="text-2xl font-bold mb-4">Work History</h2>
                            <div className="space-y-2"><Label>Current/Most Recent Job Title</Label><Input required value={work.currentTitle} onChange={e=>setWork({...work, currentTitle: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2"><Label>Company</Label><Input value={work.company} onChange={e=>setWork({...work, company: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                                <div className="space-y-2"><Label>Years of Experience</Label><Input type="number" required value={work.yearsExp} onChange={e=>setWork({...work, yearsExp: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                            </div>
                        </div>
                    )}
                    {step === 3 && (
                        <div className="space-y-4">
                            <h2 className="text-2xl font-bold mb-4">Education</h2>
                            <div className="space-y-2"><Label>Highest Education Level</Label><Input required value={edu.level} onChange={e=>setEdu({...edu, level: e.target.value})} placeholder="e.g. Bachelor's Degree" className="bg-slate-950 border-white/10 text-white" /></div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2"><Label>Institution</Label><Input value={edu.institution} onChange={e=>setEdu({...edu, institution: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                                <div className="space-y-2"><Label>Graduation Year</Label><Input value={edu.year} onChange={e=>setEdu({...edu, year: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                            </div>
                        </div>
                    )}
                    {step === 4 && (
                        <div className="space-y-4">
                            <h2 className="text-2xl font-bold mb-4">Skills & CV</h2>
                            <div className="space-y-2"><Label>Skills (Comma separated)</Label><Input required placeholder="React, Project Management, Sales" value={skills.skillsList} onChange={e=>setSkills({...skills, skillsList: e.target.value})} className="bg-slate-950 border-white/10 text-white" /></div>
                            <div className="space-y-2 mt-4 p-6 border-2 border-dashed border-white/20 rounded-xl text-center">
                                <p className="text-sm text-slate-400 mb-2">Upload your CV (PDF, DOCX)</p>
                                <Button type="button" variant="outline" className="border-white/10">Select File</Button>
                            </div>
                            <div className="flex items-center space-x-2 mt-4">
                                <Checkbox id="public" checked={skills.publicProfile} onCheckedChange={(c) => setSkills({...skills, publicProfile: c})} />
                                <Label htmlFor="public" className="text-sm font-normal text-slate-400">Make profile visible to employers</Label>
                            </div>
                        </div>
                    )}

                    <div className="flex justify-between mt-8 pt-6 border-t border-white/10">
                        {step > 1 ? <Button type="button" variant="ghost" onClick={() => setStep(step-1)}>Back</Button> : <div />}
                        <Button type="submit" className="bg-[#00D9FF] text-slate-950 font-bold">{step === 4 ? 'Complete Setup' : 'Next Step'}</Button>
                    </div>
                </form>
            </div>
        </div>
    );
};
export default CandidateProfileSetupWizard;
