
import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import Navigation from '@/components/Navigation';
import { LayoutDashboard, Briefcase, FileText, Bookmark, MessageSquare, Calendar, Folder, Award, Bell, User, LogOut, Menu, X } from 'lucide-react';

const MENU_ITEMS = [
  { path: '/candidates/dashboard', icon: LayoutDashboard, label: 'Dashboard Overview' },
  { path: '/candidates/dashboard/profile', icon: User, label: 'My Profile' },
  { path: '/candidates/portal/jobs', icon: Briefcase, label: 'Job Board' },
  { path: '/candidates/dashboard/applications', icon: FileText, label: 'My Applications' },
  { path: '/candidates/dashboard/saved-jobs', icon: Bookmark, label: 'Saved Jobs' },
  { path: '/candidates/dashboard/messages', icon: MessageSquare, label: 'Messages' },
  { path: '/candidates/dashboard/interviews', icon: Calendar, label: 'Interviews' },
  { path: '/candidates/dashboard/documents', icon: Folder, label: 'Document Vault' },
  { path: '/candidates/dashboard/assessments', icon: Award, label: 'Assessments' },
  { path: '/candidates/dashboard/notifications', icon: Bell, label: 'Notifications' },
];

const CandidateLayout = ({ children }) => {
  const { candidateUser, logout } = useCandidate();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/candidates');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans flex flex-col">
      <Navigation />
      
      <div className="flex flex-1 pt-20">
        {/* Mobile Sidebar Toggle */}
        <button 
          className="lg:hidden fixed bottom-6 right-6 z-50 bg-[#00D9FF] text-slate-950 p-4 rounded-full shadow-lg"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>

        {/* Sidebar */}
        <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 border-r border-white/10 pt-24 transform transition-transform duration-300 ease-in-out lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:static lg:h-[calc(100vh-5rem)] lg:pt-6 flex flex-col`}>
          <div className="px-6 mb-8">
            <h2 className="text-xl font-bold truncate">{candidateUser?.fullName}</h2>
            <p className="text-[#00D9FF] text-sm truncate">{candidateUser?.email}</p>
          </div>

          <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
            {MENU_ITEMS.map((item) => (
              <Link 
                key={item.path} 
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${location.pathname === item.path ? 'bg-[#00D9FF]/10 text-[#00D9FF] font-bold' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
              >
                <item.icon className="w-5 h-5" /> {item.label}
              </Link>
            ))}
          </nav>

          <div className="p-4 border-t border-white/10">
            <button 
              onClick={handleLogout}
              className="flex items-center gap-3 px-4 py-3 w-full text-left text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-xl transition-colors"
            >
              <LogOut className="w-5 h-5" /> Log Out
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 w-full lg:w-[calc(100%-16rem)] min-h-[calc(100vh-5rem)] overflow-y-auto">
          <div className="p-6 md:p-10 max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default CandidateLayout;
