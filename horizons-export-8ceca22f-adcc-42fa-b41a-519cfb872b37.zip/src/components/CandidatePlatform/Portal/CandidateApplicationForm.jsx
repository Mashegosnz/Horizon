
import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import CandidateLayout from '../CandidateLayout';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { FileText, Loader2, ArrowLeft } from 'lucide-react';

const CandidateApplicationForm = () => {
    const { jobId } = useParams();
    const { allJobs, applyToJob, candidateUser } = useCandidate();
    const navigate = useNavigate();
    const { toast } = useToast();
    const job = allJobs.find(j => j.id === jobId);

    const [coverLetter, setCoverLetter] = useState('');
    const [loading, setLoading] = useState(false);

    if (!job) return <CandidateLayout><div className="text-white p-10">Job not found</div></CandidateLayout>;

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);
        setTimeout(() => {
            applyToJob(job, { coverLetter });
            navigate('/candidates/dashboard/applications');
        }, 1500);
    };

    return (
        <CandidateLayout>
            <Link to={`/candidates/portal/jobs/${job.id}`} className="text-[#00D9FF] text-sm flex items-center mb-6 hover:underline"><ArrowLeft className="w-4 h-4 mr-1" /> Back to Job</Link>
            <div className="max-w-3xl mx-auto bg-slate-900 border border-white/10 rounded-2xl p-8">
                <h1 className="text-2xl font-bold text-white mb-2">Apply for {job.title}</h1>
                <p className="text-slate-400 mb-8">at {job.company}</p>

                <form onSubmit={handleSubmit} className="space-y-8">
                    {/* CV Confirm */}
                    <div className="bg-slate-950 border border-white/5 rounded-xl p-6">
                        <h3 className="font-bold text-white mb-4">Your Resume/CV</h3>
                        <div className="flex items-center justify-between p-4 border border-white/10 rounded-lg bg-slate-900">
                            <div className="flex items-center gap-3">
                                <FileText className="w-8 h-8 text-[#00D9FF]" />
                                <div>
                                    <div className="font-medium text-white">{candidateUser?.fullName?.replace(' ','_')}_CV.pdf</div>
                                    <div className="text-xs text-slate-500">Default Profile CV</div>
                                </div>
                            </div>
                            <Button type="button" variant="outline" size="sm" className="border-white/10">Replace</Button>
                        </div>
                    </div>

                    {/* Cover Letter */}
                    <div className="space-y-3">
                        <Label className="text-white text-base">Cover Letter / Pitch (Optional)</Label>
                        <Textarea 
                            rows={6} 
                            placeholder="Tell the employer why you're a great fit..." 
                            value={coverLetter} 
                            onChange={e=>setCoverLetter(e.target.value)}
                            className="bg-slate-950 border-white/10 text-white resize-none"
                        />
                    </div>

                    {/* Submit */}
                    <div className="flex justify-end gap-4 pt-6 border-t border-white/10">
                        <Link to={`/candidates/portal/jobs/${job.id}`}><Button type="button" variant="outline" className="border-white/10 hover:bg-white/5 text-white">Cancel</Button></Link>
                        <Button type="submit" disabled={loading} className="bg-[#00D9FF] text-slate-950 font-bold px-8">
                            {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null} Submit Application
                        </Button>
                    </div>
                </form>
            </div>
        </CandidateLayout>
    );
};
export default CandidateApplicationForm;
