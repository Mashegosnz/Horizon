
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import CandidateLayout from '../CandidateLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Briefcase, Zap, Heart } from 'lucide-react';

const CandidatePortalJobBoard = () => {
    const { allJobs, isJobSaved, saveJob } = useCandidate();
    const [search, setSearch] = useState('');
    const [locationFilter, setLocationFilter] = useState('');

    const filtered = allJobs.filter(j => 
        j.title.toLowerCase().includes(search.toLowerCase()) && 
        (locationFilter ? j.location.toLowerCase().includes(locationFilter.toLowerCase()) : true)
    );

    return (
        <CandidateLayout>
            <div className="mb-8 flex flex-col md:flex-row gap-4 justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold mb-2">Job Board</h1>
                    <p className="text-slate-400">AI-matched opportunities based on your profile.</p>
                </div>
                <div className="flex gap-4 w-full md:w-auto">
                    <Input placeholder="Search roles..." value={search} onChange={e=>setSearch(e.target.value)} className="bg-slate-900 border-white/10 text-white min-w-[200px]" />
                    <select value={locationFilter} onChange={e=>setLocationFilter(e.target.value)} className="bg-slate-900 border border-white/10 rounded-md px-3 text-white outline-none">
                        <option value="">All Locations</option>
                        <option value="Cape Town">Cape Town</option>
                        <option value="Johannesburg">Johannesburg</option>
                        <option value="Remote">Remote</option>
                    </select>
                </div>
            </div>

            {filtered.length === 0 ? (
                <div className="text-center p-12 bg-slate-900 rounded-xl border border-white/10">
                    <p className="text-slate-400">No jobs found. Try adjusting your filters.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {filtered.map(job => (
                        <div key={job.id} className="bg-slate-900 border border-white/10 rounded-xl p-6 hover:border-[#00D9FF]/40 transition-colors flex flex-col relative overflow-hidden">
                            <div className="absolute top-0 right-0 bg-[#00D9FF]/10 text-[#00D9FF] text-xs font-bold px-3 py-1 rounded-bl-lg flex items-center gap-1">
                                <Zap className="w-3 h-3" /> {job.matchScore}% Match
                            </div>
                            <h3 className="text-lg font-bold text-white mb-1 pr-16">{job.title}</h3>
                            <p className="text-[#00D9FF] font-medium text-sm mb-4">{job.company}</p>
                            <div className="flex flex-wrap gap-2 text-xs text-slate-400 mb-6">
                                <span className="flex items-center bg-slate-950 px-2 py-1 rounded border border-white/5"><MapPin className="w-3 h-3 mr-1" /> {job.location}</span>
                                <span className="flex items-center bg-slate-950 px-2 py-1 rounded border border-white/5"><Briefcase className="w-3 h-3 mr-1" /> {job.type}</span>
                                <span className="flex items-center bg-slate-950 px-2 py-1 rounded border border-white/5 font-mono text-emerald-400">{job.salary}</span>
                            </div>
                            <div className="flex gap-3 mt-auto">
                                <Link to={`/candidates/portal/jobs/${job.id}`} className="flex-1">
                                    <Button className="w-full bg-[#00D9FF] text-slate-950 font-bold hover:bg-[#00D9FF]/90">View Details</Button>
                                </Link>
                                <Button variant="outline" onClick={() => saveJob(job)} className={`border-white/10 p-3 ${isJobSaved(job.id) ? 'text-red-500 bg-red-500/10 border-red-500/20' : 'text-slate-400'}`}>
                                    <Heart className="w-5 h-5" fill={isJobSaved(job.id) ? "currentColor" : "none"} />
                                </Button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </CandidateLayout>
    );
};
export default CandidatePortalJobBoard;
