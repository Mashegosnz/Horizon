
import React from 'react';
import CandidateLayout from '../CandidateLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FileText, MonitorPlay, Users, Award, Download, Play, Calendar } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export const CandidateCVBuilder = () => {
    return (
        <CandidateLayout>
            <h1 className="text-3xl font-bold mb-2">CV Builder</h1>
            <p className="text-slate-400 mb-8">Create an ATS-friendly, professional resume.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[1,2,3].map(i => (
                    <Card key={i} className="bg-slate-900 border-white/10 overflow-hidden">
                        <div className="h-40 bg-slate-800 flex items-center justify-center"><FileText className="w-12 h-12 text-slate-600" /></div>
                        <CardContent className="p-4 text-center">
                            <h3 className="font-bold text-white mb-4">Template {i}</h3>
                            <Button className="w-full bg-[#00D9FF] text-slate-950 font-bold">Use Template</Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </CandidateLayout>
    );
};

export const CandidateInterviewPrep = () => {
    return (
        <CandidateLayout>
            <h1 className="text-3xl font-bold mb-2">Interview Prep</h1>
            <p className="text-slate-400 mb-8">Practice with our AI interviewer.</p>
            <div className="bg-slate-900 border border-white/10 rounded-2xl p-8 text-center max-w-2xl mx-auto mt-12">
                <div className="w-20 h-20 bg-[#00D9FF]/10 rounded-full flex items-center justify-center mx-auto mb-6"><MonitorPlay className="w-10 h-10 text-[#00D9FF]" /></div>
                <h2 className="text-2xl font-bold text-white mb-4">Start Mock Interview</h2>
                <p className="text-slate-400 mb-8">The AI will ask you 5 common behavioral questions and record your responses for analysis.</p>
                <Button size="lg" className="bg-[#00D9FF] text-slate-950 font-bold px-8"><Play className="w-4 h-4 mr-2" /> Start Session</Button>
            </div>
        </CandidateLayout>
    );
};

export const CandidateCoaching = () => {
    const { toast } = useToast();
    return (
        <CandidateLayout>
            <h1 className="text-3xl font-bold mb-2">Career Coaching</h1>
            <p className="text-slate-400 mb-8">Book 1-on-1 sessions with HR experts.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {['Sarah Jenkins', 'Michael Ndlovu', 'Elena Rust'].map((c,i) => (
                    <Card key={i} className="bg-slate-900 border-white/10">
                        <CardContent className="p-6 text-center">
                            <div className="w-20 h-20 rounded-full bg-slate-800 mx-auto mb-4 border-2 border-[#00D9FF]" />
                            <h3 className="font-bold text-white text-lg">{c}</h3>
                            <p className="text-[#00D9FF] text-sm mb-4">Tech Career Specialist</p>
                            <Button variant="outline" className="w-full border-white/10 text-white hover:bg-white/5" onClick={()=>toast({title:"Redirecting",description:"Opening booking calendar..."})}><Calendar className="w-4 h-4 mr-2" /> Book Session</Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </CandidateLayout>
    );
};

export const CandidateSkillsAssessments = () => {
    return (
        <CandidateLayout>
            <h1 className="text-3xl font-bold mb-2">Available Assessments</h1>
            <p className="text-slate-400 mb-8">Prove your skills to boost your match score.</p>
            <div className="space-y-4">
                {['React Framework', 'Advanced JavaScript', 'Project Management PMP', 'UI/UX Principles'].map((a,i) => (
                    <div key={i} className="p-6 bg-slate-900 border border-white/10 rounded-xl flex flex-col md:flex-row justify-between items-center gap-4">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center"><Award className="text-[#00D9FF]" /></div>
                            <div>
                                <h3 className="font-bold text-white text-lg">{a}</h3>
                                <p className="text-slate-400 text-sm">20 mins • Multiple Choice</p>
                            </div>
                        </div>
                        <Button className="bg-white text-slate-950 font-bold hover:bg-slate-200 w-full md:w-auto">Start Test</Button>
                    </div>
                ))}
            </div>
        </CandidateLayout>
    );
};
