
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import CandidateLayout from '../CandidateLayout';
import { Button } from '@/components/ui/button';
import { MapPin, Briefcase, Calendar, CheckCircle, ArrowLeft } from 'lucide-react';

const CandidateJobDetail = () => {
    const { jobId } = useParams();
    const { allJobs } = useCandidate();
    const job = allJobs.find(j => j.id === jobId);

    if (!job) return <CandidateLayout><div className="p-12 text-center text-white">Job not found.</div></CandidateLayout>;

    return (
        <CandidateLayout>
            <Link to="/candidates/portal/jobs" className="text-[#00D9FF] text-sm flex items-center mb-6 hover:underline"><ArrowLeft className="w-4 h-4 mr-1" /> Back to Jobs</Link>
            
            <div className="bg-slate-900 border border-white/10 rounded-2xl p-8 mb-8">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-white mb-2">{job.title}</h1>
                        <p className="text-xl text-[#00D9FF]">{job.company}</p>
                    </div>
                    <Link to={`/candidates/portal/jobs/${job.id}/apply`}>
                        <Button size="lg" className="bg-[#00D9FF] text-slate-950 font-bold px-8">Apply Now</Button>
                    </Link>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-6 border-y border-white/10 mb-8">
                    <div><div className="text-slate-500 text-xs mb-1">Location</div><div className="flex items-center text-white"><MapPin className="w-4 h-4 mr-2 text-slate-400" />{job.location}</div></div>
                    <div><div className="text-slate-500 text-xs mb-1">Job Type</div><div className="flex items-center text-white"><Briefcase className="w-4 h-4 mr-2 text-slate-400" />{job.type}</div></div>
                    <div><div className="text-slate-500 text-xs mb-1">Salary</div><div className="flex items-center text-emerald-400 font-mono">{job.salary}</div></div>
                    <div><div className="text-slate-500 text-xs mb-1">Posted</div><div className="flex items-center text-white"><Calendar className="w-4 h-4 mr-2 text-slate-400" />{new Date(job.posted).toLocaleDateString()}</div></div>
                </div>

                <div className="space-y-8 text-slate-300">
                    <section>
                        <h3 className="text-xl font-bold text-white mb-4">Role Overview</h3>
                        <p className="leading-relaxed">{job.description}</p>
                    </section>
                    <section>
                        <h3 className="text-xl font-bold text-white mb-4">Requirements</h3>
                        <ul className="space-y-2">
                            {job.requirements.map((r,i) => <li key={i} className="flex items-start"><CheckCircle className="w-5 h-5 text-[#00D9FF] mr-3 shrink-0" />{r}</li>)}
                        </ul>
                    </section>
                    <section>
                        <h3 className="text-xl font-bold text-white mb-4">Benefits</h3>
                        <ul className="space-y-2">
                            {job.benefits.map((b,i) => <li key={i} className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-500 mr-3 shrink-0" />{b}</li>)}
                        </ul>
                    </section>
                </div>
            </div>
        </CandidateLayout>
    );
};
export default CandidateJobDetail;
