
import React from 'react';
import CandidateLayout from '../CandidateLayout';
import { useCandidate } from '@/context/CandidateContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { FileText, Calendar, Bookmark, MessageSquare, Award, Bell, Folder, Trash2, ArrowRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export const CandidateApplications = () => {
    const { applications } = useCandidate();
    return (
        <CandidateLayout>
            <h1 className="text-2xl font-bold mb-6">My Applications</h1>
            <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
                {applications.length === 0 ? <div className="p-8 text-center text-slate-500">No applications yet.</div> : (
                    <table className="w-full text-left text-sm text-slate-300">
                        <thead className="bg-slate-950 text-slate-400"><tr><th className="p-4">Role</th><th className="p-4">Company</th><th className="p-4">Status</th><th className="p-4">Date Applied</th><th className="p-4 text-right">Action</th></tr></thead>
                        <tbody className="divide-y divide-white/10">
                            {applications.map(app => (
                                <tr key={app.id} className="hover:bg-white/5 transition-colors">
                                    <td className="p-4 font-bold text-white">{app.jobTitle}</td><td className="p-4">{app.company}</td>
                                    <td className="p-4"><span className="px-2 py-1 rounded bg-[#00D9FF]/10 text-[#00D9FF] text-xs font-bold">{app.status}</span></td>
                                    <td className="p-4">{new Date(app.appliedDate).toLocaleDateString()}</td>
                                    <td className="p-4 text-right"><Link to={`/candidates/portal/jobs/${app.jobId}`}><Button size="sm" variant="outline" className="border-white/10">View Job</Button></Link></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </CandidateLayout>
    );
};

export const CandidateSavedJobs = () => {
    const { savedJobs, saveJob } = useCandidate();
    return (
        <CandidateLayout>
            <h1 className="text-2xl font-bold mb-6">Saved Jobs</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {savedJobs.length === 0 ? <div className="col-span-full p-8 text-center text-slate-500 border border-white/10 rounded-xl bg-slate-900">No saved jobs.</div> : 
                    savedJobs.map(job => (
                        <Card key={job.id} className="bg-slate-900 border-white/10">
                            <CardContent className="p-6">
                                <h3 className="font-bold text-white text-lg">{job.title}</h3>
                                <p className="text-[#00D9FF] text-sm mb-4">{job.company}</p>
                                <div className="flex gap-2 mt-4">
                                    <Link to={`/candidates/portal/jobs/${job.id}`} className="flex-1"><Button className="w-full bg-[#00D9FF] text-slate-950 font-bold">Apply</Button></Link>
                                    <Button variant="outline" className="border-white/10 text-red-400" onClick={() => saveJob(job)}><Trash2 className="w-4 h-4" /></Button>
                                </div>
                            </CardContent>
                        </Card>
                    ))
                }
            </div>
        </CandidateLayout>
    );
};

export const CandidateMessages = () => {
    const { messages } = useCandidate();
    return (
        <CandidateLayout>
            <h1 className="text-2xl font-bold mb-6">Messages</h1>
            <div className="space-y-4">
                {messages.map(m => (
                    <div key={m.id} className={`p-4 rounded-xl border flex justify-between items-center ${m.unread ? 'bg-slate-800 border-[#00D9FF]/50' : 'bg-slate-900 border-white/10'}`}>
                        <div className="flex gap-4 items-center">
                            <div className="w-10 h-10 rounded-full bg-slate-950 flex items-center justify-center border border-white/5"><MessageSquare className="w-5 h-5 text-slate-400" /></div>
                            <div><div className={`text-white ${m.unread ? 'font-bold' : ''}`}>{m.sender}</div><div className="text-sm text-slate-400">{m.subject}</div></div>
                        </div>
                        <Button variant="outline" size="sm" className="border-white/10">Reply</Button>
                    </div>
                ))}
            </div>
        </CandidateLayout>
    );
};

export const CandidateInterviews = () => {
    const { interviews } = useCandidate();
    return (
        <CandidateLayout>
            <h1 className="text-2xl font-bold mb-6">Interviews</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {interviews.map(i => (
                    <Card key={i.id} className="bg-slate-900 border-white/10">
                        <CardContent className="p-6 flex items-start gap-4">
                            <div className="w-12 h-12 bg-[#00D9FF]/10 rounded flex items-center justify-center shrink-0"><Calendar className="w-6 h-6 text-[#00D9FF]" /></div>
                            <div className="flex-1">
                                <h3 className="font-bold text-white text-lg">{i.company}</h3>
                                <p className="text-slate-400 text-sm">{i.role}</p>
                                <div className="mt-4 pt-4 border-t border-white/5 text-sm flex justify-between text-white">
                                    <span>{new Date(i.date).toLocaleString()}</span>
                                    <span className="text-emerald-400">{i.type}</span>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </CandidateLayout>
    );
};

export const CandidateDocuments = () => {
    const { documents } = useCandidate();
    return (
        <CandidateLayout>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Document Vault</h1>
                <Button className="bg-[#00D9FF] text-slate-950">Upload File</Button>
            </div>
            <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
                <table className="w-full text-left text-sm text-slate-300">
                    <thead className="bg-slate-950 text-slate-400"><tr><th className="p-4">Name</th><th className="p-4">Type</th><th className="p-4">Date Added</th><th className="p-4 text-right">Actions</th></tr></thead>
                    <tbody className="divide-y divide-white/10">
                        {documents.map(d => (
                            <tr key={d.id} className="hover:bg-white/5">
                                <td className="p-4 font-medium text-white flex items-center gap-2"><Folder className="w-4 h-4 text-slate-500" />{d.name}</td>
                                <td className="p-4">{d.type}</td><td className="p-4">{new Date(d.uploadDate).toLocaleDateString()}</td>
                                <td className="p-4 text-right flex justify-end gap-2"><Button size="sm" variant="outline" className="border-white/10">Download</Button><Button size="sm" variant="outline" className="border-white/10 text-red-400"><Trash2 className="w-4 h-4" /></Button></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </CandidateLayout>
    );
};

export const CandidateAssessments = () => {
    const { assessments } = useCandidate();
    return (
        <CandidateLayout>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Skills Assessments</h1>
                <Link to="/candidates/portal/assessments"><Button className="bg-[#00D9FF] text-slate-950">Take New</Button></Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {assessments.map(a => (
                    <Card key={a.id} className="bg-slate-900 border-white/10 text-center p-6">
                        <div className="w-16 h-16 mx-auto bg-emerald-500/10 rounded-full flex items-center justify-center mb-4"><Award className="w-8 h-8 text-emerald-500" /></div>
                        <h3 className="font-bold text-white text-lg mb-2">{a.name}</h3>
                        <div className="text-3xl font-black text-[#00D9FF] mb-2">{a.score}%</div>
                        <div className="text-sm text-slate-400">Completed on {new Date(a.date).toLocaleDateString()}</div>
                    </Card>
                ))}
            </div>
        </CandidateLayout>
    );
};

export const CandidateNotifications = () => {
    const { notifications } = useCandidate();
    return (
        <CandidateLayout>
            <h1 className="text-2xl font-bold mb-6">Notifications</h1>
            <div className="bg-slate-900 border border-white/10 rounded-xl divide-y divide-white/10">
                {notifications.map(n => (
                    <div key={n.id} className={`p-4 flex items-center justify-between ${!n.read ? 'bg-white/5' : ''}`}>
                        <div className="flex items-center gap-4">
                            <div className={`w-2 h-2 rounded-full ${!n.read ? 'bg-[#00D9FF]' : 'bg-transparent'}`} />
                            <div><div className="text-white font-medium">{n.title}</div><div className="text-sm text-slate-400">{n.message}</div></div>
                        </div>
                        <div className="text-xs text-slate-500">{new Date(n.date).toLocaleDateString()}</div>
                    </div>
                ))}
            </div>
        </CandidateLayout>
    );
};

export const CandidateProfileEdit = () => {
    const { candidateUser } = useCandidate();
    const { toast } = useToast();
    return (
        <CandidateLayout>
            <h1 className="text-2xl font-bold mb-6">Edit Profile</h1>
            <div className="bg-slate-900 border border-white/10 rounded-xl p-8 max-w-2xl">
                <div className="space-y-4 text-white">
                    <div><label className="text-slate-400 text-sm">Full Name</label><input className="w-full bg-slate-950 border border-white/10 rounded p-3 mt-1" defaultValue={candidateUser?.fullName} /></div>
                    <div><label className="text-slate-400 text-sm">Email</label><input className="w-full bg-slate-950 border border-white/10 rounded p-3 mt-1" defaultValue={candidateUser?.email} disabled /></div>
                    <div><label className="text-slate-400 text-sm">Location</label><input className="w-full bg-slate-950 border border-white/10 rounded p-3 mt-1" defaultValue={candidateUser?.location} /></div>
                    <Button className="mt-4 bg-[#00D9FF] text-slate-950 font-bold" onClick={()=>toast({title:"Saved", description:"Profile updated."})}>Save Changes</Button>
                </div>
            </div>
        </CandidateLayout>
    );
}
