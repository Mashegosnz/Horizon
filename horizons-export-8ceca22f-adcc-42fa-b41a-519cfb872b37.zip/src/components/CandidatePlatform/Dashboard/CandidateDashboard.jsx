
import React from 'react';
import { Link } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import CandidateLayout from '../CandidateLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Briefcase, FileText, Bookmark, MessageSquare, Calendar, Folder, Award, Bell, User } from 'lucide-react';

const CandidateDashboard = () => {
    const { candidateUser, applications, savedJobs, messages, interviews, documents, assessments, notifications } = useCandidate();

    const modules = [
        { title: 'My Profile', icon: User, data: `${candidateUser?.completeness || 20}% Complete`, link: '/candidates/dashboard/profile', btn: 'Edit Profile' },
        { title: 'Applications', icon: FileText, data: `${applications.length} submitted`, link: '/candidates/dashboard/applications', btn: 'View Applications' },
        { title: 'Saved Jobs', icon: Bookmark, data: `${savedJobs.length} saved`, link: '/candidates/dashboard/saved-jobs', btn: 'View Saved Jobs' },
        { title: 'Messages', icon: MessageSquare, data: `${messages.filter(m=>m.unread).length} unread`, link: '/candidates/dashboard/messages', btn: 'View Messages' },
        { title: 'Interviews', icon: Calendar, data: `${interviews.length} scheduled`, link: '/candidates/dashboard/interviews', btn: 'View Schedule' },
        { title: 'Documents', icon: Folder, data: `${documents.length} stored`, link: '/candidates/dashboard/documents', btn: 'Access Vault' },
        { title: 'Assessments', icon: Award, data: `${assessments.length} completed`, link: '/candidates/dashboard/assessments', btn: 'View Assessments' },
        { title: 'Notifications', icon: Bell, data: `${notifications.filter(n=>!n.read).length} new`, link: '/candidates/dashboard/notifications', btn: 'View All' },
    ];

    return (
        <CandidateLayout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold mb-2">Welcome back, {candidateUser?.fullName?.split(' ')[0] || 'Candidate'}!</h1>
                <p className="text-slate-400">Here's an overview of your career journey.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {modules.map((m, i) => (
                    <Card key={i} className="bg-slate-900 border-white/10 flex flex-col h-full hover:border-[#00D9FF]/40 transition-colors">
                        <CardHeader className="pb-2">
                            <div className="w-10 h-10 rounded bg-[#00D9FF]/10 flex items-center justify-center mb-2"><m.icon className="w-5 h-5 text-[#00D9FF]" /></div>
                            <CardTitle className="text-lg text-white">{m.title}</CardTitle>
                        </CardHeader>
                        <CardContent className="flex-grow flex flex-col justify-between">
                            <p className="text-2xl font-bold text-white mb-6">{m.data}</p>
                            <Link to={m.link}>
                                <Button variant="outline" className="w-full border-white/10 hover:bg-white/5 text-white">{m.btn}</Button>
                            </Link>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <div className="mt-12 p-8 bg-gradient-to-r from-slate-900 to-[#00D9FF]/5 border border-[#00D9FF]/20 rounded-2xl flex flex-col md:flex-row justify-between items-center gap-6">
                <div>
                    <h3 className="text-xl font-bold text-white mb-2">Ready for your next move?</h3>
                    <p className="text-slate-400">Our AI has found new jobs matching your profile.</p>
                </div>
                <Link to="/candidates/portal/jobs">
                    <Button className="bg-[#00D9FF] text-slate-950 font-bold px-8">Discover Matches</Button>
                </Link>
            </div>
        </CandidateLayout>
    );
};
export default CandidateDashboard;
