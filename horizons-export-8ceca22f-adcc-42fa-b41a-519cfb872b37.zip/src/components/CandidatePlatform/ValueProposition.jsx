import React from 'react';
import { motion } from 'framer-motion';
import { FileText, UserCheck, Network, ShieldCheck, Sparkles, TrendingUp } from 'lucide-react';

const Card = ({ icon: Icon, title, description, delay }) => (
  <motion.div
    className="relative group p-8 rounded-2xl bg-charcoal/50 border border-white/5 hover:border-electric-cyan/50 backdrop-blur-sm transition-all duration-500 hover:shadow-[0_0_30px_rgba(0,217,255,0.15)] hover:-translate-y-2"
    initial={{ opacity: 0, y: 50 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6, delay }}
  >
    <div className="absolute inset-0 bg-gradient-to-br from-electric-cyan/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
    
    <div className="relative z-10">
      <div className="w-16 h-16 rounded-xl bg-deep-space border border-white/10 flex items-center justify-center mb-6 group-hover:border-electric-cyan group-hover:shadow-[0_0_15px_rgba(0,217,255,0.4)] transition-all duration-300">
        <Icon className="w-8 h-8 text-electric-cyan" />
      </div>
      
      <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-electric-cyan transition-colors">{title}</h3>
      <p className="text-metallic-silver leading-relaxed group-hover:text-white/90 transition-colors">
        {description}
      </p>
    </div>
  </motion.div>
);

const ValueProposition = () => {
  return (
    <section className="py-24 bg-charcoal relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-deep-space to-transparent opacity-50" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-3xl md:text-5xl font-bold text-white mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Why Choose <span className="text-electric-cyan">Indira?</span>
          </motion.h2>
          <p className="text-metallic-silver text-lg max-w-2xl mx-auto">
            We're reimagining the hiring process to put human potential first.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card 
            icon={UserCheck}
            title="Beyond the Resume"
            description="Paper resumes are flat. You are multi-dimensional. Showcase your personality, communication skills, and passion through video profiling."
            delay={0.1}
          />
          <Card 
            icon={ShieldCheck}
            title="Verified & Authentic"
            description="Build trust instantly with blockchain-verified qualifications and ID checks. Stand out as a verified candidate in a sea of unknowns."
            delay={0.3}
          />
          <Card 
            icon={Network}
            title="Intelligent Matching"
            description="Our AI doesn't just look for keywords. It understands context, potential, and cultural fit to connect you with opportunities you'll love."
            delay={0.5}
          />
        </div>
      </div>
    </section>
  );
};

export default ValueProposition;