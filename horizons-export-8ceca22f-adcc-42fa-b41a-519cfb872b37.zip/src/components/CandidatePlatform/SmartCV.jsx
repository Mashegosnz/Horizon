import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Save, ChevronRight, User, Briefcase, GraduationCap, Phone } from 'lucide-react';

const SmartCV = ({ onNext }) => {
  const [activeSection, setActiveSection] = useState('personal');
  const [data, setData] = useState({
    firstName: '', lastName: '', phone: '', location: '', role: '', skills: ''
  });

  const handleChange = (e) => setData({ ...data, [e.target.name]: e.target.value });

  const renderSection = () => {
    switch(activeSection) {
      case 'personal':
        return (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
            <h3 className="text-xl font-bold text-white mb-4">Personal Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <input name="firstName" placeholder="First Name" value={data.firstName} onChange={handleChange} className="bg-deep-space border border-white/10 rounded-lg p-3 text-white w-full" />
              <input name="lastName" placeholder="Last Name" value={data.lastName} onChange={handleChange} className="bg-deep-space border border-white/10 rounded-lg p-3 text-white w-full" />
            </div>
            <input type="date" className="bg-deep-space border border-white/10 rounded-lg p-3 text-white w-full" />
          </div>
        );
      case 'contact':
        return (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
             <h3 className="text-xl font-bold text-white mb-4">Contact Info</h3>
             <input name="phone" placeholder="Phone Number" value={data.phone} onChange={handleChange} className="bg-deep-space border border-white/10 rounded-lg p-3 text-white w-full" />
             <select name="location" value={data.location} onChange={handleChange} className="bg-deep-space border border-white/10 rounded-lg p-3 text-white w-full">
               <option value="">Select Province</option>
               <option value="Gauteng">Gauteng</option>
               <option value="Western Cape">Western Cape</option>
               <option value="KZN">KwaZulu-Natal</option>
             </select>
          </div>
        );
      case 'experience':
        return (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
             <h3 className="text-xl font-bold text-white mb-4">Work Experience</h3>
             <input name="role" placeholder="Current Role" value={data.role} onChange={handleChange} className="bg-deep-space border border-white/10 rounded-lg p-3 text-white w-full" />
             <textarea placeholder="Key Responsibilities..." className="bg-deep-space border border-white/10 rounded-lg p-3 text-white w-full h-32" />
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 container mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full">
        {/* Left: Progress */}
        <div className="lg:col-span-3 space-y-2">
          <div className="bg-charcoal p-6 rounded-xl border border-white/10">
            <h4 className="text-metallic-silver text-sm uppercase tracking-wider mb-4">Progress</h4>
            <div className="w-full bg-deep-space rounded-full h-2 mb-2">
              <div className="bg-electric-cyan h-2 rounded-full w-1/4 transition-all" />
            </div>
            <p className="text-electric-cyan font-bold text-2xl">25%</p>
          </div>
          <nav className="space-y-1">
            {[
              { id: 'personal', icon: User, label: 'Personal' },
              { id: 'contact', icon: Phone, label: 'Contact' },
              { id: 'experience', icon: Briefcase, label: 'Experience' },
              { id: 'education', icon: GraduationCap, label: 'Education' }
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${activeSection === item.id ? 'bg-electric-cyan text-deep-space font-bold' : 'text-gray-400 hover:bg-white/5'}`}
              >
                <item.icon className="w-4 h-4" /> {item.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Center: Form */}
        <div className="lg:col-span-5 bg-charcoal p-8 rounded-2xl border border-white/10 shadow-xl relative">
           <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-electric-cyan to-transparent rounded-t-2xl" />
           {renderSection()}
           <div className="mt-8 flex justify-between">
             <Button variant="ghost" className="text-gray-400 hover:text-white"> <Save className="w-4 h-4 mr-2" /> Save Draft</Button>
             <Button onClick={onNext} className="bg-electric-cyan text-deep-space hover:bg-neon-blue font-bold">Next Step <ChevronRight className="w-4 h-4 ml-2" /></Button>
           </div>
        </div>

        {/* Right: Live Preview */}
        <div className="hidden lg:block lg:col-span-4">
          <div className="bg-white text-gray-900 p-8 rounded-xl shadow-2xl h-full min-h-[500px] scale-95 origin-top-right opacity-90">
            <div className="border-b-2 border-gray-100 pb-4 mb-4">
              <h1 className="text-3xl font-bold text-gray-800">{data.firstName || 'Your'} {data.lastName || 'Name'}</h1>
              <p className="text-electric-cyan font-medium text-lg">{data.role || 'Job Title'}</p>
            </div>
            <div className="space-y-4 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4" /> {data.phone || '+27 00 000 0000'}
              </div>
              <div className="flex items-center gap-2">
                <div className="w-full h-px bg-gray-100 my-2" />
              </div>
              <div>
                <h4 className="font-bold text-gray-900 mb-2 uppercase text-xs tracking-wider">Experience</h4>
                <p className="italic text-gray-400">Add your work history to see it appear here.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SmartCV;