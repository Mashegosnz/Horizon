import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Lock, Globe, ArrowRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const languages = [
  "English", "IsiZulu", "IsiXhosa", "Afrikaans", "Sepedi", "Setswana", 
  "Sesotho", "Xitsonga", "SiSwati", "Tshivenda", "IsiNdebele"
];

const CandidateSignUp = ({ onComplete }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    isSALocal: true,
    language: 'English'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      onComplete(formData);
    }, 1500);
  };

  return (
    <div className="min-h-screen pt-20 flex items-center justify-center bg-deep-space p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-charcoal/80 backdrop-blur-md border border-white/10 p-8 rounded-2xl shadow-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-electric-cyan to-neon-blue" />
        
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Create Account</h2>
          <p className="text-metallic-silver">Join 50,000+ South Africans finding work</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Preferred Language</label>
            <div className="relative">
              <Globe className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
              <select 
                className="w-full bg-deep-space border border-white/10 rounded-lg py-2.5 pl-10 pr-4 text-white focus:border-electric-cyan focus:ring-1 focus:ring-electric-cyan transition-colors"
                value={formData.language}
                onChange={(e) => setFormData({...formData, language: e.target.value})}
              >
                {languages.map(l => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
              <input 
                type="email" 
                required
                className="w-full bg-deep-space border border-white/10 rounded-lg py-2.5 pl-10 pr-4 text-white focus:border-electric-cyan focus:ring-1 focus:ring-electric-cyan transition-colors"
                placeholder="you@example.com"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
              <input 
                type="password" 
                required
                className="w-full bg-deep-space border border-white/10 rounded-lg py-2.5 pl-10 pr-4 text-white focus:border-electric-cyan focus:ring-1 focus:ring-electric-cyan transition-colors"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
            <input 
              type="checkbox" 
              className="rounded bg-deep-space border-white/20 text-electric-cyan focus:ring-electric-cyan"
              checked={formData.isSALocal}
              onChange={(e) => setFormData({...formData, isSALocal: e.target.checked})}
            />
            <span className="text-sm text-gray-300">I am looking for work in South Africa</span>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-electric-cyan hover:bg-neon-blue text-deep-space font-bold py-6 rounded-xl transition-all shadow-[0_0_20px_rgba(0,217,255,0.3)] hover:shadow-[0_0_30px_rgba(0,217,255,0.5)]"
            disabled={isLoading}
          >
            {isLoading ? <Loader2 className="animate-spin" /> : "Start My Journey"}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm text-gray-500">
          Looking to hire? <a href="#" className="text-electric-cyan hover:underline">Employer Sign Up</a>
        </div>
      </motion.div>
    </div>
  );
};

export default CandidateSignUp;