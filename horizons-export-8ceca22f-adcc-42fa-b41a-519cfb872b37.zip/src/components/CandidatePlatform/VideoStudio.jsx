import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mic, Video, Circle, Play, RefreshCw, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const VideoStudio = ({ onNext }) => {
  const [recording, setRecording] = useState(false);
  const [timer, setTimer] = useState(120); // 2 minutes
  
  useEffect(() => {
    let interval;
    if (recording && timer > 0) {
      interval = setInterval(() => setTimer(t => t - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [recording, timer]);

  const toggleRecord = () => {
    setRecording(!recording);
    if (!recording) setTimer(120);
  };

  const formatTime = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="min-h-screen pt-24 px-4 container mx-auto max-w-4xl">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white">Video Studio</h2>
        <p className="text-metallic-silver">Answer 3 questions to complete your profile.</p>
      </div>

      <div className="bg-charcoal border border-white/10 rounded-2xl overflow-hidden shadow-2xl relative">
        <div className="aspect-video bg-black relative flex items-center justify-center">
          {/* Simulated Camera View */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/60 z-10" />
          
          {!recording && <div className="z-0 text-gray-600 flex flex-col items-center">
             <Video className="w-16 h-16 mb-2 opacity-50" />
             <p>Camera Preview</p>
          </div>}

          {/* Question Overlay */}
          <div className="absolute top-6 left-6 right-6 z-20">
            <div className="bg-black/60 backdrop-blur-md text-white p-4 rounded-xl border border-white/10">
              <span className="text-electric-cyan text-xs font-bold uppercase tracking-wider mb-1 block">Question 1 of 3</span>
              <h3 className="text-lg md:text-xl font-medium">Tell us about a time you solved a difficult problem at work.</h3>
            </div>
          </div>

          {/* Recording UI */}
          <div className="absolute bottom-6 left-6 right-6 z-20 flex justify-between items-center">
             <div className="flex gap-4">
                <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${recording ? 'bg-red-500/20 text-red-500 border border-red-500/50' : 'bg-white/10 text-gray-400'}`}>
                  <div className={`w-2 h-2 rounded-full ${recording ? 'bg-red-500 animate-pulse' : 'bg-gray-400'}`} />
                  <span className="font-mono text-sm">{formatTime(timer)}</span>
                </div>
             </div>

             <div className="flex gap-4">
                <button 
                  onClick={toggleRecord}
                  className={`w-16 h-16 rounded-full border-4 flex items-center justify-center transition-all ${recording ? 'border-red-500 bg-red-500/20' : 'border-white hover:border-electric-cyan hover:bg-electric-cyan/10'}`}
                >
                  {recording ? <div className="w-6 h-6 bg-red-500 rounded-sm" /> : <div className="w-12 h-12 bg-red-500 rounded-full" />}
                </button>
             </div>

             <div className="flex gap-2">
               <button className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white"><RefreshCw className="w-5 h-5" /></button>
             </div>
          </div>
        </div>

        {/* Studio Controls */}
        <div className="p-6 bg-deep-space flex justify-between items-center">
           <div className="flex gap-4 text-sm text-gray-400">
             <div className="flex items-center gap-2"><Mic className="w-4 h-4 text-green-500" /> Mic Check</div>
             <div className="flex items-center gap-2"><Video className="w-4 h-4 text-green-500" /> Camera Ready</div>
           </div>
           <Button onClick={onNext} className="bg-electric-cyan text-deep-space font-bold hover:bg-neon-blue">
             Next Question <ChevronRight className="w-4 h-4 ml-2" />
           </Button>
        </div>
      </div>
    </div>
  );
};

export default VideoStudio;