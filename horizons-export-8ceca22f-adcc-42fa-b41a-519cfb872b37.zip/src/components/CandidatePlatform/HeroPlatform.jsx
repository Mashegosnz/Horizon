import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Sparkles, Search, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HeroPlatform = ({ onFindJob, onFindTalent }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-deep-space pt-16">
      {/* Dynamic Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-deep-space/80 to-deep-space z-10" />
        <img
          src="https://images.unsplash.com/photo-1493882552576-fce827c6161e"
          alt="Future of Work"
          className="w-full h-full object-cover opacity-50 scale-105 animate-pulse-slow"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-deep-space via-transparent to-deep-space/80 mix-blend-multiply" />
      </div>

      {/* Glowing Orbs */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-electric-cyan/20 rounded-full blur-[100px] animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-neon-blue/20 rounded-full blur-[120px] animate-pulse" />

      <div className="relative z-20 container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-electric-cyan text-sm mb-8 backdrop-blur-sm">
            <Sparkles className="w-4 h-4" />
            <span className="tracking-wide uppercase font-medium">The Future of Hiring is Here</span>
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black mb-6 leading-tight tracking-tight text-white">
            Your Career, <span className="text-transparent bg-clip-text bg-gradient-to-r from-electric-cyan to-neon-blue drop-shadow-[0_0_15px_rgba(0,217,255,0.5)]">Fully Expressed.</span>
            <br />
            Your Potential, <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-purple-500">Fully Seen.</span>
          </h1>

          <p className="text-xl md:text-2xl text-metallic-silver/80 mb-12 max-w-3xl mx-auto font-light leading-relaxed">
            Stop being just a resume. Start being a person. Indira connects authentic talent with visionary companies through intelligent video profiling.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center w-full max-w-4xl mx-auto">
            <Button
              size="xl"
              onClick={onFindJob}
              className="w-full sm:w-auto min-w-[240px] bg-electric-cyan text-deep-space hover:bg-white hover:text-deep-space font-bold py-8 text-lg rounded-xl shadow-[0_0_20px_rgba(0,217,255,0.4)] hover:shadow-[0_0_40px_rgba(0,217,255,0.6)] transition-all duration-300 hover:scale-105"
            >
              <div className="flex items-center justify-center gap-3">
                <Search className="w-5 h-5" />
                Find Your Dream Job
              </div>
            </Button>

            <Button
              size="xl"
              onClick={onFindTalent}
              className="w-full sm:w-auto min-w-[240px] bg-deep-space/50 backdrop-blur-md border border-neon-blue text-neon-blue hover:bg-neon-blue hover:text-white font-bold py-8 text-lg rounded-xl shadow-lg hover:shadow-[0_0_30px_rgba(59,130,246,0.5)] transition-all duration-300 hover:scale-105"
            >
              <div className="flex items-center justify-center gap-3">
                <Users className="w-5 h-5" />
                Find Exceptional Talent
              </div>
            </Button>
          </div>
        </motion.div>
      </div>

      <motion.div
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        transition={{ duration: 2, delay: 1, repeat: Infinity, ease: 'easeInOut' }}
      >
        <ChevronDown className="h-8 w-8 text-electric-cyan animate-pulse" />
      </motion.div>
    </section>
  );
};

export default HeroPlatform;