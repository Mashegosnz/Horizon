import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UserPlus, FileText, Video, BrainCircuit, Users, Briefcase, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const steps = {
  candidate: [
    { id: 1, icon: UserPlus, title: "Sign Up", desc: "Create your free account in seconds." },
    { id: 2, icon: FileText, title: "Smart CV", desc: "Build a comprehensive digital profile." },
    { id: 3, icon: Video, title: "Video Profile", desc: "Record short clips to showcase your personality." },
    { id: 4, icon: BrainCircuit, title: "Get Matched", desc: "AI connects you with ideal roles." },
    { id: 5, icon: Briefcase, title: "Hired", desc: "Land the job and start your journey." },
  ],
  employer: [
    { id: 1, icon: FileText, title: "Post Job", desc: "Define your requirements with AI assistance." },
    { id: 2, icon: Video, title: "View Profiles", desc: "See candidates, not just resumes." },
    { id: 3, icon: BrainCircuit, title: "Review Matches", desc: "AI ranks candidates by fit." },
    { id: 4, icon: Users, title: "Interview", desc: "Meet the top talent directly." },
    { id: 5, icon: CheckCircle, title: "Hire", desc: "Onboard your new team member." },
  ]
};

const HowItWorks = () => {
  const [activeTab, setActiveTab] = useState('candidate');

  return (
    <section className="py-24 bg-deep-space relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">How It Works</h2>
          
          <div className="flex justify-center gap-4 mb-12">
            <button
              onClick={() => setActiveTab('candidate')}
              className={`px-8 py-3 rounded-full text-lg font-medium transition-all duration-300 ${
                activeTab === 'candidate' 
                  ? 'bg-electric-cyan text-deep-space shadow-[0_0_20px_rgba(0,217,255,0.4)]' 
                  : 'bg-white/5 text-metallic-silver hover:bg-white/10'
              }`}
            >
              For Candidates
            </button>
            <button
              onClick={() => setActiveTab('employer')}
              className={`px-8 py-3 rounded-full text-lg font-medium transition-all duration-300 ${
                activeTab === 'employer' 
                  ? 'bg-neon-blue text-white shadow-[0_0_20px_rgba(59,130,246,0.4)]' 
                  : 'bg-white/5 text-metallic-silver hover:bg-white/10'
              }`}
            >
              For Employers
            </button>
          </div>
        </div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-0 w-full h-1 bg-white/10 -translate-y-1/2 hidden md:block" />
          
          <div className="grid grid-cols-1 md:grid-cols-5 gap-8 relative z-10">
            <AnimatePresence mode='wait'>
              {steps[activeTab].map((step, index) => (
                <motion.div
                  key={`${activeTab}-${step.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: index * 0.1 }}
                  className="group relative"
                >
                  <div className="bg-charcoal/80 border border-white/10 p-6 rounded-2xl backdrop-blur-sm hover:border-electric-cyan/50 hover:bg-charcoal transition-all duration-300 h-full flex flex-col items-center text-center">
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 transition-all duration-300 ${
                      activeTab === 'candidate' 
                        ? 'bg-deep-space text-electric-cyan group-hover:shadow-[0_0_15px_rgba(0,217,255,0.5)]' 
                        : 'bg-deep-space text-neon-blue group-hover:shadow-[0_0_15px_rgba(59,130,246,0.5)]'
                    }`}>
                      <step.icon className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{step.title}</h3>
                    <p className="text-sm text-metallic-silver/80">{step.desc}</p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;