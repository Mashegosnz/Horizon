import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, CheckCircle, Upload, FileText, Check } from 'lucide-react';
import { motion } from 'framer-motion';

const CandidateApplicationForm = () => {
  const { jobId } = useParams();
  const { allJobs, applyToJob, candidateUser } = useCandidate();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [motivation, setMotivation] = useState('');
  const [file, setFile] = useState(null);
  const [confirmed, setConfirmed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const job = allJobs.find(j => j.id === jobId);

  if (!job) return <div className="p-10 text-center text-white">Job not found</div>;

  const handleFileChange = (e) => {
    const selected = e.target.files[0];
    if (selected && selected.size > 5 * 1024 * 1024) {
        toast({ title: "File too large", description: "Max 5MB allowed.", variant: "destructive" });
        return;
    }
    setFile(selected);
  };

  const handleSubmit = async () => {
      setLoading(true);
      try {
          // Simulate upload delay
          await new Promise(resolve => setTimeout(resolve, 1500));
          
          applyToJob(job, {
              motivation,
              cvFile: file ? file.name : 'Existing Profile CV'
          });
          
          setSuccess(true);
          setLoading(false);
      } catch (err) {
          toast({ title: "Error", description: "Failed to submit application.", variant: "destructive" });
          setLoading(false);
      }
  };

  if (success) {
      return (
          <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
              <motion.div 
                 initial={{ scale: 0.9, opacity: 0 }}
                 animate={{ scale: 1, opacity: 1 }}
                 className="bg-slate-900 border border-white/10 rounded-2xl p-8 max-w-lg w-full text-center shadow-2xl"
              >
                  <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-emerald-500">
                      <CheckCircle className="w-10 h-10" />
                  </div>
                  <h2 className="text-3xl font-bold text-white mb-2">Application Submitted!</h2>
                  <p className="text-slate-400 mb-6">
                      You've successfully applied for <strong className="text-white">{job.title}</strong> at <strong className="text-white">{job.company}</strong>.
                  </p>
                  
                  <div className="bg-slate-950 p-4 rounded-xl border border-white/5 mb-8 text-sm text-slate-400">
                      We'll review your application and get back to you soon. You can track your status in your dashboard.
                  </div>

                  <div className="flex flex-col gap-3">
                      <Link to="/candidate-dashboard/applications">
                          <Button className="w-full h-12 bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 font-bold">View Your Applications</Button>
                      </Link>
                      <Link to="/candidate-jobs">
                          <Button variant="outline" className="w-full border-white/10">Back to Jobs</Button>
                      </Link>
                  </div>
              </motion.div>
          </div>
      )
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-4 py-12">
       <div className="max-w-2xl w-full bg-slate-900 border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
           <div className="p-6 border-b border-white/10 flex items-center gap-4 bg-slate-900">
               <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="text-slate-400 hover:text-white">
                   <ArrowLeft className="w-5 h-5" />
               </Button>
               <div>
                   <h1 className="text-xl font-bold text-white">Apply for {job.title}</h1>
                   <div className="text-sm text-slate-400">{job.company} • {job.location}</div>
               </div>
           </div>

           <div className="p-8 space-y-8">
               {/* CV Section */}
               <section>
                   <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                       <FileText className="w-5 h-5 text-[#00D9FF]" /> Resume / CV
                   </h3>
                   <div className="bg-slate-950 border border-white/10 rounded-xl p-4">
                       <div className="flex justify-between items-center mb-4">
                           <div className="text-sm text-slate-300">
                               {file ? (
                                   <span className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> {file.name}</span>
                               ) : (
                                   <span>Using profile CV: <strong>John_Doe_CV.pdf</strong></span>
                               )}
                           </div>
                           <label className="cursor-pointer">
                               <input type="file" className="hidden" accept=".pdf,.doc,.docx" onChange={handleFileChange} />
                               <span className="text-xs text-[#00D9FF] hover:underline font-bold">Upload New</span>
                           </label>
                       </div>
                       <p className="text-xs text-slate-500">Accepted formats: PDF, DOC, DOCX (Max 5MB)</p>
                   </div>
               </section>

               {/* Motivation */}
               <section>
                   <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                       <FileText className="w-5 h-5 text-[#00D9FF]" /> Motivation (Optional)
                   </h3>
                   <textarea 
                       className="w-full h-32 bg-slate-950 border border-white/10 rounded-xl p-4 text-white text-sm focus:border-[#00D9FF] outline-none resize-none"
                       placeholder="Why are you a good fit for this role?"
                       value={motivation}
                       onChange={(e) => setMotivation(e.target.value)}
                       maxLength={1000}
                   />
                   <div className="text-right text-xs text-slate-500 mt-1">{motivation.length}/1000</div>
               </section>

               {/* Confirmation */}
               <section>
                   <label className="flex items-start gap-3 cursor-pointer p-4 bg-slate-950 border border-white/10 rounded-xl hover:border-[#00D9FF]/30 transition-colors">
                       <input 
                          type="checkbox" 
                          checked={confirmed} 
                          onChange={(e) => setConfirmed(e.target.checked)} 
                          className="mt-1 accent-[#00D9FF] w-4 h-4"
                       />
                       <span className="text-sm text-slate-300">
                           I confirm that the information provided is accurate and I agree to share my profile with {job.company} for the purpose of this application.
                       </span>
                   </label>
               </section>

               <div className="pt-4">
                   <Button 
                      className="w-full h-12 text-lg bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 font-bold shadow-[0_0_20px_rgba(0,217,255,0.2)] disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={!confirmed || loading}
                      onClick={handleSubmit}
                   >
                       {loading ? 'Submitting Application...' : 'Submit Application'}
                   </Button>
               </div>
           </div>
       </div>
    </div>
  );
};

export default CandidateApplicationForm;