import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { MapPin, Briefcase, DollarSign, Clock, Calendar, Heart, Share2, ArrowLeft, Building, CheckCircle } from 'lucide-react';

const CandidateJobDetail = () => {
  const { jobId } = useParams();
  const { allJobs, saveJob, isJobSaved } = useCandidate();
  const { toast } = useToast();
  const navigate = useNavigate();

  const job = allJobs.find(j => j.id === jobId);

  if (!job) return <div className="p-10 text-center text-white">Job not found</div>;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({ title: "Link Copied", description: "Job link copied to clipboard." });
  };

  const relatedJobs = allJobs.filter(j => j.industry === job.industry && j.id !== job.id).slice(0, 3);

  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
       {/* Header */}
       <div className="bg-slate-900 border-b border-white/10 py-8 px-4">
           <div className="container mx-auto max-w-5xl">
               <Link to="/candidate-jobs" className="text-slate-400 hover:text-white text-sm flex items-center gap-2 mb-6">
                   <ArrowLeft className="w-4 h-4" /> Back to Jobs
               </Link>
               
               <div className="flex flex-col md:flex-row justify-between items-start gap-6">
                   <div>
                       <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{job.title}</h1>
                       <div className="flex items-center gap-2 text-lg text-slate-300 mb-4">
                           <Building className="w-5 h-5 text-[#00D9FF]" />
                           {job.company}
                       </div>
                       
                       <div className="flex flex-wrap gap-4 text-sm text-slate-400">
                           <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {job.location}</span>
                           <span className="flex items-center gap-1"><Briefcase className="w-4 h-4" /> {job.type}</span>
                           <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {job.workArrangement}</span>
                           <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> Posted {job.posted}</span>
                       </div>
                   </div>

                   <div className="flex flex-col gap-3 w-full md:w-auto">
                       <Link to={`/candidate-jobs/${job.id}/apply`}>
                          <Button className="w-full md:w-auto bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 font-bold px-8 h-12 text-lg shadow-[0_0_20px_rgba(0,217,255,0.3)]">
                              Apply Now
                          </Button>
                       </Link>
                       <div className="flex gap-3">
                           <Button 
                              variant="outline" 
                              className={`flex-1 border-white/10 ${isJobSaved(job.id) ? 'text-pink-500 border-pink-500/50' : 'text-slate-300'}`}
                              onClick={() => saveJob(job)}
                           >
                               <Heart className={`w-4 h-4 mr-2 ${isJobSaved(job.id) ? 'fill-current' : ''}`} /> {isJobSaved(job.id) ? 'Saved' : 'Save'}
                           </Button>
                           <Button variant="outline" className="flex-1 border-white/10 text-slate-300" onClick={handleShare}>
                               <Share2 className="w-4 h-4 mr-2" /> Share
                           </Button>
                       </div>
                   </div>
               </div>
           </div>
       </div>

       <div className="container mx-auto max-w-5xl px-4 py-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
           {/* Main Content */}
           <div className="lg:col-span-2 space-y-10">
               <section>
                   <h2 className="text-xl font-bold text-white mb-4">About the Job</h2>
                   <div className="text-slate-300 leading-relaxed whitespace-pre-line">
                       {job.description}
                   </div>
               </section>

               <section>
                   <h2 className="text-xl font-bold text-white mb-4">Requirements</h2>
                   <ul className="space-y-2">
                       {job.requirements?.map((req, i) => (
                           <li key={i} className="flex items-start gap-3 text-slate-300">
                               <div className="w-1.5 h-1.5 rounded-full bg-[#00D9FF] mt-2 flex-shrink-0" />
                               {req}
                           </li>
                       )) || <li className="text-slate-500">No specific requirements listed.</li>}
                   </ul>
               </section>

               <section>
                   <h2 className="text-xl font-bold text-white mb-4">Benefits</h2>
                   <div className="flex flex-wrap gap-3">
                       {job.benefits?.map((ben, i) => (
                           <div key={i} className="bg-slate-900 border border-white/10 px-4 py-2 rounded-full text-sm text-slate-300 flex items-center gap-2">
                               <CheckCircle className="w-4 h-4 text-emerald-500" /> {ben}
                           </div>
                       )) || <div className="text-slate-500">No benefits listed.</div>}
                   </div>
               </section>
               
               <div className="pt-8 border-t border-white/10">
                   <h3 className="text-lg font-bold text-white mb-2">About {job.company}</h3>
                   <p className="text-slate-400 text-sm leading-relaxed">
                       {job.company} is a leading player in the {job.industry} sector, committed to innovation and excellence. Join a team that values growth and impact.
                   </p>
               </div>
           </div>

           {/* Sidebar / Related */}
           <div className="space-y-8">
               <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
                   <h3 className="font-bold text-white mb-4">Job Overview</h3>
                   <div className="space-y-4">
                       <div className="flex justify-between border-b border-white/5 pb-3">
                           <span className="text-slate-400 text-sm">Salary</span>
                           <span className="text-emerald-400 font-bold text-sm">{job.salary}</span>
                       </div>
                       <div className="flex justify-between border-b border-white/5 pb-3">
                           <span className="text-slate-400 text-sm">Industry</span>
                           <span className="text-white text-sm">{job.industry}</span>
                       </div>
                       <div className="flex justify-between border-b border-white/5 pb-3">
                           <span className="text-slate-400 text-sm">Job Type</span>
                           <span className="text-white text-sm">{job.type}</span>
                       </div>
                       <div className="flex justify-between">
                           <span className="text-slate-400 text-sm">Location</span>
                           <span className="text-white text-sm">{job.location}</span>
                       </div>
                   </div>
               </div>

               <div>
                   <h3 className="font-bold text-white mb-4">Related Jobs</h3>
                   <div className="space-y-4">
                       {relatedJobs.map(related => (
                           <div key={related.id} className="bg-slate-900 border border-white/10 p-4 rounded-xl hover:border-[#00D9FF]/30 transition-colors group cursor-pointer" onClick={() => navigate(`/candidate-jobs/${related.id}`)}>
                               <div className="font-bold text-white text-sm group-hover:text-[#00D9FF] transition-colors">{related.title}</div>
                               <div className="text-slate-500 text-xs mb-2">{related.company}</div>
                               <div className="flex justify-between items-center">
                                   <span className="text-xs text-emerald-500">{related.salary}</span>
                                   <span className="text-[10px] text-slate-400">{related.location}</span>
                               </div>
                           </div>
                       ))}
                       {relatedJobs.length === 0 && <div className="text-slate-500 text-sm">No related jobs found.</div>}
                   </div>
               </div>
           </div>
       </div>
    </div>
  );
};

export default CandidateJobDetail;