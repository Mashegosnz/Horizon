import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/components/ui/use-toast';
import { Search, MapPin, Briefcase, Heart, Filter, X, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const CandidateJobSearch = () => {
  const { allJobs, saveJob, isJobSaved } = useCandidate();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    location: [],
    jobType: [],
    workArrangement: [],
    salaryRange: [20000, 200000],
    industry: []
  });
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);
  const [savedSearchName, setSavedSearchName] = useState('');

  // Filter Options
  const LOCATIONS = ['Johannesburg', 'Cape Town', 'Durban', 'Pretoria', 'Remote', 'Sandton'];
  const JOB_TYPES = ['Full-time', 'Part-time', 'Contract', 'Fixed Term', 'Freelance'];
  const WORK_ARRANGEMENTS = ['On-site', 'Hybrid', 'Remote'];
  const INDUSTRIES = ['Technology', 'Finance', 'Healthcare', 'Retail', 'Design', 'Data Science', 'Marketing', 'Construction', 'Legal'];

  useEffect(() => {
    let result = allJobs;

    if (searchTerm) {
      const lower = searchTerm.toLowerCase();
      result = result.filter(job => 
        job.title.toLowerCase().includes(lower) || 
        job.company.toLowerCase().includes(lower)
      );
    }

    if (filters.location.length > 0) {
      result = result.filter(job => filters.location.includes(job.location));
    }

    if (filters.jobType.length > 0) {
      result = result.filter(job => filters.jobType.includes(job.type));
    }

    if (filters.workArrangement.length > 0) {
      result = result.filter(job => filters.workArrangement.includes(job.workArrangement));
    }
    
    if (filters.industry.length > 0) {
      result = result.filter(job => filters.industry.includes(job.industry));
    }

    // Salary filter logic (simplified for string ranges in mock data)
    // In real app, parse salary range from job.salary string.
    
    setFilteredJobs(result);
  }, [allJobs, searchTerm, filters]);

  const toggleFilter = (category, value) => {
    setFilters(prev => {
      const current = prev[category];
      const updated = current.includes(value) 
        ? current.filter(item => item !== value)
        : [...current, value];
      return { ...prev, [category]: updated };
    });
  };

  const handleSaveSearch = () => {
      // Simulate saving
      const searches = JSON.parse(localStorage.getItem('indira_candidate_saved_searches') || '[]');
      searches.push({ name: savedSearchName || 'Untitled Search', criteria: filters, date: new Date().toISOString() });
      localStorage.setItem('indira_candidate_saved_searches', JSON.stringify(searches));
      toast({ title: "Search Saved", description: "You can load this search later." });
      setSavedSearchName('');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
       <div className="container mx-auto px-4 py-8">
           {/* Header & Search */}
           <div className="flex flex-col md:flex-row gap-4 mb-8">
               <div className="relative flex-grow">
                   <Search className="absolute left-3 top-3.5 w-5 h-5 text-slate-400" />
                   <input 
                      className="w-full bg-slate-900 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white focus:border-[#00D9FF] outline-none"
                      placeholder="Search job title, company, or keywords..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                   />
               </div>
               <Button 
                 variant="outline" 
                 className="md:hidden border-white/10"
                 onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
               >
                  <Filter className="w-4 h-4 mr-2" /> Filters
               </Button>
               <div className="hidden md:block">
                  <Button onClick={handleSaveSearch} variant="outline" className="border-white/10 hover:border-[#00D9FF]">Save Search</Button>
               </div>
           </div>

           <div className="flex flex-col md:flex-row gap-8">
               {/* Filters Sidebar */}
               <aside className={`md:w-64 flex-shrink-0 ${isMobileFilterOpen ? 'block' : 'hidden md:block'}`}>
                   <div className="bg-slate-900 border border-white/10 rounded-xl p-5 space-y-6 sticky top-24">
                       <div className="flex justify-between items-center md:hidden mb-4">
                           <h3 className="font-bold text-white">Filters</h3>
                           <Button variant="ghost" size="sm" onClick={() => setIsMobileFilterOpen(false)}><X className="w-4 h-4" /></Button>
                       </div>

                       {/* Filter Groups */}
                       <div>
                           <h4 className="font-bold text-sm text-white mb-3">Location</h4>
                           <div className="space-y-2">
                               {LOCATIONS.map(loc => (
                                   <label key={loc} className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer hover:text-white">
                                       <input 
                                          type="checkbox" 
                                          checked={filters.location.includes(loc)}
                                          onChange={() => toggleFilter('location', loc)}
                                          className="accent-[#00D9FF]"
                                       />
                                       {loc}
                                   </label>
                               ))}
                           </div>
                       </div>

                       <div>
                           <h4 className="font-bold text-sm text-white mb-3">Job Type</h4>
                           <div className="space-y-2">
                               {JOB_TYPES.map(type => (
                                   <label key={type} className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer hover:text-white">
                                       <input 
                                          type="checkbox" 
                                          checked={filters.jobType.includes(type)}
                                          onChange={() => toggleFilter('jobType', type)}
                                          className="accent-[#00D9FF]"
                                       />
                                       {type}
                                   </label>
                               ))}
                           </div>
                       </div>

                       <div>
                           <h4 className="font-bold text-sm text-white mb-3">Work Style</h4>
                           <div className="space-y-2">
                               {WORK_ARRANGEMENTS.map(style => (
                                   <label key={style} className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer hover:text-white">
                                       <input 
                                          type="checkbox" 
                                          checked={filters.workArrangement.includes(style)}
                                          onChange={() => toggleFilter('workArrangement', style)}
                                          className="accent-[#00D9FF]"
                                       />
                                       {style}
                                   </label>
                               ))}
                           </div>
                       </div>

                       <div>
                           <h4 className="font-bold text-sm text-white mb-3">Industry</h4>
                           <div className="space-y-2 max-h-40 overflow-y-auto">
                               {INDUSTRIES.map(ind => (
                                   <label key={ind} className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer hover:text-white">
                                       <input 
                                          type="checkbox" 
                                          checked={filters.industry.includes(ind)}
                                          onChange={() => toggleFilter('industry', ind)}
                                          className="accent-[#00D9FF]"
                                       />
                                       {ind}
                                   </label>
                               ))}
                           </div>
                       </div>

                       <Button 
                         variant="outline" 
                         className="w-full text-xs"
                         onClick={() => setFilters({ location: [], jobType: [], workArrangement: [], salaryRange: [20000, 200000], industry: [] })}
                       >
                           Reset Filters
                       </Button>
                   </div>
               </aside>

               {/* Job List */}
               <div className="flex-grow space-y-4">
                   <div className="flex justify-between items-center mb-2">
                       <span className="text-sm text-slate-400">{filteredJobs.length} jobs found</span>
                       <select className="bg-slate-900 border border-white/10 rounded px-2 py-1 text-sm text-slate-300 outline-none">
                           <option>Newest First</option>
                           <option>Match Score</option>
                       </select>
                   </div>

                   {filteredJobs.length === 0 ? (
                       <div className="text-center py-20 bg-slate-900 rounded-xl border border-white/10">
                           <Briefcase className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                           <h3 className="text-xl font-bold text-white mb-2">No jobs found</h3>
                           <p className="text-slate-400 mb-6">Try adjusting your filters or search terms.</p>
                           <Button onClick={() => setFilters({ location: [], jobType: [], workArrangement: [], salaryRange: [20000, 200000], industry: [] })}>
                               Clear Filters
                           </Button>
                       </div>
                   ) : (
                       filteredJobs.map(job => (
                           <motion.div 
                              key={job.id} 
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="bg-slate-900 border border-white/10 rounded-xl p-6 hover:border-[#00D9FF]/30 transition-all group relative"
                           >
                               <div className="flex justify-between items-start mb-2">
                                   <div>
                                       <h3 className="text-xl font-bold text-white group-hover:text-[#00D9FF] transition-colors">{job.title}</h3>
                                       <div className="text-slate-400 text-sm">{job.company}</div>
                                   </div>
                                   {job.matchScore && (
                                       <span className={`text-xs font-bold px-2 py-1 rounded ${job.matchScore > 90 ? 'bg-emerald-500/10 text-emerald-500' : 'bg-blue-500/10 text-blue-500'}`}>
                                           {job.matchScore}% Match
                                       </span>
                                   )}
                               </div>

                               <div className="flex flex-wrap gap-3 my-4 text-xs text-slate-300">
                                   <span className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-white/5"><MapPin className="w-3 h-3" /> {job.location}</span>
                                   <span className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-white/5"><Briefcase className="w-3 h-3" /> {job.type}</span>
                                   <span className="bg-slate-950 px-2 py-1 rounded border border-white/5 text-emerald-400">{job.salary}</span>
                               </div>

                               <p className="text-sm text-slate-400 mb-6 line-clamp-2">{job.description}</p>

                               <div className="flex gap-3">
                                   <Link to={`/candidate-jobs/${job.id}`}>
                                      <Button className="bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 font-bold px-6">View Details</Button>
                                   </Link>
                                   <Button 
                                      variant="ghost" 
                                      className={`px-3 ${isJobSaved(job.id) ? 'text-pink-500 hover:text-pink-600' : 'text-slate-400 hover:text-white'}`}
                                      onClick={() => saveJob(job)}
                                   >
                                       <Heart className={`w-5 h-5 ${isJobSaved(job.id) ? 'fill-current' : ''}`} />
                                   </Button>
                               </div>
                           </motion.div>
                       ))
                   )}
               </div>
           </div>
       </div>
    </div>
  );
};

export default CandidateJobSearch;