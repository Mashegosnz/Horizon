import React, { useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import { LayoutDashboard, Briefcase, FileText, User, Bell, Search, Star, Menu, X, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Import sub-pages
import CandidateJobSearch from './CandidateJobSearch';
import CandidateJobDetail from './CandidateJobDetail';
import CandidateApplicationForm from './CandidateApplicationForm';
import CandidateApplications from './CandidateApplications';
import CandidateProfile from './CandidateProfile';

const RecommendedJobs = () => {
    const { allJobs } = useCandidate();
    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white">Recommended for You</h2>
                <Link to="/candidate-jobs" className="text-[#00D9FF] text-sm hover:underline">See all jobs</Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {allJobs.slice(0, 6).map(job => (
                    <div key={job.id} className="bg-slate-900 border border-white/10 p-5 rounded-xl hover:border-[#00D9FF]/30 transition-all group">
                        <div className="flex justify-between items-start mb-3">
                            <div>
                                <h3 className="font-bold text-white line-clamp-1 group-hover:text-[#00D9FF] transition-colors">{job.title}</h3>
                                <div className="text-sm text-slate-400">{job.company}</div>
                            </div>
                            <span className="bg-emerald-500/10 text-emerald-500 text-xs px-2 py-1 rounded font-bold">95% Match</span>
                        </div>
                        <div className="text-xs text-slate-500 mb-4 flex gap-3">
                            <span>{job.location}</span>
                            <span>•</span>
                            <span>{job.salary}</span>
                        </div>
                        <p className="text-sm text-slate-400 mb-4 line-clamp-2">{job.description}</p>
                        <div className="flex gap-2">
                             <Link to={`/candidate-jobs/${job.id}`} className="flex-1">
                                <Button variant="outline" size="sm" className="w-full border-white/10">View</Button>
                             </Link>
                             <Link to={`/candidate-jobs/${job.id}/apply`} className="flex-1">
                                <Button size="sm" className="w-full bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 font-bold">Apply</Button>
                             </Link>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

const NotificationsPanel = ({ isOpen, onClose }) => {
    const { notifications, markNotificationRead, markAllNotificationsRead, clearNotifications } = useCandidate();

    if (!isOpen) return null;

    return (
        <div className="absolute top-16 right-0 w-80 md:w-96 bg-slate-900 border border-white/10 rounded-xl shadow-2xl z-50 overflow-hidden">
            <div className="p-4 border-b border-white/10 flex justify-between items-center bg-slate-950">
                <h3 className="font-bold text-white">Notifications</h3>
                <div className="flex gap-2">
                    <button onClick={markAllNotificationsRead} className="text-xs text-[#00D9FF] hover:underline">Mark all read</button>
                    <button onClick={clearNotifications} className="text-xs text-slate-500 hover:text-red-400">Clear</button>
                </div>
            </div>
            <div className="max-h-[400px] overflow-y-auto">
                {notifications.length === 0 ? (
                    <div className="p-8 text-center text-slate-500 text-sm">No notifications</div>
                ) : (
                    notifications.map(n => (
                        <div 
                           key={n.id} 
                           className={`p-4 border-b border-white/5 hover:bg-slate-800 transition-colors cursor-pointer ${!n.read ? 'bg-slate-900' : 'bg-slate-950/50'}`}
                           onClick={() => markNotificationRead(n.id)}
                        >
                            <div className="flex gap-3">
                                <div className="mt-1">
                                    {n.icon === 'briefcase' && <Briefcase className="w-4 h-4 text-[#00D9FF]" />}
                                    {n.icon === 'heart' && <Star className="w-4 h-4 text-pink-500" />}
                                    {!n.icon && <Bell className="w-4 h-4 text-slate-400" />}
                                </div>
                                <div>
                                    <p className={`text-sm ${!n.read ? 'text-white font-medium' : 'text-slate-400'}`}>{n.message}</p>
                                    <span className="text-xs text-slate-600 block mt-1">{new Date(n.timestamp).toLocaleTimeString()}</span>
                                </div>
                                {!n.read && <div className="w-2 h-2 rounded-full bg-[#00D9FF] mt-2 flex-shrink-0" />}
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

const CandidateDashboard = () => {
  const { candidateUser, logout, notifications } = useCandidate();
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);

  if (!candidateUser) return <div className="p-10 text-center text-white">Please log in.</div>;

  const NavItem = ({ to, icon: Icon, label, exact = false }) => {
      // Logic for active state: Handle nested routes for job search
      const isActive = exact 
          ? location.pathname === to
          : location.pathname.startsWith(to);

      return (
        <Link 
            to={to} 
            onClick={() => setIsSidebarOpen(false)}
            className={`flex items-center px-4 py-3 rounded-lg mb-1 transition-colors ${isActive ? 'bg-[#00D9FF]/10 text-[#00D9FF]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
        >
            <Icon className="w-5 h-5 mr-3" />
            <span className="font-medium text-sm">{label}</span>
        </Link>
      )
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white">
      <Navigation />
      
      <div className="pt-24 pb-12 container mx-auto px-4 flex flex-col lg:flex-row gap-8 relative">
         {/* Mobile Sidebar Toggle */}
         <div className="lg:hidden mb-4 flex justify-between items-center">
             <Button variant="outline" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
                 {isSidebarOpen ? <X className="w-4 h-4 mr-2" /> : <Menu className="w-4 h-4 mr-2" />} Menu
             </Button>
             
             {/* Mobile Notif Toggle */}
             <div className="relative">
                 <button className="p-2 relative" onClick={() => setIsNotifOpen(!isNotifOpen)}>
                     <Bell className="w-6 h-6 text-slate-300" />
                     {unreadCount > 0 && (
                         <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center font-bold">
                             {unreadCount}
                         </span>
                     )}
                 </button>
                 <NotificationsPanel isOpen={isNotifOpen} onClose={() => setIsNotifOpen(false)} />
             </div>
         </div>

         {/* Sidebar */}
         <aside className={`lg:w-64 flex-shrink-0 ${isSidebarOpen ? 'block' : 'hidden lg:block'}`}>
             <div className="bg-slate-900 border border-white/10 rounded-xl p-6 sticky top-24">
                 <div className="flex items-center gap-3 mb-8 pb-6 border-b border-white/5">
                     <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-[#00D9FF] font-bold">
                         {candidateUser.firstName?.[0]}{candidateUser.lastName?.[0]}
                     </div>
                     <div>
                         <div className="font-bold text-white text-sm">{candidateUser.firstName}</div>
                         <div className="text-xs text-slate-500 truncate w-32">{candidateUser.desiredRole || 'Candidate'}</div>
                     </div>
                 </div>

                 <nav>
                     <NavItem to="/candidate-dashboard" icon={LayoutDashboard} label="Dashboard" exact />
                     <NavItem to="/candidate-jobs" icon={Search} label="Job Search" />
                     <NavItem to="/candidate-dashboard/applications" icon={Briefcase} label="Applications" />
                     <NavItem to="/candidate-dashboard/profile" icon={User} label="My Profile" />
                 </nav>

                 <div className="mt-8 pt-6 border-t border-white/5">
                     <Button variant="ghost" className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-400/10" onClick={() => { logout(); navigate('/'); }}>
                         Sign Out
                     </Button>
                 </div>
             </div>
         </aside>

         {/* Main Content */}
         <main className="flex-grow bg-slate-950 rounded-xl min-h-[80vh] relative">
             {/* Desktop Header Notif */}
             <div className="hidden lg:flex justify-end mb-4 absolute top-0 right-0 z-20">
                 <div className="relative">
                     <button 
                         className="p-2 bg-slate-900 border border-white/10 rounded-full hover:bg-slate-800 transition-colors relative"
                         onClick={() => setIsNotifOpen(!isNotifOpen)}
                     >
                         <Bell className="w-5 h-5 text-slate-300" />
                         {unreadCount > 0 && (
                             <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center font-bold">
                                 {unreadCount}
                             </span>
                         )}
                     </button>
                     <NotificationsPanel isOpen={isNotifOpen} onClose={() => setIsNotifOpen(false)} />
                 </div>
             </div>

             <Routes>
                 <Route path="/" element={<RecommendedJobs />} />
                 <Route path="/applications/*" element={<CandidateApplications />} />
                 <Route path="/profile" element={<CandidateProfile />} />
                 {/* Job Routes embedded in dashboard layout if preferred, or handled via full page redirects in App.jsx. 
                     For consistency, let's allow them here if accessed via /candidate-dashboard path, 
                     but currently App.jsx handles /candidate-jobs separately. 
                     
                     Ideally, Job Search should be full width. 
                     Let's keep Dashboard mainly for "My Stuff" and Job Search separate but accessible.
                     However, the sidebar is useful everywhere.
                  */}
             </Routes>
         </main>
      </div>
    </div>
  );
};

export default CandidateDashboard;