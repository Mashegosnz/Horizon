import React, { useState } from 'react';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Briefcase, Calendar, ChevronRight, Clock } from 'lucide-react';

const CandidateApplications = () => {
  const { applications } = useCandidate();
  const [filter, setFilter] = useState('All');
  
  const TABS = ['All', 'Applied', 'Interview', 'Offer', 'Rejected'];

  const filteredApps = filter === 'All' 
    ? applications 
    : applications.filter(app => app.status === filter);

  const getStatusColor = (status) => {
      switch(status) {
          case 'Applied': return 'bg-blue-500/10 text-blue-500';
          case 'Interview': return 'bg-cyan-500/10 text-cyan-500';
          case 'Offer': return 'bg-emerald-500/10 text-emerald-500';
          case 'Rejected': return 'bg-red-500/10 text-red-500';
          default: return 'bg-slate-500/10 text-slate-500';
      }
  };

  return (
    <div className="p-6">
       <div className="flex flex-col md:flex-row justify-between items-center mb-8">
           <h2 className="text-2xl font-bold text-white mb-4 md:mb-0">Your Applications</h2>
           <Link to="/candidate-jobs">
               <Button variant="outline" className="border-white/10">Browse Jobs</Button>
           </Link>
       </div>

       {/* Tabs */}
       <div className="flex gap-2 overflow-x-auto pb-4 mb-4 border-b border-white/5">
           {TABS.map(tab => (
               <button
                  key={tab}
                  onClick={() => setFilter(tab)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${filter === tab ? 'bg-[#00D9FF] text-slate-950' : 'bg-slate-900 text-slate-400 hover:text-white'}`}
               >
                   {tab}
               </button>
           ))}
       </div>

       {/* List */}
       <div className="space-y-4">
           {filteredApps.length === 0 ? (
               <div className="text-center py-20 bg-slate-900 rounded-xl border border-white/10">
                   <Briefcase className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                   <h3 className="text-xl font-bold text-white mb-2">No applications found</h3>
                   <p className="text-slate-400 mb-6">Start applying to jobs to see them here.</p>
                   <Link to="/candidate-jobs"><Button>Find Jobs</Button></Link>
               </div>
           ) : (
               filteredApps.map(app => (
                   <div key={app.id} className="bg-slate-900 border border-white/10 rounded-xl p-6 flex flex-col md:flex-row justify-between items-center gap-6 hover:border-[#00D9FF]/30 transition-colors">
                       <div className="flex-grow">
                           <div className="flex items-center gap-3 mb-2">
                               <h3 className="text-lg font-bold text-white">{app.jobTitle}</h3>
                               <span className={`text-xs font-bold px-2 py-1 rounded ${getStatusColor(app.status)}`}>
                                   {app.status}
                               </span>
                           </div>
                           <div className="text-slate-400 text-sm mb-3">{app.company} • {app.location}</div>
                           <div className="flex items-center gap-4 text-xs text-slate-500">
                               <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> Applied: {new Date(app.appliedDate).toLocaleDateString()}</span>
                               <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Updated: {new Date(app.lastUpdate).toLocaleDateString()}</span>
                           </div>
                       </div>
                       
                       <Button variant="outline" className="w-full md:w-auto border-white/10 hover:border-[#00D9FF]">
                           View Details <ChevronRight className="w-4 h-4 ml-2" />
                       </Button>
                   </div>
               ))
           )}
       </div>
    </div>
  );
};

export default CandidateApplications;