import React, { useState } from 'react';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { User, Briefcase, GraduationCap, Code, Globe, FileText, CheckCircle, Plus, Trash2, Edit2 } from 'lucide-react';

const CandidateProfile = () => {
  const { candidateUser, updateProfile } = useCandidate();
  const { toast } = useToast();
  
  // Local state for editing sections
  const [isEditingPersonal, setIsEditingPersonal] = useState(false);
  const [personalData, setPersonalData] = useState({ 
      firstName: candidateUser?.firstName || '', 
      lastName: candidateUser?.lastName || '', 
      email: candidateUser?.email || '', 
      phone: candidateUser?.phone || '', 
      location: candidateUser?.location || '' 
  });

  const handlePersonalSave = () => {
      updateProfile(personalData);
      setIsEditingPersonal(false);
  };

  const completeness = 85; // Calculation logic simplified for demo

  return (
    <div className="p-6 max-w-5xl mx-auto">
       <div className="flex justify-between items-center mb-8">
           <h1 className="text-3xl font-bold text-white">My Profile</h1>
           <div className="flex items-center gap-4">
               <div className="text-right">
                   <div className="text-sm text-slate-400 mb-1">Profile Completeness</div>
                   <div className="w-40 h-2 bg-slate-800 rounded-full overflow-hidden">
                       <div className="h-full bg-[#00D9FF]" style={{ width: `${completeness}%` }} />
                   </div>
               </div>
               <span className="font-bold text-[#00D9FF]">{completeness}%</span>
           </div>
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
           {/* Left Column */}
           <div className="space-y-8 lg:col-span-2">
               {/* Personal Info */}
               <section className="bg-slate-900 border border-white/10 rounded-xl p-6 relative">
                   <div className="flex justify-between items-start mb-6">
                       <h3 className="text-xl font-bold text-white flex items-center gap-2">
                           <User className="w-5 h-5 text-[#00D9FF]" /> Personal Information
                       </h3>
                       {!isEditingPersonal && (
                           <Button size="sm" variant="ghost" onClick={() => setIsEditingPersonal(true)}><Edit2 className="w-4 h-4" /></Button>
                       )}
                   </div>

                   {isEditingPersonal ? (
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <input value={personalData.firstName} onChange={e => setPersonalData({...personalData, firstName: e.target.value})} className="bg-slate-950 border border-white/10 rounded p-2 text-white text-sm" placeholder="First Name" />
                           <input value={personalData.lastName} onChange={e => setPersonalData({...personalData, lastName: e.target.value})} className="bg-slate-950 border border-white/10 rounded p-2 text-white text-sm" placeholder="Last Name" />
                           <input value={personalData.email} onChange={e => setPersonalData({...personalData, email: e.target.value})} className="bg-slate-950 border border-white/10 rounded p-2 text-white text-sm" placeholder="Email" />
                           <input value={personalData.phone} onChange={e => setPersonalData({...personalData, phone: e.target.value})} className="bg-slate-950 border border-white/10 rounded p-2 text-white text-sm" placeholder="Phone" />
                           <input value={personalData.location} onChange={e => setPersonalData({...personalData, location: e.target.value})} className="bg-slate-950 border border-white/10 rounded p-2 text-white text-sm col-span-2" placeholder="Location" />
                           <div className="col-span-2 flex justify-end gap-2 mt-2">
                               <Button variant="ghost" size="sm" onClick={() => setIsEditingPersonal(false)}>Cancel</Button>
                               <Button size="sm" onClick={handlePersonalSave}>Save Changes</Button>
                           </div>
                       </div>
                   ) : (
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4 text-sm">
                           <div>
                               <div className="text-slate-500 text-xs">Full Name</div>
                               <div className="text-white font-medium">{candidateUser?.firstName} {candidateUser?.lastName}</div>
                           </div>
                           <div>
                               <div className="text-slate-500 text-xs">Email</div>
                               <div className="text-white font-medium">{candidateUser?.email}</div>
                           </div>
                           <div>
                               <div className="text-slate-500 text-xs">Phone</div>
                               <div className="text-white font-medium">{candidateUser?.phone}</div>
                           </div>
                           <div>
                               <div className="text-slate-500 text-xs">Location</div>
                               <div className="text-white font-medium">{candidateUser?.location}</div>
                           </div>
                       </div>
                   )}
               </section>

               {/* Skills */}
               <section className="bg-slate-900 border border-white/10 rounded-xl p-6">
                   <div className="flex justify-between items-start mb-6">
                       <h3 className="text-xl font-bold text-white flex items-center gap-2">
                           <Code className="w-5 h-5 text-[#00D9FF]" /> Skills
                       </h3>
                       <Button size="sm" variant="ghost"><Plus className="w-4 h-4" /></Button>
                   </div>
                   <div className="flex flex-wrap gap-2">
                       {candidateUser?.skills?.map((skill, i) => (
                           <div key={i} className="bg-slate-950 border border-white/10 px-3 py-1.5 rounded-full text-sm text-slate-300 flex items-center gap-2">
                               {skill}
                               <button className="text-slate-500 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>
                           </div>
                       )) || <div className="text-slate-500 italic">No skills added yet.</div>}
                   </div>
               </section>
           </div>

           {/* Right Column */}
           <div className="space-y-8">
               {/* CV Management */}
               <section className="bg-slate-900 border border-white/10 rounded-xl p-6">
                   <h3 className="text-xl font-bold text-white flex items-center gap-2 mb-6">
                       <FileText className="w-5 h-5 text-[#00D9FF]" /> CV / Resume
                   </h3>
                   <div className="bg-slate-950 border border-white/10 rounded-xl p-4 flex items-center justify-between mb-4">
                       <div className="flex items-center gap-3">
                           <div className="w-10 h-10 bg-red-500/10 rounded flex items-center justify-center text-red-500">
                               <FileText className="w-5 h-5" />
                           </div>
                           <div>
                               <div className="text-sm font-bold text-white">John_Doe_CV.pdf</div>
                               <div className="text-xs text-slate-500">Uploaded 2 days ago</div>
                           </div>
                       </div>
                       <Button variant="ghost" size="sm" className="text-slate-400"><Trash2 className="w-4 h-4" /></Button>
                   </div>
                   <Button variant="outline" className="w-full border-white/10 border-dashed">Upload New CV</Button>
               </section>

               {/* Visibility */}
               <section className="bg-slate-900 border border-white/10 rounded-xl p-6">
                   <div className="flex justify-between items-center mb-4">
                       <h3 className="font-bold text-white">Profile Visibility</h3>
                       <div className="w-10 h-6 bg-[#00D9FF] rounded-full p-1 cursor-pointer">
                           <div className="w-4 h-4 bg-white rounded-full translate-x-4 shadow-sm" />
                       </div>
                   </div>
                   <p className="text-sm text-slate-400">
                       Your profile is currently <strong className="text-emerald-400">visible</strong> to employers. You are marked as "Open to Work".
                   </p>
               </section>
           </div>
       </div>
    </div>
  );
};

export default CandidateProfile;