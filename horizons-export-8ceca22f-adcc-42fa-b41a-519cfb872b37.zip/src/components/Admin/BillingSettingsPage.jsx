import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Settings, CreditCard, Save, RefreshCw, CheckCircle, ExternalLink } from 'lucide-react';
import Navigation from '@/components/Navigation';

const BillingSettingsPage = () => {
  const { toast } = useToast();
  const [config, setConfig] = useState({
    paypalEnabled: true,
    payfastEnabled: true,
    currency: 'ZAR',
    defaultGateway: 'payfast',
    paypal: { clientId: '', secret: '', mode: 'sandbox' },
    payfast: { merchantId: '', merchantKey: '', passphrase: '', notifyUrl: '', mode: 'sandbox' }
  });

  const [isTestingPayPal, setIsTestingPayPal] = useState(false);
  const [isTestingPayFast, setIsTestingPayFast] = useState(false);

  useEffect(() => {
    const savedConfig = localStorage.getItem('indira_admin_billing_config');
    if (savedConfig) {
      setConfig(JSON.parse(savedConfig));
    }
  }, []);

  const handleChange = (section, field, value) => {
    if (section === 'root') {
      setConfig(prev => ({ ...prev, [field]: value }));
    } else {
      setConfig(prev => ({ ...prev, [section]: { ...prev[section], [field]: value } }));
    }
  };

  const handleSave = () => {
    localStorage.setItem('indira_admin_billing_config', JSON.stringify(config));
    toast({ title: "Settings Saved", description: "Billing configuration updated successfully." });
  };

  const testConnection = (gateway) => {
    if (gateway === 'paypal') {
      setIsTestingPayPal(true);
      setTimeout(() => {
        setIsTestingPayPal(false);
        toast({ title: "PayPal Connected", description: "Connection successful." });
      }, 1500);
    } else {
      setIsTestingPayFast(true);
      setTimeout(() => {
        setIsTestingPayFast(false);
        toast({ title: "PayFast Connected", description: "Connection successful." });
      }, 1500);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans">
      <Navigation />
      <div className="container mx-auto px-6 pt-24 pb-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Settings className="w-8 h-8 text-[#00D9FF]" /> Billing Settings
          </h1>
          <Button onClick={handleSave} className="bg-[#00D9FF] text-slate-950 font-bold">
            <Save className="w-4 h-4 mr-2" /> Save Configuration
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* General Settings */}
          <div className="lg:col-span-2 bg-slate-900 border border-white/10 rounded-xl p-6">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-[#00D9FF]" /> General Configuration
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm text-slate-400 mb-1">Currency</label>
                <input 
                  type="text" 
                  value={config.currency} 
                  disabled 
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-slate-500 cursor-not-allowed" 
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Default Gateway</label>
                <select 
                  value={config.defaultGateway}
                  onChange={(e) => handleChange('root', 'defaultGateway', e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                >
                  <option value="payfast">PayFast (Recommended for SA)</option>
                  <option value="paypal">PayPal (International)</option>
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <label className="block text-sm text-slate-400">Enabled Gateways</label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={config.payfastEnabled}
                    onChange={(e) => handleChange('root', 'payfastEnabled', e.target.checked)}
                    className="accent-[#00D9FF]"
                  />
                  <span>PayFast</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={config.paypalEnabled}
                    onChange={(e) => handleChange('root', 'paypalEnabled', e.target.checked)}
                    className="accent-[#00D9FF]"
                  />
                  <span>PayPal</span>
                </label>
              </div>
            </div>
          </div>

          {/* PayFast Configuration */}
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5">
               <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/PayFast_Logo.png/800px-PayFast_Logo.png" alt="PayFast" className="w-32" />
            </div>
            <h2 className="text-xl font-bold mb-2 flex items-center gap-2">PayFast Configuration</h2>
            <a 
              href="https://www.payfast.co.za/integration" 
              target="_blank" 
              rel="noreferrer" 
              className="text-xs text-[#00D9FF] flex items-center gap-1 mb-6 hover:underline"
            >
              Get Credentials <ExternalLink className="w-3 h-3" />
            </a>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1">Merchant ID</label>
                <input 
                  type="text" 
                  value={config.payfast.merchantId}
                  onChange={(e) => handleChange('payfast', 'merchantId', e.target.value)}
                  placeholder="10000100"
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Merchant Key</label>
                <input 
                  type="text" 
                  value={config.payfast.merchantKey}
                  onChange={(e) => handleChange('payfast', 'merchantKey', e.target.value)}
                  placeholder="46f0cd694581a"
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Passphrase</label>
                <input 
                  type="password" 
                  value={config.payfast.passphrase}
                  onChange={(e) => handleChange('payfast', 'passphrase', e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Mode</label>
                <select 
                  value={config.payfast.mode}
                  onChange={(e) => handleChange('payfast', 'mode', e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                >
                  <option value="sandbox">Sandbox (Test)</option>
                  <option value="live">Live</option>
                </select>
              </div>
              <Button 
                onClick={() => testConnection('payfast')} 
                disabled={isTestingPayFast}
                variant="outline" 
                className="w-full border-white/10 mt-4"
              >
                {isTestingPayFast ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                {isTestingPayFast ? 'Testing...' : 'Test Connection'}
              </Button>
            </div>
          </div>

          {/* PayPal Configuration */}
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6 relative overflow-hidden">
             <div className="absolute top-0 right-0 p-4 opacity-5">
               <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" className="w-24" />
            </div>
            <h2 className="text-xl font-bold mb-2 flex items-center gap-2">PayPal Configuration</h2>
            <a 
              href="https://developer.paypal.com/dashboard/" 
              target="_blank" 
              rel="noreferrer" 
              className="text-xs text-[#00D9FF] flex items-center gap-1 mb-6 hover:underline"
            >
              Get Credentials <ExternalLink className="w-3 h-3" />
            </a>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1">Client ID</label>
                <input 
                  type="text" 
                  value={config.paypal.clientId}
                  onChange={(e) => handleChange('paypal', 'clientId', e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Secret</label>
                <input 
                  type="password" 
                  value={config.paypal.secret}
                  onChange={(e) => handleChange('paypal', 'secret', e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Mode</label>
                <select 
                  value={config.paypal.mode}
                  onChange={(e) => handleChange('paypal', 'mode', e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                >
                  <option value="sandbox">Sandbox (Test)</option>
                  <option value="live">Live</option>
                </select>
              </div>
              <Button 
                onClick={() => testConnection('paypal')} 
                disabled={isTestingPayPal}
                variant="outline" 
                className="w-full border-white/10 mt-4"
              >
                {isTestingPayPal ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                {isTestingPayPal ? 'Testing...' : 'Test Connection'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BillingSettingsPage;