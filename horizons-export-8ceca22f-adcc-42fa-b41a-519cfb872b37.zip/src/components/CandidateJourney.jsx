import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ChevronDown, FileText, Upload, Video, User, Briefcase, ArrowRight, Check, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import JobCard from '@/components/ui/JobCard';
import ComingSoonBadge from '@/components/ui/ComingSoonBadge';
import PlatformNavigation from '@/components/CandidatePlatform/PlatformNavigation';
import Footer from '@/components/Footer';

const StepMockup = ({ title, description, children, onNext }) => (
  <motion.div 
    className="min-h-[80vh] flex flex-col justify-center py-20 border-b border-white/5 relative"
    initial={{ opacity: 0, y: 50 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-100px" }}
    transition={{ duration: 0.6 }}
  >
    <div className="container mx-auto px-4 md:px-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">{title}</h2>
          <p className="text-xl text-slate-300 mb-8 leading-relaxed font-light">{description}</p>
          <div className="flex gap-4">
            <Button onClick={onNext} className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-8 py-6 rounded-lg text-lg shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 transition-all group">
              Next Step <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </div>
        <div className="relative">
          <div className="absolute inset-0 bg-cyan-500/20 blur-[100px] rounded-full opacity-20" />
          <div className="relative bg-slate-900 border border-white/10 rounded-xl shadow-2xl overflow-hidden group hover:border-cyan-500/30 transition-all duration-500">
            {/* Mockup Window Controls */}
            <div className="bg-slate-950 px-4 py-3 border-b border-white/5 flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/20" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/20" />
              <div className="w-3 h-3 rounded-full bg-green-500/20" />
            </div>
            {/* Mockup Content */}
            <div className="p-6 md:p-8 bg-slate-900/50 backdrop-blur-sm min-h-[400px]">
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  </motion.div>
);

const CandidateJourney = () => {
  const step1Ref = useRef(null);
  const step2Ref = useRef(null);
  const step3Ref = useRef(null);
  const step4Ref = useRef(null);
  const step5Ref = useRef(null);

  const scrollToRef = (ref) => ref.current?.scrollIntoView({ behavior: 'smooth' });

  return (
    <>
      <Helmet>
        <title>Your Journey | Indira Candidates</title>
      </Helmet>

      <div className="bg-slate-950 min-h-screen text-slate-200 selection:bg-cyan-500 selection:text-slate-950 font-sans">
        <PlatformNavigation />

        {/* Hero Section */}
        <section className="relative h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
             <img 
               src="https://images.unsplash.com/photo-1666892666066-abe5c4865e9c" 
               alt="Candidate Journey" 
               className="w-full h-full object-cover opacity-30"
             />
             <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-950/60 to-slate-950" />
          </div>
          
          <div className="container relative z-10 px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
                Your Career, <span className="text-cyan-400">Reimagined</span>
              </h1>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-10 font-light">
                Experience the future of job hunting. No more ghosting, no more repetitive forms. Just you and your potential.
              </p>
              <div className="flex flex-col md:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => scrollToRef(step1Ref)}
                  size="lg" 
                  className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-8 py-6 rounded-lg text-lg shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 transition-all"
                >
                  Start Your Journey
                </Button>
                <Link to="/">
                  <Button variant="outline" size="lg" className="border-white/10 text-white hover:bg-white/5 hover:text-cyan-400 px-8 py-6 rounded-lg text-lg">
                    <Home className="mr-2 w-5 h-5" /> Back to Home
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
          
          <motion.div 
            className="absolute bottom-10 left-1/2 -translate-x-1/2 text-cyan-400 animate-bounce cursor-pointer"
            onClick={() => scrollToRef(step1Ref)}
          >
            <ChevronDown className="w-8 h-8" />
          </motion.div>
        </section>

        {/* Step 1: Smart CV */}
        <div ref={step1Ref}>
          <StepMockup 
            title="Step 1: Smart CV Builder" 
            description="Our AI extracts your skills and experience to build a dynamic, living profile. Update it once, and it evolves with you."
            onNext={() => scrollToRef(step2Ref)}
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-6">
                 <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                       <FileText className="w-5 h-5 text-cyan-400" />
                    </div>
                    <div>
                       <h4 className="text-white font-bold">Auto-Generated Profile</h4>
                       <p className="text-xs text-slate-400">AI Parsing in progress...</p>
                    </div>
                 </div>
                 <ComingSoonBadge />
              </div>
              
              {/* Fake Form Elements */}
              <div className="space-y-3 opacity-60">
                 <div className="h-2 bg-slate-800 rounded w-3/4" />
                 <div className="h-2 bg-slate-800 rounded w-1/2" />
                 <div className="h-2 bg-slate-800 rounded w-full" />
                 <div className="grid grid-cols-2 gap-2 mt-4">
                    <div className="h-8 bg-slate-800 rounded" />
                    <div className="h-8 bg-slate-800 rounded" />
                 </div>
              </div>
              
              <div className="mt-6 p-4 bg-cyan-900/10 border border-cyan-500/20 rounded-lg">
                 <p className="text-sm text-cyan-300 flex items-center gap-2">
                    <Check className="w-4 h-4" /> Skills extracted successfully
                 </p>
              </div>
            </div>
          </StepMockup>
        </div>

        {/* Step 2: Document Hub */}
        <div ref={step2Ref}>
          <StepMockup 
            title="Step 2: Verified Document Hub" 
            description="Securely upload your ID, degrees, and certificates. Our blockchain technology verifies them instantly, building trust with employers."
            onNext={() => scrollToRef(step3Ref)}
          >
            <div className="flex flex-col items-center justify-center h-full text-center space-y-6">
               <div className="w-20 h-20 rounded-full bg-slate-800 border-2 border-dashed border-slate-600 flex items-center justify-center group-hover:border-cyan-500 transition-colors">
                  <Upload className="w-8 h-8 text-slate-400 group-hover:text-cyan-400" />
               </div>
               <div>
                  <h4 className="text-white font-bold text-lg">Drag & Drop Documents</h4>
                  <p className="text-sm text-slate-400 mt-1">ID, Transcripts, Certificates</p>
               </div>
               
               <div className="w-full space-y-2 mt-4">
                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded border border-white/5">
                     <span className="text-sm text-slate-300">Degree_Cert.pdf</span>
                     <span className="text-xs text-green-400 flex items-center gap-1"><Check className="w-3 h-3" /> Verified</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded border border-white/5">
                     <span className="text-sm text-slate-300">ID_Document.jpg</span>
                     <span className="text-xs text-yellow-400 flex items-center gap-1">Processing...</span>
                  </div>
               </div>
            </div>
          </StepMockup>
        </div>

        {/* Step 3: Video Studio */}
        <div ref={step3Ref}>
          <StepMockup 
            title="Step 3: Video Profile Studio" 
            description="Showcase your personality and communication skills with a short video intro. Stand out before the interview even begins."
            onNext={() => scrollToRef(step4Ref)}
          >
            <div className="relative aspect-video bg-slate-950 rounded-lg overflow-hidden border border-white/10 flex items-center justify-center">
               <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-4">
                  <div className="flex justify-center gap-4 mb-2">
                     <div className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center shadow-lg shadow-red-500/50 cursor-pointer hover:scale-110 transition-transform">
                        <div className="w-4 h-4 bg-white rounded-sm" />
                     </div>
                  </div>
                  <p className="text-center text-xs text-slate-400">Recording: 00:14 / 01:00</p>
               </div>
               <Video className="w-16 h-16 text-slate-700" />
               <div className="absolute top-4 right-4">
                  <span className="flex items-center gap-2 px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded font-bold uppercase animate-pulse">
                     <div className="w-2 h-2 rounded-full bg-red-500" /> REC
                  </span>
               </div>
            </div>
          </StepMockup>
        </div>

        {/* Step 4: Profile Dashboard */}
        <div ref={step4Ref}>
          <StepMockup 
            title="Step 4: Profile Complete" 
            description="Your professional dashboard tracks your visibility, applications, and profile strength in real-time."
            onNext={() => scrollToRef(step5Ref)}
          >
             <div className="space-y-4">
                <div className="flex items-center gap-4 mb-6">
                   <div className="w-16 h-16 rounded-full bg-slate-800 border-2 border-cyan-500 flex items-center justify-center">
                      <User className="w-8 h-8 text-cyan-400" />
                   </div>
                   <div>
                      <h3 className="text-xl font-bold text-white">Thandiwe Nkosi</h3>
                      <p className="text-cyan-400 text-sm">Profile Strength: All Star</p>
                   </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                   <div className="bg-slate-950 p-4 rounded-lg border border-white/5 text-center">
                      <span className="block text-2xl font-bold text-white">85%</span>
                      <span className="text-xs text-slate-400">Visibility</span>
                   </div>
                   <div className="bg-slate-950 p-4 rounded-lg border border-white/5 text-center">
                      <span className="block text-2xl font-bold text-white">12</span>
                      <span className="text-xs text-slate-400">Profile Views</span>
                   </div>
                </div>
             </div>
          </StepMockup>
        </div>

        {/* Step 5: Job Matches */}
        <div ref={step5Ref} className="py-24 bg-slate-900 border-t border-white/5">
          <div className="container mx-auto px-4 md:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Your Perfect Matches</h2>
              <p className="text-slate-400 text-lg">Jobs curated specifically for your skills and goals.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
               <JobCard 
                  title="Senior Frontend Developer"
                  company="TechCorp SA"
                  match={98}
                  location="Cape Town (Remote)"
                  salary="R 65k - R 85k"
                  tags={["React", "TypeScript", "Tailwind"]}
               />
               <JobCard 
                  title="UX/UI Designer"
                  company="Creative Agency"
                  match={92}
                  location="Johannesburg (Hybrid)"
                  salary="R 45k - R 60k"
                  tags={["Figma", "Design Systems"]}
               />
               <JobCard 
                  title="Product Manager"
                  company="FinServe Ltd"
                  match={89}
                  location="Durban"
                  salary="R 70k - R 90k"
                  tags={["Agile", "Strategy"]}
               />
            </div>

            <div className="flex justify-center">
               <Button variant="outline" className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 px-8 py-6 text-lg relative overflow-hidden">
                  <span className="relative z-10">View All Matches</span>
                  <div className="absolute top-0 right-0 p-1">
                     <div className="w-2 h-2 bg-cyan-500 rounded-full animate-ping" />
                  </div>
               </Button>
            </div>
            
            <div className="flex justify-center mt-20">
              <Link to="/">
                <Button variant="ghost" className="text-slate-400 hover:text-white flex items-center gap-2">
                  <Home className="w-4 h-4" /> Back to Home
                </Button>
              </Link>
            </div>
          </div>
        </div>
        
        <Footer />
      </div>
    </>
  );
};

export default CandidateJourney;