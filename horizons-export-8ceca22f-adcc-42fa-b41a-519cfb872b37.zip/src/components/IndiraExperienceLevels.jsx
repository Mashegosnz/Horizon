import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Zap, Briefcase, Building2 } from 'lucide-react';

const ExperienceCard = ({ icon: Icon, title, audience, description, planName, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay }}
    className="bg-slate-900 border border-white/10 rounded-xl p-8 flex flex-col h-full hover:border-[#00D9FF]/50 hover:shadow-[0_0_20px_rgba(0,217,255,0.1)] transition-all duration-300 group"
  >
    <div className="flex justify-between items-start mb-6">
      <div className="w-14 h-14 bg-[#00D9FF]/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
        <Icon className="w-7 h-7 text-[#00D9FF]" />
      </div>
      <span className="bg-[#00D9FF]/10 text-[#00D9FF] px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border border-[#00D9FF]/20">
        {planName}
      </span>
    </div>

    <div className="mb-2">
      <h3 className="text-2xl font-bold text-white">{title}</h3>
      <p className="text-sm text-slate-500 font-medium uppercase tracking-wide mt-1">{audience}</p>
    </div>

    <p className="text-slate-400 mt-4 mb-8 flex-grow leading-relaxed">
      {description}
    </p>

    <Link to={`/subscription-confirmation?plan=${planName}`}>
      <Button className="w-full group-hover:shadow-[0_0_15px_rgba(0,217,255,0.4)] transition-shadow">
        Select Plan
      </Button>
    </Link>
  </motion.div>
);

const IndiraExperienceLevels = () => {
  return (
    <section className="py-24 px-6 bg-slate-950">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="mb-4">The Indira Experience</h2>
          <p className="text-slate-400 text-lg">Three levels of integration designed to scale with your South African business.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <ExperienceCard 
            icon={Zap}
            title="Indira Assistant"
            planName="Starter"
            audience="1-50 Employees"
            description="Your autonomous recruiting coordinator. It handles sourcing, screening, and basic employment contracts so you can focus on building your team."
            delay={0}
          />
          <ExperienceCard 
            icon={Briefcase}
            title="Indira Partner"
            planName="Growth"
            audience="50-500 Employees"
            description="A full-suite digital HR partner. Manages payroll integration, legislative compliance (BCEA), performance cycles, and day-to-day operations."
            delay={0.1}
          />
          <ExperienceCard 
            icon={Building2}
            title="Indira Enterprise"
            planName="Enterprise"
            audience="500+ Employees"
            description="Strategic organizational intelligence. Predicts B-BBEE risks, optimizes workforce planning, and integrates with complex ERP systems for total automation."
            delay={0.2}
          />
        </div>
      </div>
    </section>
  );
};

export default IndiraExperienceLevels;