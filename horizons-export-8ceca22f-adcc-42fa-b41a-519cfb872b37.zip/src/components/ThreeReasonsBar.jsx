import React from 'react';
import { motion } from 'framer-motion';
import { Bot, ShieldCheck, TrendingUp } from 'lucide-react';

const ReasonItem = ({ icon: Icon, text, targetId, delay }) => {
  const scrollToSection = () => {
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
      onClick={scrollToSection}
      className="flex items-center gap-3 cursor-pointer group p-4 rounded-lg hover:bg-white/5 transition-all"
    >
      <div className="p-2 bg-[#00D9FF]/10 rounded-full group-hover:bg-[#00D9FF]/20 group-hover:scale-110 transition-all duration-300">
        <Icon className="w-5 h-5 text-[#00D9FF]" />
      </div>
      <span className="text-slate-300 font-medium text-sm md:text-base group-hover:text-white transition-colors">
        {text}
      </span>
    </motion.div>
  );
};

const ThreeReasonsBar = () => {
  return (
    <div className="w-full bg-slate-900 border-y border-white/10 py-4">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4 md:gap-8">
        <ReasonItem 
          icon={Bot} 
          text="End-to-end HR automation" 
          targetId="automation-section"
          delay={0.1}
        />
        <div className="hidden md:block w-px h-8 bg-white/10" />
        <ReasonItem 
          icon={ShieldCheck} 
          text="Built for South African law & B-BBEE" 
          targetId="compliance-section"
          delay={0.2}
        />
        <div className="hidden md:block w-px h-8 bg-white/10" />
        <ReasonItem 
          icon={TrendingUp} 
          text="Designed for SMEs to Enterprise" 
          targetId="pricing-section"
          delay={0.3}
        />
      </div>
    </div>
  );
};

export default ThreeReasonsBar;