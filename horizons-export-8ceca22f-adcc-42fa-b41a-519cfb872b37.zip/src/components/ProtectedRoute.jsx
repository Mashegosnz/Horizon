
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useEmployer } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';

const ProtectedRoute = ({ children, requiredRole = 'employer' }) => {
  const { user, loading } = useEmployer();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-[#00D9FF]">
        Loading...
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/employers/login" state={{ from: location }} replace />;
  }

  // Basic role check simulation. In a real app, user object would have a role.
  // For this prototype, we assume if they have an employer context user, they are an employer.
  // If requiredRole is admin, we might check user.email === 'admin@indira.jobs'
  const isAuthorized = requiredRole === 'employer' || (requiredRole === 'admin' && user.email?.includes('admin'));

  if (!isAuthorized) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white p-6 text-center">
        <h2 className="text-3xl font-bold mb-4 text-red-500">Access Denied</h2>
        <p className="text-slate-400 mb-8">You do not have permission to view this page.</p>
        <Button onClick={() => window.location.href = '/employers/login'} className="bg-[#00D9FF] text-slate-950">
          Log In with Correct Account
        </Button>
      </div>
    );
  }

  return children;
};

export default ProtectedRoute;
