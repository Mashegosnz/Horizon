import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, CircleDot } from 'lucide-react';

const ComparisonColumn = ({ plan, automatedItems, manualItems }) => (
  <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden flex flex-col h-full">
    <div className="bg-slate-950 p-6 border-b border-white/10 text-center">
      <h3 className="text-xl font-bold text-white mb-1">{plan}</h3>
      <div className="text-xs text-slate-500 uppercase tracking-wider">Plan Level</div>
    </div>
    
    <div className="flex flex-col md:flex-row h-full">
      {/* Automated Side */}
      <div className="flex-1 p-6 bg-slate-900/50 border-r border-white/5 relative">
        <div className="absolute top-0 left-0 w-full h-1 bg-[#00D9FF]" />
        <h4 className="text-[#00D9FF] font-bold mb-4 flex items-center gap-2">
          <CheckCircle className="w-5 h-5" /> Automated by Indira
        </h4>
        <ul className="space-y-3">
          {automatedItems.map((item, idx) => (
            <li key={idx} className="text-sm text-slate-300 flex items-start gap-2">
              <span className="text-[#00D9FF] mt-1">•</span> {item}
            </li>
          ))}
        </ul>
      </div>

      {/* Manual Side */}
      <div className="flex-1 p-6 bg-slate-950/30">
        <h4 className="text-slate-400 font-bold mb-4 flex items-center gap-2">
          <CircleDot className="w-5 h-5" /> You Still Decide
        </h4>
        <ul className="space-y-3">
          {manualItems.map((item, idx) => (
            <li key={idx} className="text-sm text-slate-400 flex items-start gap-2">
              <span className="text-slate-600 mt-1">•</span> {item}
            </li>
          ))}
        </ul>
      </div>
    </div>
  </div>
);

const AutomationComparison = () => {
  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="mb-4">What's Automated vs. What You Control</h2>
          <p className="text-slate-400 text-lg">Peace of mind for your legal team: You retain control where it matters.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <ComparisonColumn 
            plan="Indira Assistant"
            automatedItems={[
              "Employment contracts (BCEA)",
              "Employee record storage",
              "Payroll sync & payslip distrib.",
              "Basic leave tracking",
              "Compliance alerts"
            ]}
            manualItems={[
              "Final hiring decisions",
              "Salary negotiations",
              "Disciplinary hearings",
              "Leave approvals (optional)"
            ]}
          />
          
          <ComparisonColumn 
            plan="Indira Partner"
            automatedItems={[
              "Everything in Assistant +",
              "Performance review cycles",
              "Training assignments (L&D)",
              "B-BBEE gap analysis",
              "Compliance audits"
            ]}
            manualItems={[
              "Promotions & raises",
              "Strategic workforce planning",
              "Organizational restructuring",
              "Culture initiatives"
            ]}
          />
          
          <ComparisonColumn 
            plan="Indira Enterprise"
            automatedItems={[
              "Everything in Partner +",
              "End-to-end workflows",
              "Succession planning models",
              "Predictive retention alerts",
              "B-BBEE optimization paths",
              "Executive onboarding"
            ]}
            manualItems={[
              "Executive appointments",
              "Sensitive disciplinary action",
              "Transformation strategy",
              "Mergers & Acquisitions"
            ]}
          />
        </div>
      </div>
    </section>
  );
};

export default AutomationComparison;