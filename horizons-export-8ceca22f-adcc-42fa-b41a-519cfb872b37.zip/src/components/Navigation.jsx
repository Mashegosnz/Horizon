
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, LayoutDashboard, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useEmployer } from '@/context/EmployerContext';
import { useCandidate } from '@/context/CandidateContext';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { user: employerUser, logout: employerLogout } = useEmployer();
  const { candidateUser, logout: candidateLogout } = useCandidate();

  const toggleMenu = () => setIsOpen(!isOpen);

  const NavLink = ({ to, children, mobile = false }) => (
    <Link
      to={to}
      onClick={() => mobile && setIsOpen(false)}
      className={`text-sm font-medium transition-colors hover:text-[#00D9FF] ${
        location.pathname === to ? 'text-[#00D9FF]' : 'text-slate-300'
      } ${mobile ? 'text-2xl py-4 block' : ''}`}
    >
      {children}
    </Link>
  );

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-white/5 transition-all duration-300">
        <div className="container mx-auto px-6 h-20 flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group z-50">
            <span className="font-['Great_Vibes'] text-3xl text-[#00D9FF] drop-shadow-[0_0_10px_rgba(0,217,255,0.8)] group-hover:drop-shadow-[0_0_15px_rgba(0,217,255,1)] transition-all">i</span>
            <span className="font-['Playfair_Display'] italic text-xl font-bold text-white tracking-wide">Indira<span className="text-[#00D9FF]">.Jobs</span></span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            
            {employerUser ? (
               <>
                 <NavLink to="/employers/pricing">Pricing</NavLink>
                 <Link to="/employers/dashboard">
                    <Button variant="outline" className="text-[#00D9FF] hover:bg-[#00D9FF]/10">
                       <LayoutDashboard className="w-4 h-4 mr-2" /> Dashboard
                    </Button>
                 </Link>
                 <Button variant="ghost" onClick={employerLogout} className="text-red-400 hover:text-red-300 p-2">
                       <LogOut className="w-4 h-4" />
                 </Button>
               </>
            ) : candidateUser ? (
                <>
                    <NavLink to="/candidate-jobs">Browse Jobs</NavLink>
                    <Link to="/candidate-dashboard">
                        <Button variant="outline" className="text-[#00D9FF] hover:bg-[#00D9FF]/10">
                            <LayoutDashboard className="w-4 h-4 mr-2" /> My Dashboard
                        </Button>
                    </Link>
                    <Button variant="ghost" onClick={candidateLogout} className="text-red-400 hover:text-red-300 p-2">
                         <LogOut className="w-4 h-4" />
                    </Button>
                </>
            ) : (
               <>
                 <NavLink to="/candidates">For Candidates</NavLink>
                 <NavLink to="/employers/pricing">Pricing</NavLink>
                 <div className="flex items-center gap-4 ml-4">
                      <Link to="/employers/login">
                        <Button variant="ghost" className="text-white hover:text-[#00D9FF]">
                          Log In
                        </Button>
                      </Link>
                      <Link to="/employers/pricing">
                        <Button className="bg-[#00D9FF] text-slate-950 font-bold hover:bg-[#00D9FF]/90">
                          Get Started
                        </Button>
                      </Link>
                  </div>
               </>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden text-white p-2 z-50" onClick={toggleMenu}>
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-slate-950 pt-24 px-6 md:hidden flex flex-col"
          >
            <div className="flex flex-col gap-6 items-center text-center">
              <NavLink to="/" mobile>Home</NavLink>
              
              {employerUser ? (
                 <>
                   <NavLink to="/employers/dashboard" mobile>Dashboard</NavLink>
                   <NavLink to="/employers/pricing" mobile>Pricing</NavLink>
                   <Button variant="ghost" onClick={() => { employerLogout(); setIsOpen(false); }} className="text-red-400">
                      Log Out
                   </Button>
                 </>
              ) : candidateUser ? (
                  <>
                    <NavLink to="/candidate-dashboard" mobile>My Dashboard</NavLink>
                    <NavLink to="/candidate-jobs" mobile>Browse Jobs</NavLink>
                    <Button variant="ghost" onClick={() => { candidateLogout(); setIsOpen(false); }} className="text-red-400">
                        Log Out
                    </Button>
                  </>
              ) : (
                <>
                    <NavLink to="/candidates" mobile>For Candidates</NavLink>
                    <NavLink to="/employers/pricing" mobile>Pricing</NavLink>
                    <div className="flex flex-col w-full gap-4 mt-4">
                        <Link to="/employers/login" onClick={() => setIsOpen(false)}>
                            <Button variant="outline" className="w-full">Log In</Button>
                        </Link>
                        <Link to="/employers/pricing" onClick={() => setIsOpen(false)}>
                            <Button className="w-full bg-[#00D9FF] text-slate-950">Get Started</Button>
                        </Link>
                    </div>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navigation;
