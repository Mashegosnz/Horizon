import React, { useState } from 'react';
import { useEmployer } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Users, Search, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';

const HiringPage = () => {
    const { jobs, postJob } = useEmployer();
    const { toast } = useToast();
    const [isCreating, setIsCreating] = useState(false);
    const [newJob, setNewJob] = useState({ title: '', location: '', salary: '', type: 'Full-time', description: '' });

    const handlePost = (e) => {
        e.preventDefault();
        postJob(newJob);
        setIsCreating(false);
        setNewJob({ title: '', location: '', salary: '', type: 'Full-time', description: '' });
    };

    if (isCreating) {
        return (
            <div className="max-w-2xl mx-auto bg-slate-900 border border-white/10 rounded-xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Create New Role</h2>
                <form onSubmit={handlePost} className="space-y-4">
                    <input required placeholder="Job Title" className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white" value={newJob.title} onChange={e => setNewJob({...newJob, title: e.target.value})} />
                    <div className="grid grid-cols-2 gap-4">
                        <input required placeholder="Location" className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white" value={newJob.location} onChange={e => setNewJob({...newJob, location: e.target.value})} />
                        <input required placeholder="Salary Range" className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white" value={newJob.salary} onChange={e => setNewJob({...newJob, salary: e.target.value})} />
                    </div>
                    <textarea required placeholder="Job Description" className="w-full h-32 bg-slate-950 border border-white/10 rounded p-3 text-white" value={newJob.description} onChange={e => setNewJob({...newJob, description: e.target.value})} />
                    
                    <div className="flex justify-end gap-3 pt-4">
                        <Button variant="ghost" onClick={() => setIsCreating(false)}>Cancel</Button>
                        <Button type="submit" className="bg-[#00D9FF] text-slate-950">Post Role</Button>
                    </div>
                </form>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">Hiring Pipeline</h2>
                <Button onClick={() => setIsCreating(true)} className="bg-[#00D9FF] text-slate-950 font-bold">
                    <Plus className="w-4 h-4 mr-2" /> Create Role
                </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {jobs.map(job => (
                    <div key={job.id} className="bg-slate-900 border border-white/10 rounded-xl p-6 hover:border-[#00D9FF]/30 transition-colors">
                        <div className="flex justify-between mb-2">
                            <h3 className="font-bold text-lg text-white">{job.title}</h3>
                            <span className="text-xs bg-emerald-500/10 text-emerald-500 px-2 py-1 rounded font-bold">{job.status}</span>
                        </div>
                        <p className="text-sm text-slate-400 mb-4">{job.location} • {job.type}</p>
                        
                        <div className="flex gap-2 mb-6">
                             <div className="flex-1 bg-slate-950 rounded p-2 text-center border border-white/5">
                                 <div className="text-lg font-bold text-white">{job.applicants || 0}</div>
                                 <div className="text-[10px] text-slate-500 uppercase">Applicants</div>
                             </div>
                             <div className="flex-1 bg-slate-950 rounded p-2 text-center border border-white/5">
                                 <div className="text-lg font-bold text-[#00D9FF]">3</div>
                                 <div className="text-[10px] text-slate-500 uppercase">Shortlisted</div>
                             </div>
                        </div>

                        <Link to={`/employer-dashboard/hiring/${job.id}`}>
                            <Button variant="outline" className="w-full border-white/10 hover:border-[#00D9FF]">Manage Pipeline</Button>
                        </Link>
                    </div>
                ))}
                {jobs.length === 0 && (
                    <div className="col-span-full text-center py-12 bg-slate-900/50 rounded-xl border border-dashed border-white/10">
                        <p className="text-slate-500">No active roles. Create one to get started.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default HiringPage;