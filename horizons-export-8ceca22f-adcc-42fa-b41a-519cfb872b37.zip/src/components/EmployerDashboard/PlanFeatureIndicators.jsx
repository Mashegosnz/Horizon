import React from 'react';
import { Lock, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import Badge from '@/components/ui/Badge';
import { useEmployer } from '@/context/EmployerContext';

const PlanFeatureIndicators = ({ feature, currentPlan, requiredPlan }) => {
  const navigate = useNavigate();
  const { upgradePlan } = useEmployer();
  
  // Simple logic: Enterprise > Partner > Assistant
  const planLevels = { 'Assistant': 1, 'Partner': 2, 'Enterprise': 3 };
  const currentLevel = planLevels[currentPlan] || 1;
  const requiredLevel = planLevels[requiredPlan] || 1;
  const isLocked = currentLevel < requiredLevel;

  if (!isLocked) {
    return (
      <div className="flex items-center gap-2 text-emerald-400 text-xs mt-2">
        <Check className="w-3 h-3" /> Included in {currentPlan}
      </div>
    );
  }

  return (
    <div className="mt-4 p-4 bg-slate-950/50 border border-white/5 rounded-lg flex items-center justify-between group">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-slate-800 rounded-full text-slate-400">
          <Lock className="w-4 h-4" />
        </div>
        <div>
          <p className="text-sm font-bold text-white">Unlock {feature}</p>
          <p className="text-xs text-slate-400">Available on {requiredPlan} plan</p>
        </div>
      </div>
      <Button 
        size="sm" 
        variant="outline" 
        onClick={() => upgradePlan(requiredPlan)}
        className="text-xs border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
      >
        Upgrade
      </Button>
    </div>
  );
};

export default PlanFeatureIndicators;