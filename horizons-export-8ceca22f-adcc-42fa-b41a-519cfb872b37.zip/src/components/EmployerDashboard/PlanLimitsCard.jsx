import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useEmployer } from '@/context/EmployerContext';
import { Zap } from 'lucide-react';

const ProgressBar = ({ label, current, max, warningThreshold = 0.8 }) => {
  const percentage = Math.min((current / max) * 100, 100);
  const isWarning = (current / max) >= warningThreshold;

  return (
    <div className="mb-3">
      <div className="flex justify-between text-xs mb-1">
        <span className="text-slate-400">{label}</span>
        <span className={`${isWarning ? 'text-amber-400' : 'text-slate-400'}`}>
          {current} of {max} {isWarning && '(Running Low)'}
        </span>
      </div>
      <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full transition-all duration-500 ${isWarning ? 'bg-amber-400' : 'bg-[#00D9FF]'}`}
          style={{ width: `${percentage}%` }} 
        />
      </div>
    </div>
  );
};

const PlanLimitsCard = () => {
  const { user, currentPlanLimits } = useEmployer();
  
  if (!user) return null;

  // Mock usage data - in a real app this would come from the context/API
  const usage = {
    employees: 23,
    jobs: 2,
    locations: 1,
    seats: 1
  };

  const isEnterprise = user.plan === 'Enterprise';

  return (
    <div className="bg-slate-900 border border-[#00D9FF]/30 rounded-xl p-6 relative overflow-hidden">
       {/* Background Decoration */}
       <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
          <Zap className="w-24 h-24 text-[#00D9FF]" />
       </div>

       <div className="relative z-10">
          <div className="text-xs font-bold text-[#00D9FF] uppercase tracking-wider mb-1">Current Plan</div>
          <h3 className="text-2xl font-bold text-white mb-6">{currentPlanLimits.name}</h3>

          <div className="space-y-4 mb-6">
             <ProgressBar 
                label="Active Employees" 
                current={usage.employees} 
                max={currentPlanLimits.jobs === 9999 ? '∞' : 50} // Using hardcoded 50 for Starter for mock display logic
             />
             <ProgressBar 
                label="Active Job Slots" 
                current={usage.jobs} 
                max={currentPlanLimits.jobs === 9999 ? '∞' : currentPlanLimits.jobs} 
             />
             <ProgressBar 
                label="Admin Seats" 
                current={usage.seats} 
                max={currentPlanLimits.seats === 9999 ? '∞' : currentPlanLimits.seats} 
             />
          </div>

          <div className="flex gap-3">
             <Link to="/pricing" className="flex-1">
                <Button variant="outline" size="sm" className="w-full text-xs">
                   View Limits
                </Button>
             </Link>
             {!isEnterprise && (
                <Link to="/pricing" className="flex-1">
                   <Button size="sm" className="w-full text-xs">
                      Upgrade Plan
                   </Button>
                </Link>
             )}
          </div>
       </div>
    </div>
  );
};

export default PlanLimitsCard;