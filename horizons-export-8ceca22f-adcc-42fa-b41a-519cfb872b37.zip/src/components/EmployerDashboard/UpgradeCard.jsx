import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Lock } from 'lucide-react';

const UpgradeCard = ({ featureName, requiredPlan }) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 bg-slate-900 border border-white/10 rounded-xl text-center">
      <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-6">
        <Lock className="w-8 h-8 text-slate-400" />
      </div>
      <h3 className="text-2xl font-bold text-white mb-2">Unlock {featureName}</h3>
      <p className="text-slate-400 mb-8 max-w-md">
        This feature is available on the <span className="text-[#00D9FF] font-semibold">{requiredPlan}</span> plan. 
        Upgrade your workspace to access advanced capabilities.
      </p>
      <Link to="/pricing">
        <Button size="lg" className="shadow-lg shadow-[#00D9FF]/20">
          Upgrade Plan
        </Button>
      </Link>
    </div>
  );
};

export default UpgradeCard;