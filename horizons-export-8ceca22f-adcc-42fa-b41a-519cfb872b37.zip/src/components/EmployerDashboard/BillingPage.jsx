import React from 'react';
import { useEmployer } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';
import { CreditCard, Calendar, Download, AlertTriangle, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const BillingPage = () => {
  const { user, paymentHistory, cancelPlan } = useEmployer();

  if (!user) return null;

  return (
    <div className="space-y-8">
       <div className="flex justify-between items-center">
           <h2 className="text-2xl font-bold text-white flex items-center gap-2">
               <CreditCard className="w-6 h-6 text-[#00D9FF]" /> Billing & Payments
           </h2>
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
           {/* Current Plan Card */}
           <div className="bg-slate-900 border border-white/10 rounded-xl p-6 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-32 h-32 bg-[#00D9FF]/5 rounded-bl-full" />
               <h3 className="text-lg font-bold text-slate-400 mb-4 uppercase text-xs tracking-wider">Current Subscription</h3>
               
               <div className="flex justify-between items-start mb-6">
                   <div>
                       <div className="text-3xl font-bold text-white mb-1">{user.plan} Plan</div>
                       <div className="text-[#00D9FF] text-sm">{user.billingPeriod === 'yearly' ? 'Yearly Billing' : 'Monthly Billing'}</div>
                   </div>
                   <div className={`px-3 py-1 rounded-full text-xs font-bold border ${user.billingStatus === 'Active' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'}`}>
                       {user.billingStatus || 'Trial'}
                   </div>
               </div>

               <div className="flex gap-6 mb-6">
                   <div>
                       <div className="text-slate-500 text-xs mb-1">Price</div>
                       <div className="font-bold text-white">R{user.subscriptionAmount?.toLocaleString()} <span className="text-xs font-normal text-slate-500">/ {user.billingPeriod === 'yearly' ? 'yr' : 'mo'}</span></div>
                   </div>
                   <div>
                       <div className="text-slate-500 text-xs mb-1">Next Billing</div>
                       <div className="font-bold text-white flex items-center gap-2">
                           <Calendar className="w-3 h-3 text-slate-400" />
                           {user.nextBillingDate ? new Date(user.nextBillingDate).toLocaleDateString() : 'N/A'}
                       </div>
                   </div>
               </div>

               <div className="flex gap-3 pt-6 border-t border-white/5">
                   <Link to="/checkout" className="flex-1">
                       <Button variant="outline" className="w-full border-white/10">Change Plan</Button>
                   </Link>
                   <Button variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={() => { if(window.confirm('Are you sure?')) cancelPlan() }}>
                       Cancel Subscription
                   </Button>
               </div>
           </div>

           {/* Payment Method Card */}
           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <h3 className="text-lg font-bold text-slate-400 mb-4 uppercase text-xs tracking-wider">Payment Method</h3>
               
               {user.paymentMethod ? (
                   <div className="flex items-center gap-4 mb-6 p-4 bg-slate-950 rounded-lg border border-white/5">
                       <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
                           <CreditCard className="w-5 h-5 text-white" />
                       </div>
                       <div>
                           <div className="font-bold text-white">{user.paymentMethod}</div>
                           <div className="text-xs text-slate-500">Last used on {user.lastPaymentDate ? new Date(user.lastPaymentDate).toLocaleDateString() : '-'}</div>
                       </div>
                   </div>
               ) : (
                   <div className="flex items-center gap-4 mb-6 p-4 bg-yellow-500/5 rounded-lg border border-yellow-500/10">
                       <AlertTriangle className="w-5 h-5 text-yellow-500" />
                       <div className="text-sm text-yellow-500">No payment method on file.</div>
                   </div>
               )}

               <Link to="/checkout">
                   <Button className="w-full bg-[#00D9FF] text-slate-950 font-bold">Update Payment Method</Button>
               </Link>
           </div>
       </div>

       {/* Payment History */}
       <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
           <div className="p-6 border-b border-white/10">
               <h3 className="font-bold text-white">Payment History</h3>
           </div>
           <div className="overflow-x-auto">
               <table className="w-full text-sm text-left">
                   <thead className="bg-slate-950 text-slate-400 uppercase text-xs">
                       <tr>
                           <th className="px-6 py-3">Date</th>
                           <th className="px-6 py-3">Description</th>
                           <th className="px-6 py-3">Amount</th>
                           <th className="px-6 py-3">Status</th>
                           <th className="px-6 py-3 text-right">Invoice</th>
                       </tr>
                   </thead>
                   <tbody className="divide-y divide-white/5">
                       {paymentHistory.length === 0 ? (
                           <tr>
                               <td colSpan="5" className="px-6 py-8 text-center text-slate-500">No payment history found.</td>
                           </tr>
                       ) : (
                           paymentHistory.map((payment) => (
                               <tr key={payment.id} className="hover:bg-white/5">
                                   <td className="px-6 py-4 text-white">{new Date(payment.date).toLocaleDateString()}</td>
                                   <td className="px-6 py-4 text-slate-300">{payment.billingPeriod}ly subscription - {payment.plan}</td>
                                   <td className="px-6 py-4 text-white font-mono">R{payment.amount.toLocaleString()}</td>
                                   <td className="px-6 py-4">
                                       <span className="bg-emerald-500/10 text-emerald-500 px-2 py-1 rounded-full text-xs font-bold flex items-center w-fit gap-1">
                                           <CheckCircle className="w-3 h-3" /> {payment.status}
                                       </span>
                                   </td>
                                   <td className="px-6 py-4 text-right">
                                       <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                           <Download className="w-4 h-4 text-slate-400" />
                                       </Button>
                                   </td>
                               </tr>
                           ))
                       )}
                   </tbody>
               </table>
           </div>
       </div>
    </div>
  );
};

export default BillingPage;