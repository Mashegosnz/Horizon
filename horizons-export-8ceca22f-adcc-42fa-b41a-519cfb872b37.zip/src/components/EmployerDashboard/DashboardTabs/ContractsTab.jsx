import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { FileText, Download, Plus, Search, FileCheck } from 'lucide-react';

const ContractsTab = () => {
  const { toast } = useToast();
  const [view, setView] = useState('list'); // list, create

  const contracts = [
    { id: 1, name: "Thabo Molefe", type: "Permanent", status: "Signed", date: "2025-10-12" },
    { id: 2, name: "Sarah Jacobs", type: "Fixed Term", status: "Pending", date: "2026-01-15" },
    { id: 3, name: "Nandi Zuma", type: "Consultant", status: "Expired", date: "2024-12-31" },
  ];

  const handleGenerate = () => {
    toast({
      title: "Contract Generated",
      description: "Document saved to employee records.",
    });
    setView('list');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-slate-900 border border-white/10 p-4 rounded-xl">
        <h3 className="text-white font-bold text-xl">Contracts & Documents</h3>
        <div className="flex gap-2">
            {view === 'list' ? (
                <Button onClick={() => setView('create')}><Plus className="w-4 h-4 mr-2" /> New Contract</Button>
            ) : (
                <Button variant="ghost" onClick={() => setView('list')}>Back to List</Button>
            )}
        </div>
      </div>

      {view === 'list' && (
        <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-white/10 flex gap-4">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                    <input className="w-full bg-slate-950 border border-white/10 rounded pl-10 pr-4 py-2 text-sm text-white" placeholder="Search contracts..." />
                </div>
                <Button variant="outline">Filter</Button>
            </div>
            <table className="w-full text-left text-sm">
                <thead className="bg-slate-950 text-slate-400">
                    <tr>
                        <th className="p-4 font-medium">Employee</th>
                        <th className="p-4 font-medium">Type</th>
                        <th className="p-4 font-medium">Status</th>
                        <th className="p-4 font-medium">Date</th>
                        <th className="p-4 font-medium text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                    {contracts.map(c => (
                        <tr key={c.id} className="hover:bg-white/5">
                            <td className="p-4 font-medium text-white">{c.name}</td>
                            <td className="p-4 text-slate-300">{c.type}</td>
                            <td className="p-4">
                                <span className={`px-2 py-1 rounded text-xs font-bold ${
                                    c.status === 'Signed' ? 'bg-emerald-500/10 text-emerald-500' : 
                                    c.status === 'Pending' ? 'bg-amber-500/10 text-amber-500' : 'bg-red-500/10 text-red-500'
                                }`}>
                                    {c.status}
                                </span>
                            </td>
                            <td className="p-4 text-slate-400">{c.date}</td>
                            <td className="p-4 text-right">
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0"><FileText className="w-4 h-4" /></Button>
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0"><Download className="w-4 h-4" /></Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      )}

      {view === 'create' && (
        <div className="bg-slate-900 border border-white/10 rounded-xl p-8 max-w-3xl mx-auto">
             <div className="flex items-center gap-3 mb-6 text-[#00D9FF]">
                 <FileCheck className="w-6 h-6" />
                 <h2 className="text-xl font-bold text-white">Generate Employment Contract</h2>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                 <div className="space-y-2">
                     <label className="text-sm text-slate-400">Employee Name</label>
                     <input className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white" placeholder="Full legal name" />
                 </div>
                 <div className="space-y-2">
                     <label className="text-sm text-slate-400">Job Title</label>
                     <input className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white" placeholder="e.g. Sales Manager" />
                 </div>
                 <div className="space-y-2">
                     <label className="text-sm text-slate-400">Contract Type</label>
                     <select className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white">
                         <option>Permanent Employment</option>
                         <option>Fixed Term Contract</option>
                         <option>Independent Contractor</option>
                     </select>
                 </div>
                 <div className="space-y-2">
                     <label className="text-sm text-slate-400">Monthly Salary (ZAR)</label>
                     <input className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white" placeholder="0.00" />
                 </div>
                 <div className="space-y-2">
                     <label className="text-sm text-slate-400">Start Date</label>
                     <input type="date" className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white" />
                 </div>
             </div>

             <div className="bg-slate-950 p-4 rounded border border-white/5 mb-6">
                 <h4 className="font-bold text-white text-sm mb-2">Automated Clauses Included:</h4>
                 <ul className="text-xs text-slate-400 space-y-1 list-disc pl-4">
                     <li>BCEA compliance checks (Working hours, Leave)</li>
                     <li>POPIA data privacy consent</li>
                     <li>Restraint of trade (Standard)</li>
                     <li>Disciplinary code reference</li>
                 </ul>
             </div>

             <div className="flex gap-4">
                 <Button className="flex-1" onClick={handleGenerate}>Generate & Store</Button>
                 <Button variant="outline" className="flex-1">Preview PDF</Button>
             </div>
        </div>
      )}
    </div>
  );
};

export default ContractsTab;