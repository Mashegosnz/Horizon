import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Users, GitMerge, FileText } from 'lucide-react';

const SuccessionTab = () => {
  const { toast } = useToast();

  return (
    <div className="space-y-6">
       <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
           <h3 className="font-bold text-white text-xl mb-2">Succession Planning</h3>
           <p className="text-slate-400 text-sm mb-6">Ensure business continuity with AI-identified successors.</p>

           <div className="space-y-4">
               {/* Role Card */}
               <div className="bg-slate-950 border border-white/5 rounded-xl p-6">
                   <div className="flex justify-between items-start mb-6">
                       <div>
                           <h4 className="font-bold text-white text-lg">Head of Sales</h4>
                           <div className="text-sm text-slate-400">Current: Mike Ross</div>
                       </div>
                       <div className="flex items-center gap-2">
                           <span className="text-xs font-bold text-slate-400 uppercase">Readiness:</span>
                           <span className="text-xs font-bold bg-amber-500/10 text-amber-500 px-2 py-1 rounded">Medium</span>
                       </div>
                   </div>

                   <div className="space-y-3 mb-6">
                       <div className="text-xs font-bold text-slate-500 uppercase">Identified Successors</div>
                       <div className="flex items-center justify-between bg-slate-900 p-3 rounded border border-white/5">
                           <div className="flex items-center gap-3">
                               <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold">SJ</div>
                               <div>
                                   <div className="text-white text-sm font-bold">Sarah Jacobs</div>
                                   <div className="text-xs text-slate-500">Ready in 1-2 years</div>
                               </div>
                           </div>
                           <div className="h-1.5 w-20 bg-slate-800 rounded-full overflow-hidden">
                               <div className="h-full bg-emerald-500 w-[75%]"></div>
                           </div>
                       </div>
                   </div>

                   <div className="flex gap-4">
                       <Button size="sm" variant="outline"><GitMerge className="w-4 h-4 mr-2" /> Plan Transition</Button>
                       <Button size="sm" variant="outline"><FileText className="w-4 h-4 mr-2" /> Capture Knowledge</Button>
                   </div>
               </div>
           </div>
       </div>
    </div>
  );
};

export default SuccessionTab;