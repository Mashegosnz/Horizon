import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { GraduationCap, TrendingUp, AlertTriangle } from 'lucide-react';

const PeopleTab = () => {
  const { toast } = useToast();

  const handleCycle = () => {
    toast({
      title: "Performance Cycle Created",
      description: "Q2 2026 Cycle initialized for 48 employees.",
    });
  };

  const handleTraining = () => {
    toast({
      title: "Recommendations Loaded",
      description: "Showing 3 SETA-accredited courses matching skills gaps.",
    });
  };

  const handleRisk = () => {
    toast({
      title: "Risk Dashboard",
      description: "Opening retention analysis view...",
    });
  };

  return (
    <div className="space-y-6">
       <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
             <div>
                <h3 className="text-white font-bold text-xl">People Development & Performance</h3>
                <p className="text-slate-400 text-sm">Personalized growth paths and predictive retention analytics.</p>
             </div>
             <span className="bg-[#00D9FF]/10 text-[#00D9FF] border border-[#00D9FF]/20 px-3 py-1 rounded text-xs font-bold uppercase">AI-Assisted</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
             <div className="bg-slate-950 p-6 rounded-lg border border-white/5 hover:border-[#00D9FF]/30 transition-all">
                <div className="flex items-center justify-between mb-4">
                   <h4 className="text-white font-bold">Check-ins</h4>
                   <TrendingUp className="w-5 h-5 text-[#00D9FF]" />
                </div>
                <div className="text-3xl font-bold text-white mb-1">5</div>
                <div className="text-xs text-slate-400">Scheduled for this week</div>
             </div>

             <div className="bg-slate-950 p-6 rounded-lg border border-white/5 hover:border-[#00D9FF]/30 transition-all">
                <div className="flex items-center justify-between mb-4">
                   <h4 className="text-white font-bold">Training Needs</h4>
                   <GraduationCap className="w-5 h-5 text-[#00D9FF]" />
                </div>
                <div className="text-3xl font-bold text-white mb-1">3</div>
                <div className="text-xs text-slate-400">Employees need SETA training</div>
             </div>

             <div className="bg-slate-950 p-6 rounded-lg border border-amber-500/20 hover:border-amber-500/50 transition-all">
                <div className="flex items-center justify-between mb-4">
                   <h4 className="text-white font-bold">Retention Risk</h4>
                   <AlertTriangle className="w-5 h-5 text-amber-500" />
                </div>
                <div className="text-3xl font-bold text-amber-500 mb-1">2</div>
                <div className="text-xs text-slate-400">Employees flagged at-risk</div>
             </div>
          </div>

          <div className="flex flex-wrap gap-4">
             <Button onClick={handleCycle} className="flex-1 min-w-[200px]">Auto-create Performance Cycle</Button>
             <Button onClick={handleTraining} variant="outline" className="flex-1 min-w-[200px]">View SETA Recommendations</Button>
             <Button onClick={handleRisk} variant="ghost" className="flex-1 min-w-[200px] text-amber-400 hover:text-amber-300 hover:bg-amber-400/10">
                Review At-Risk Employees
             </Button>
          </div>
       </div>
    </div>
  );
};

export default PeopleTab;