import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Users, Clock, Briefcase, ChevronRight, CheckCircle, FilePlus, UserCheck } from 'lucide-react';
import JobCreation from '../JobCreation';

const HiringTab = () => {
  const { toast } = useToast();
  const [view, setView] = useState('pipeline'); // pipeline, create-role, shortlist, offer
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const candidates = [
    { id: 1, name: "Thabo Molefe", role: "Senior Frontend Dev", stage: "Applied", score: 88, applied: "2d ago" },
    { id: 2, name: "Sarah Jacobs", role: "Product Manager", stage: "Shortlisted", score: 92, applied: "1w ago" },
    { id: 3, name: "Nandi Zuma", role: "UX Designer", stage: "Interview", score: 95, applied: "3d ago" },
    { id: 4, name: "Mike Smith", role: "Sales Lead", stage: "Offer", score: 85, applied: "2w ago" },
  ];

  const handleCreateRole = () => setView('create-role');
  
  const handleProgress = (candidate) => {
    toast({ title: "Candidate Progressed", description: `${candidate.name} moved to next stage.` });
  };

  const handleGenerateOffer = () => setView('offer');

  const sendOffer = () => {
    toast({ title: "Offer Sent", description: "Offer letter emailed to candidate." });
    setView('pipeline');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-slate-900 border border-white/10 p-4 rounded-xl">
        <h3 className="text-white font-bold text-xl">Hiring & Talent Pipeline</h3>
        <div className="flex gap-2">
            {view !== 'pipeline' && <Button variant="ghost" onClick={() => setView('pipeline')}>Back to Pipeline</Button>}
            {view === 'pipeline' && <Button onClick={handleCreateRole}><Briefcase className="w-4 h-4 mr-2" /> Create Role</Button>}
        </div>
      </div>

      {view === 'create-role' && <JobCreation />}

      {view === 'pipeline' && (
        <>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {['Applied', 'Shortlisted', 'Interview', 'Offer'].map((stage) => (
                    <div key={stage} className="bg-slate-900/50 border border-white/5 rounded-lg p-4 min-h-[300px]">
                        <h4 className="font-bold text-slate-300 mb-4 flex justify-between">
                            {stage} 
                            <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-400">
                                {candidates.filter(c => c.stage === stage).length}
                            </span>
                        </h4>
                        <div className="space-y-3">
                            {candidates.filter(c => c.stage === stage).map(c => (
                                <div key={c.id} className="bg-slate-950 p-3 rounded border border-white/5 hover:border-[#00D9FF]/30 transition-colors group">
                                    <div className="font-bold text-white text-sm">{c.name}</div>
                                    <div className="text-xs text-slate-400">{c.role}</div>
                                    <div className="flex justify-between items-center mt-3">
                                        <span className={`text-xs font-bold ${c.score > 90 ? 'text-emerald-400' : 'text-[#00D9FF]'}`}>{c.score}% Match</span>
                                        <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={() => handleProgress(c)}>Move <ChevronRight className="w-3 h-3 ml-1" /></Button>
                                    </div>
                                    {stage === 'Offer' && (
                                        <Button size="sm" className="w-full mt-2 text-xs" onClick={handleGenerateOffer}>Generate Letter</Button>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
            
            <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
                <h4 className="font-bold text-white mb-4 flex items-center gap-2"><UserCheck className="w-5 h-5 text-[#00D9FF]" /> AI Shortlist Review</h4>
                <div className="space-y-2">
                    {candidates.filter(c => c.stage === 'Shortlisted').map(c => (
                        <div key={c.id} className="flex justify-between items-center p-3 bg-slate-950 rounded border border-white/5">
                             <div>
                                <div className="font-bold text-white">{c.name}</div>
                                <div className="text-xs text-slate-400">Skills Match: React, Node.js, TypeScript</div>
                             </div>
                             <div className="flex gap-2">
                                <Button size="sm" variant="outline">View Profile</Button>
                                <Button size="sm">Schedule Interview</Button>
                             </div>
                        </div>
                    ))}
                    {candidates.filter(c => c.stage === 'Shortlisted').length === 0 && <div className="text-slate-500 text-sm">No candidates in shortlist currently.</div>}
                </div>
            </div>
        </>
      )}

      {view === 'offer' && (
        <div className="bg-slate-900 border border-white/10 rounded-xl p-6 max-w-2xl mx-auto">
             <h3 className="mb-6">Generate Offer Letter</h3>
             <div className="space-y-4">
                 <div className="grid grid-cols-2 gap-4">
                     <div>
                         <label className="text-xs text-slate-400 mb-1 block">Candidate Name</label>
                         <input className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white" defaultValue="Mike Smith" />
                     </div>
                     <div>
                         <label className="text-xs text-slate-400 mb-1 block">Role</label>
                         <input className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white" defaultValue="Sales Lead" />
                     </div>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                     <div>
                         <label className="text-xs text-slate-400 mb-1 block">Annual Salary (ZAR)</label>
                         <input className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white" defaultValue="450,000" />
                     </div>
                     <div>
                         <label className="text-xs text-slate-400 mb-1 block">Start Date</label>
                         <input type="date" className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white" />
                     </div>
                 </div>
                 
                 <div className="p-4 bg-slate-950 rounded text-sm text-slate-300 font-mono border border-white/5 my-4">
                     <p>Dear Mike,</p>
                     <p className="mt-2">We are pleased to offer you the position of Sales Lead at Acme Corp...</p>
                     <p className="mt-2">[Preview of automated BCEA compliant offer]</p>
                 </div>

                 <div className="flex gap-4">
                     <Button className="flex-1" onClick={sendOffer}>Send to Candidate</Button>
                     <Button variant="outline" className="flex-1">Download PDF</Button>
                 </div>
             </div>
        </div>
      )}
    </div>
  );
};

export default HiringTab;