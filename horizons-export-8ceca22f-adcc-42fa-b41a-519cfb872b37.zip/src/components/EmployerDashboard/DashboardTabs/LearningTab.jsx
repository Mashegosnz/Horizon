import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { GraduationCap, BookOpen, BarChart } from 'lucide-react';

const LearningTab = () => {
  const { toast } = useToast();

  const assignTraining = () => {
    toast({ title: "Training Assigned", description: "Employees notified of new learning path." });
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
          <h3 className="font-bold text-white text-xl mb-6">Learning & Development</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-slate-950 border border-white/5 rounded-xl p-5">
                  <h4 className="font-bold text-white mb-4 flex items-center gap-2">
                      <GraduationCap className="w-5 h-5 text-[#00D9FF]" /> Recommended Training
                  </h4>
                  <div className="space-y-3">
                      <div className="p-3 bg-slate-900 rounded border border-white/5 hover:border-[#00D9FF]/30 transition-colors">
                          <div className="flex justify-between items-start">
                              <div className="font-bold text-white text-sm">Advanced Leadership</div>
                              <span className="text-[10px] bg-emerald-500/10 text-emerald-500 px-1 rounded">SETA Accredited</span>
                          </div>
                          <div className="text-xs text-slate-400 mt-1">Rec: Middle Management • Skills Gap Match</div>
                          <Button size="sm" className="w-full mt-3 h-7 text-xs" onClick={assignTraining}>Assign</Button>
                      </div>
                      <div className="p-3 bg-slate-900 rounded border border-white/5 hover:border-[#00D9FF]/30 transition-colors">
                          <div className="flex justify-between items-start">
                              <div className="font-bold text-white text-sm">POPIA Compliance</div>
                              <span className="text-[10px] bg-emerald-500/10 text-emerald-500 px-1 rounded">Mandatory</span>
                          </div>
                          <div className="text-xs text-slate-400 mt-1">Rec: All Staff • Annual Refresher</div>
                          <Button size="sm" className="w-full mt-3 h-7 text-xs" onClick={assignTraining}>Assign</Button>
                      </div>
                  </div>
              </div>

              <div className="bg-slate-950 border border-white/5 rounded-xl p-5">
                  <h4 className="font-bold text-white mb-4 flex items-center gap-2">
                      <BarChart className="w-5 h-5 text-[#00D9FF]" /> L&D ROI & Progress
                  </h4>
                  <div className="space-y-4">
                      <div>
                          <div className="text-sm text-slate-400 mb-1">Completion Rate</div>
                          <div className="text-2xl font-bold text-white">78%</div>
                      </div>
                      <div>
                          <div className="text-sm text-slate-400 mb-1">Total Training Hours</div>
                          <div className="text-2xl font-bold text-white">142h</div>
                      </div>
                      <div>
                          <div className="text-sm text-slate-400 mb-1">Estimated ROI</div>
                          <div className="text-2xl font-bold text-emerald-400">+24%</div>
                          <div className="text-xs text-slate-500">Based on perf. improvement</div>
                      </div>
                      <Button variant="outline" className="w-full">View Full Report</Button>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};

export default LearningTab;