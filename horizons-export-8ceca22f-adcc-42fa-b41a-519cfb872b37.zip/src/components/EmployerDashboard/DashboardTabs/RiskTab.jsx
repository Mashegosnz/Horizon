import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Scale, Heart, ArrowRight } from 'lucide-react';

const RiskTab = () => {
  return (
    <div className="space-y-6">
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <div className="flex items-center justify-between mb-4">
                   <h4 className="font-bold text-white flex items-center gap-2">
                       <AlertTriangle className="w-5 h-5 text-red-500" /> Retention Risk
                   </h4>
               </div>
               <div className="text-3xl font-bold text-white mb-2">2</div>
               <p className="text-sm text-slate-400 mb-6">Employees at high risk of exit.</p>
               <Button variant="outline" className="w-full text-xs">View At-Risk Profiles <ArrowRight className="w-3 h-3 ml-2" /></Button>
           </div>

           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <div className="flex items-center justify-between mb-4">
                   <h4 className="font-bold text-white flex items-center gap-2">
                       <Scale className="w-5 h-5 text-amber-500" /> Pay Equity
                   </h4>
               </div>
               <div className="text-3xl font-bold text-white mb-2">3%</div>
               <p className="text-sm text-slate-400 mb-6">Gender pay gap detected in Sales.</p>
               <Button variant="outline" className="w-full text-xs">Analyze Gap <ArrowRight className="w-3 h-3 ml-2" /></Button>
           </div>

           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <div className="flex items-center justify-between mb-4">
                   <h4 className="font-bold text-white flex items-center gap-2">
                       <Heart className="w-5 h-5 text-emerald-500" /> Cultural Health
                   </h4>
               </div>
               <div className="text-3xl font-bold text-white mb-2">8.2</div>
               <p className="text-sm text-slate-400 mb-6">Engagement score (out of 10).</p>
               <Button variant="outline" className="w-full text-xs">View Insights <ArrowRight className="w-3 h-3 ml-2" /></Button>
           </div>
       </div>

       <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
           <h3 className="font-bold text-white text-lg mb-4">High Risk Employees</h3>
           <table className="w-full text-left text-sm">
               <thead className="text-slate-500 border-b border-white/5">
                   <tr>
                       <th className="pb-3">Employee</th>
                       <th className="pb-3">Risk Level</th>
                       <th className="pb-3">Primary Factor</th>
                       <th className="pb-3 text-right">Action</th>
                   </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                   <tr>
                       <td className="py-3 text-white font-medium">John Doe</td>
                       <td className="py-3"><span className="text-red-500 font-bold bg-red-500/10 px-2 py-1 rounded text-xs">High</span></td>
                       <td className="py-3 text-slate-400">Salary &lt; 20th Percentile</td>
                       <td className="py-3 text-right"><Button size="sm" variant="ghost">Review</Button></td>
                   </tr>
               </tbody>
           </table>
       </div>
    </div>
  );
};

export default RiskTab;