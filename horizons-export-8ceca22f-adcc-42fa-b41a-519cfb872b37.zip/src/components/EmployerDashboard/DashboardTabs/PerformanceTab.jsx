import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { TrendingUp, Users, RefreshCw } from 'lucide-react';

const PerformanceTab = () => {
  const { toast } = useToast();

  const handleCreateCycle = () => {
    toast({ title: "Cycle Created", description: "Performance review cycle initiated." });
  };

  const handleCheckin = () => {
    toast({ title: "Scheduled", description: "Check-in invitation sent." });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-slate-900 border border-white/10 p-6 rounded-xl">
         <div>
            <h3 className="font-bold text-white text-xl">Performance Management</h3>
            <p className="text-slate-400 text-sm">Active Cycle: Q1 2026 Growth Review</p>
         </div>
         <Button onClick={handleCreateCycle}><RefreshCw className="w-4 h-4 mr-2" /> Auto-Create Cycle</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
              <h4 className="font-bold text-white mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#00D9FF]" /> Upcoming Check-ins
              </h4>
              <div className="space-y-3">
                  {[
                      { name: "Mike Ross", date: "Tomorrow, 10:00 AM", type: "Goal Setting" },
                      { name: "Sarah Jacobs", date: "Feb 2, 2:00 PM", type: "Performance Review" },
                  ].map((c, i) => (
                      <div key={i} className="flex justify-between items-center bg-slate-950 p-3 rounded border border-white/5">
                          <div>
                              <div className="text-white font-medium">{c.name}</div>
                              <div className="text-xs text-slate-400">{c.date} • {c.type}</div>
                          </div>
                          <Button size="sm" variant="outline" onClick={handleCheckin}>Reschedule</Button>
                      </div>
                  ))}
              </div>
          </div>

          <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
              <h4 className="font-bold text-white mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#00D9FF]" /> 360 Feedback Status
              </h4>
              <div className="space-y-4">
                  <div>
                      <div className="flex justify-between text-sm mb-1 text-slate-300">
                          <span>Feedback Collection</span>
                          <span>65% Complete</span>
                      </div>
                      <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 w-[65%]"></div>
                      </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-sm">
                       <div className="bg-slate-950 p-2 rounded">
                           <div className="font-bold text-white">45</div>
                           <div className="text-xs text-slate-500">Sent</div>
                       </div>
                       <div className="bg-slate-950 p-2 rounded">
                           <div className="font-bold text-white">29</div>
                           <div className="text-xs text-slate-500">Completed</div>
                       </div>
                       <div className="bg-slate-950 p-2 rounded">
                           <div className="font-bold text-amber-500">16</div>
                           <div className="text-xs text-slate-500">Pending</div>
                       </div>
                  </div>
                  <Button variant="outline" className="w-full">Send Reminders</Button>
              </div>
          </div>
      </div>
    </div>
  );
};

export default PerformanceTab;