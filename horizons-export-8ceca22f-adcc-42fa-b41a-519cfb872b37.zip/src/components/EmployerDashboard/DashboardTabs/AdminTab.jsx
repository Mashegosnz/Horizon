import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { CalendarCheck, Banknote, FileText, RefreshCw, Download } from 'lucide-react';

const AdminTab = () => {
  const { toast } = useToast();

  const handleSync = () => {
    toast({
        title: "Syncing Payroll...",
        description: "Connecting to provider.",
    });
    setTimeout(() => {
        toast({
          title: "Sync Successful",
          description: "Payroll data up to date as of now.",
        });
    }, 1500);
  };

  const handleLeaveAction = (action) => {
    toast({
      title: action === 'Approve' ? "Leave Approved" : "Leave Rejected",
      description: `Request has been processed.`,
    });
  };

  const handleExport = () => {
      toast({ title: "Report Exported", description: "Leave_Report_Jan2026.pdf downloaded." });
  }

  return (
    <div className="space-y-6">
       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {/* Payroll Section */}
           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <div className="flex items-center justify-between mb-6">
                   <h3 className="text-white font-bold text-lg flex items-center gap-2">
                       <Banknote className="w-5 h-5 text-[#00D9FF]" /> Payroll Overview
                   </h3>
                   <span className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded">Connected</span>
               </div>
               
               <div className="grid grid-cols-2 gap-4 mb-6">
                   <div className="bg-slate-950 p-3 rounded border border-white/5">
                       <div className="text-xs text-slate-400">Next Payroll</div>
                       <div className="text-white font-bold">25 Jan 2026</div>
                   </div>
                   <div className="bg-slate-900 p-3 rounded border border-white/5">
                       <div className="text-xs text-slate-400">Total Employees</div>
                       <div className="text-white font-bold">48 Synced</div>
                   </div>
               </div>

               <div className="flex gap-3">
                   <Button onClick={handleSync} className="w-full"><RefreshCw className="w-4 h-4 mr-2" /> Sync Data</Button>
               </div>
           </div>

           {/* Leave Balances */}
           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <div className="flex items-center justify-between mb-6">
                   <h3 className="text-white font-bold text-lg flex items-center gap-2">
                       <CalendarCheck className="w-5 h-5 text-[#00D9FF]" /> Leave Balances
                   </h3>
                   <Button variant="ghost" size="sm" onClick={handleExport}><Download className="w-4 h-4" /></Button>
               </div>
               <div className="space-y-3">
                   {[{n:'John Doe', b: 12}, {n:'Jane Smith', b: 8}, {n:'Mike Ross', b: 15}].map((e, i) => (
                       <div key={i} className="flex justify-between items-center text-sm border-b border-white/5 pb-2">
                           <span className="text-slate-300">{e.n}</span>
                           <span className="font-bold text-white">{e.b} Days</span>
                       </div>
                   ))}
               </div>
               <Button variant="outline" className="w-full mt-4">View Team Calendar</Button>
           </div>
       </div>

       {/* Leave Requests */}
       <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
           <h3 className="text-white font-bold text-lg mb-4">Pending Leave Requests</h3>
           <div className="overflow-x-auto">
               <table className="w-full text-left text-sm">
                   <thead className="text-slate-400 border-b border-white/10">
                       <tr>
                           <th className="pb-3">Employee</th>
                           <th className="pb-3">Type</th>
                           <th className="pb-3">Dates</th>
                           <th className="pb-3 text-right">Actions</th>
                       </tr>
                   </thead>
                   <tbody className="divide-y divide-white/5">
                       <tr className="group">
                           <td className="py-3 text-white">Nandi Zuma</td>
                           <td className="py-3 text-slate-400">Annual Leave</td>
                           <td className="py-3 text-slate-400">Feb 10 - Feb 14</td>
                           <td className="py-3 text-right gap-2 flex justify-end">
                               <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300" onClick={() => handleLeaveAction('Reject')}>Reject</Button>
                               <Button size="sm" className="bg-emerald-600 hover:bg-emerald-500" onClick={() => handleLeaveAction('Approve')}>Approve</Button>
                           </td>
                       </tr>
                       <tr className="group">
                           <td className="py-3 text-white">Thabo Molefe</td>
                           <td className="py-3 text-slate-400">Sick Leave</td>
                           <td className="py-3 text-slate-400">Jan 28 (1 Day)</td>
                           <td className="py-3 text-right gap-2 flex justify-end">
                               <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300" onClick={() => handleLeaveAction('Reject')}>Reject</Button>
                               <Button size="sm" className="bg-emerald-600 hover:bg-emerald-500" onClick={() => handleLeaveAction('Approve')}>Approve</Button>
                           </td>
                       </tr>
                   </tbody>
               </table>
           </div>
       </div>
    </div>
  );
};

export default AdminTab;