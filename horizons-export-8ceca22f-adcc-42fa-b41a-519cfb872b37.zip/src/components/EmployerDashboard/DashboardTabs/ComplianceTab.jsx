import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ShieldCheck, Scale, FileText, CheckCircle, AlertTriangle, Download } from 'lucide-react';
import { useEmployer } from '@/context/EmployerContext';
import UpgradeCard from '../UpgradeCard';

const ComplianceTab = () => {
  const { toast } = useToast();
  const { isFeatureAvailable } = useEmployer();
  const showAdvanced = isFeatureAvailable('compliance_advanced');

  const handleAudit = () => {
    toast({ title: "Audit Started", description: "Scanning policies against latest Gazette..." });
    setTimeout(() => toast({ title: "Audit Complete", description: "1 Minor finding detected." }), 2000);
  };

  return (
    <div className="space-y-6">
       {/* Basic Compliance (All Plans) */}
       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <div className="flex justify-between items-start mb-4">
                   <h3 className="font-bold text-white text-lg flex items-center gap-2">
                       <ShieldCheck className="w-5 h-5 text-emerald-500" /> Compliance Status
                   </h3>
                   <span className="bg-emerald-500/10 text-emerald-500 text-xs font-bold px-2 py-1 rounded uppercase">Low Risk</span>
               </div>
               <div className="space-y-4 mb-6">
                   <div className="flex justify-between text-sm border-b border-white/5 pb-2">
                       <span className="text-slate-400">Open Findings</span>
                       <span className="text-white font-bold">0 Critical</span>
                   </div>
                   <div className="flex justify-between text-sm border-b border-white/5 pb-2">
                       <span className="text-slate-400">Policy Updates</span>
                       <span className="text-white font-bold">Up to date</span>
                   </div>
                   <div className="flex justify-between text-sm border-b border-white/5 pb-2">
                       <span className="text-slate-400">Next Audit</span>
                       <span className="text-white font-bold">30 days</span>
                   </div>
               </div>
               <Button onClick={handleAudit} className="w-full">Run Compliance Audit</Button>
           </div>

           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <h3 className="font-bold text-white text-lg mb-4 flex items-center gap-2">
                   <FileText className="w-5 h-5 text-[#00D9FF]" /> Gazette Updates
               </h3>
               <div className="space-y-3 h-[180px] overflow-y-auto pr-2">
                   <div className="bg-slate-950 p-3 rounded border-l-2 border-[#00D9FF]">
                       <div className="text-xs text-slate-500 mb-1">15 Jan 2026</div>
                       <div className="text-sm text-white font-medium">BCEA Earnings Threshold Increase</div>
                   </div>
                   <div className="bg-slate-950 p-3 rounded border-l-2 border-slate-700">
                       <div className="text-xs text-slate-500 mb-1">10 Dec 2025</div>
                       <div className="text-sm text-white font-medium">EE Act Sector Targets Draft</div>
                   </div>
               </div>
           </div>
       </div>

       {/* Advanced Compliance / B-BBEE (Partner+) */}
       {showAdvanced ? (
           <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
               <div className="flex justify-between items-center mb-6">
                   <h3 className="font-bold text-white text-lg flex items-center gap-2">
                       <Scale className="w-5 h-5 text-[#00D9FF]" /> B-BBEE & Employment Equity
                   </h3>
                   <Button variant="outline" size="sm"><Download className="w-4 h-4 mr-2" /> Report</Button>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                   <div className="bg-slate-950 p-4 rounded-xl border border-white/5 flex flex-col items-center justify-center text-center">
                       <div className="text-slate-400 text-sm mb-2">Current Level</div>
                       <div className="text-4xl font-bold text-white mb-1">Level 4</div>
                       <div className="text-emerald-500 text-xs">Projected Level 3</div>
                   </div>
                   
                   <div className="col-span-2 space-y-4">
                       <div>
                           <div className="flex justify-between text-sm mb-1">
                               <span className="text-slate-400">Management Control</span>
                               <span className="text-white">12 / 20 pts</span>
                           </div>
                           <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                               <div className="h-full bg-[#00D9FF] w-[60%]"></div>
                           </div>
                       </div>
                       <div>
                           <div className="flex justify-between text-sm mb-1">
                               <span className="text-slate-400">Skills Development</span>
                               <span className="text-white">18 / 20 pts</span>
                           </div>
                           <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                               <div className="h-full bg-[#00D9FF] w-[90%]"></div>
                           </div>
                       </div>
                       <div>
                           <div className="flex justify-between text-sm mb-1">
                               <span className="text-slate-400">Enterprise Dev</span>
                               <span className="text-white">5 / 15 pts</span>
                           </div>
                           <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                               <div className="h-full bg-amber-500 w-[33%]"></div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       ) : (
           <UpgradeCard featureName="B-BBEE & Employment Equity" requiredPlan="Indira Partner" />
       )}
    </div>
  );
};

export default ComplianceTab;