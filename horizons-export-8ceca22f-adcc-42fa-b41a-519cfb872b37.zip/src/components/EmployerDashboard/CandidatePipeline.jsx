import React from 'react';
import { useEmployer } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const CandidatePipeline = () => {
  const { user, currentPlanLimits } = useEmployer();
  
  // Dummy data
  const candidates = [
     { id: 1, name: 'Thabo M.', role: 'React Dev', stage: 'Applied', match: 92 },
     { id: 2, name: 'Sarah L.', role: 'Designer', stage: 'Interview', match: 88 },
     { id: 3, name: 'John D.', role: 'Backend', stage: 'Shortlisted', match: 95 },
  ];

  return (
    <div className="space-y-8">
       <div className="flex justify-between items-center">
          <h3>Candidate Pipeline</h3>
          <div className="text-sm text-slate-400">
             Limit: {currentPlanLimits.candidates} candidates
          </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {['Applied', 'Shortlisted', 'Interview', 'Offer', 'Hired'].map(stage => (
             <div key={stage} className="bg-slate-900/50 p-4 rounded-xl border border-white/5 min-h-[300px]">
                <div className="font-bold text-sm uppercase text-slate-500 mb-4">{stage}</div>
                <div className="space-y-3">
                   {candidates.filter(c => c.stage === stage).map(c => (
                      <div key={c.id} className="bg-slate-950 p-3 rounded-lg border border-white/10 hover:border-[#00D9FF]/50 transition-colors">
                         <div className="font-bold text-sm">{c.name}</div>
                         <div className="text-xs text-slate-400">{c.role}</div>
                         <div className="mt-2 flex justify-between items-center">
                            <span className="text-[#00D9FF] text-xs font-bold">{c.match}% Match</span>
                            <Button size="sm" variant="ghost" className="h-6 px-2 text-xs">View</Button>
                         </div>
                      </div>
                   ))}
                </div>
             </div>
          ))}
       </div>

       {user.plan === 'Starter' && (
          <div className="bg-slate-900 p-6 rounded-xl border border-[#00D9FF]/20 text-center">
             <p className="mb-4">Unlock advanced pipeline features with the Growth Plan.</p>
             <Link to="/pricing"><Button>Upgrade Plan</Button></Link>
          </div>
       )}
    </div>
  );
};

export default CandidatePipeline;