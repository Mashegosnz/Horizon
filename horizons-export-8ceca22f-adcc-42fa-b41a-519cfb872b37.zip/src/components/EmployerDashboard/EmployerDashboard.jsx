import React, { useState, useEffect } from 'react';
import { useNavigate, Link, Routes, Route, useLocation } from 'react-router-dom';
import { useEmployer } from '@/context/EmployerContext';
import Navigation from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { 
    LayoutDashboard, Users, BarChart2, LogOut, Zap, 
    ShieldCheck, GraduationCap, CalendarCheck, FileText,
    TrendingUp, GitMerge, AlertTriangle, Plug, Settings, Briefcase, CreditCard
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Pages
import PlanLimitsCard from './PlanLimitsCard';
import UpgradeCard from './UpgradeCard';
import AnalyticsDashboard from './AnalyticsDashboard';
import IntegrationsPage from './IntegrationsPage';
import HiringPage from './HiringPage';
import ContractsPage from './ContractsPage';
import BillingPage from './BillingPage';

const PlaceholderPage = ({ title }) => (
    <div className="p-8 bg-slate-900 border border-white/10 rounded-xl text-center">
        <h2 className="text-2xl font-bold text-white mb-2">{title}</h2>
        <p className="text-slate-400">This module is part of the comprehensive autonomous suite.</p>
    </div>
);

const EmployerDashboard = () => {
  const { user, loading, logout, isFeatureAvailable, allPlans } = useEmployer();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/employer-login');
    }
  }, [user, loading, navigate]);

  if (loading || !user) return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-[#00D9FF]">Loading Dashboard...</div>;

  const currentPlan = allPlans[user.plan] || allPlans['Starter'];
  
  const MENU_ITEMS = [
      { path: '', label: 'Overview', icon: LayoutDashboard, exact: true },
      { path: 'hiring', label: 'Hiring & Talent', icon: Users, feature: 'recruitment' },
      { path: 'contracts', label: 'Contracts', icon: FileText, feature: 'contracts' },
      { path: 'payroll', label: 'Payroll & Leave', icon: CalendarCheck, feature: 'payroll_leave' },
      { path: 'compliance', label: 'Compliance', icon: ShieldCheck, feature: 'compliance_basic' },
      { path: 'performance', label: 'Performance', icon: TrendingUp, feature: 'performance' },
      { path: 'learning', label: 'L&D', icon: GraduationCap, feature: 'learning' },
      { path: 'analytics', label: 'Analytics', icon: BarChart2, feature: 'analytics_advanced' },
      { path: 'billing', label: 'Billing', icon: CreditCard, exact: true },
      { path: 'integrations', label: 'Integrations', icon: Plug, exact: true },
  ];

  const filteredMenu = MENU_ITEMS.filter(item => !item.feature || isFeatureAvailable(item.feature));

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white">
      <Navigation />
      
      <main className="pt-24 pb-12 container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar */}
            <div className="lg:w-64 flex-shrink-0">
                <div className="bg-slate-900 border border-white/10 rounded-xl p-4 sticky top-24">
                    <div className="mb-6 px-2">
                        <div className="font-bold text-white truncate">{user.companyName}</div>
                        <div className="text-xs text-[#00D9FF]">{currentPlan.name}</div>
                    </div>

                    <nav className="space-y-1">
                        {filteredMenu.map(item => {
                             const fullPath = item.path ? `/employer-dashboard/${item.path}` : '/employer-dashboard';
                             const isActive = item.exact 
                                ? location.pathname === fullPath
                                : location.pathname.startsWith(fullPath);
                             
                             return (
                                <Link
                                    key={item.path}
                                    to={fullPath}
                                    className={`flex items-center w-full px-4 py-3 rounded-lg transition-all font-medium text-sm ${isActive ? 'bg-[#00D9FF]/10 text-[#00D9FF]' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                                >
                                    <item.icon className="w-4 h-4 mr-3" />
                                    {item.label}
                                </Link>
                             )
                        })}
                    </nav>

                    <div className="mt-8 pt-6 border-t border-white/5 space-y-2">
                        <Link to="/employer-dashboard/settings" className="flex items-center w-full px-4 py-2 text-sm text-slate-400 hover:text-white">
                            <Settings className="w-4 h-4 mr-3" /> Settings
                        </Link>
                        <button onClick={() => { logout(); navigate('/'); }} className="flex items-center w-full px-4 py-2 text-sm text-red-400 hover:text-red-300">
                            <LogOut className="w-4 h-4 mr-3" /> Log Out
                        </button>
                    </div>
                </div>
            </div>

            {/* Content */}
            <div className="flex-grow">
                <Routes>
                    <Route path="/" element={
                        <div className="space-y-8">
                             <h1 className="text-3xl font-bold">Dashboard Overview</h1>
                             <PlanLimitsCard />
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="bg-slate-900 p-6 rounded-xl border border-white/10">
                                    <h3 className="font-bold mb-4">Quick Actions</h3>
                                    <div className="flex gap-4">
                                        <Link to="hiring" className="flex-1"><Button variant="outline" className="w-full">Post Job</Button></Link>
                                        <Link to="contracts" className="flex-1"><Button variant="outline" className="w-full">New Contract</Button></Link>
                                    </div>
                                </div>
                                <div className="bg-slate-900 p-6 rounded-xl border border-white/10">
                                    <h3 className="font-bold mb-4">System Health</h3>
                                    <div className="text-emerald-500 flex items-center gap-2"><Zap className="w-4 h-4" /> All Systems Operational</div>
                                </div>
                             </div>
                        </div>
                    } />
                    <Route path="integrations" element={<IntegrationsPage />} />
                    <Route path="billing" element={<BillingPage />} />
                    <Route path="hiring/*" element={<HiringPage />} />
                    <Route path="contracts" element={<ContractsPage />} />
                    <Route path="payroll" element={<PlaceholderPage title="Payroll Management" />} />
                    <Route path="compliance" element={<PlaceholderPage title="Compliance Center" />} />
                    <Route path="performance" element={<PlaceholderPage title="Performance Reviews" />} />
                    <Route path="learning" element={<PlaceholderPage title="Learning & Development" />} />
                    <Route path="analytics" element={<AnalyticsDashboard />} />
                </Routes>
            </div>
        </div>
      </main>
    </div>
  );
};

export default EmployerDashboard;