import React, { useState } from 'react';
import { MapPin, Plus, Edit2, XCircle, Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useEmployer } from '@/context/EmployerContext';
import { Link } from 'react-router-dom';

const JobCreation = () => {
  const { user, postJob, getEmployerJobs, currentPlanLimits } = useEmployer();
  const jobs = getEmployerJobs();
  const canPost = jobs.length < currentPlanLimits.jobs;

  const [formData, setFormData] = useState({
    title: '', location: '', salaryMin: '', salaryMax: '', type: 'Full-time', description: '', skills: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (canPost) postJob(formData);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <h3>Post a New Job</h3>
            <span className={`text-sm font-bold ${canPost ? 'text-green-400' : 'text-red-400'}`}>
              {jobs.length} / {currentPlanLimits.jobs} Slots Used
            </span>
          </div>

          {canPost ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input required placeholder="Job Title" className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white" 
                  value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} />
                <select className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white"
                  value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})}>
                    <option value="">Select Location</option>
                    <option>Remote</option>
                    <option>Johannesburg</option>
                    <option>Cape Town</option>
                </select>
              </div>
              <textarea placeholder="Job Description" className="w-full bg-slate-950 border border-white/10 rounded p-3 text-white h-32" 
                 value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
              
              <Button type="submit" className="w-full">
                <Plus className="w-4 h-4 mr-2" /> Post Job
              </Button>
            </form>
          ) : (
            <div className="text-center p-8 bg-slate-950 rounded-lg">
               <p className="text-red-400 mb-4">You have reached your job posting limit.</p>
               <Link to="/pricing"><Button>Upgrade to Growth Plan</Button></Link>
            </div>
          )}
        </div>
      </div>

      <div className="lg:col-span-1">
         <h3 className="mb-4">Posted Jobs</h3>
         <div className="space-y-4">
            {jobs.length === 0 ? <p className="text-slate-500">No active jobs.</p> : jobs.map(j => (
               <div key={j.id} className="bg-slate-900 p-4 rounded-xl border border-white/10">
                  <div className="font-bold">{j.title}</div>
                  <div className="text-sm text-slate-400 mb-2">{j.location} • {j.status}</div>
                  <div className="flex gap-2">
                     <Button size="sm" variant="outline" className="flex-1">Edit</Button>
                     <Button size="sm" variant="ghost" className="text-red-400">Close</Button>
                  </div>
               </div>
            ))}
         </div>
      </div>
    </div>
  );
};

export default JobCreation;