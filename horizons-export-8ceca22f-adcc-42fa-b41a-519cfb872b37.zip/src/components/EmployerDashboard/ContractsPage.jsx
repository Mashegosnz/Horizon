import React from 'react';
import { Button } from '@/components/ui/button';
import { FileText, Download, Send } from 'lucide-react';

const ContractsPage = () => {
    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <FileText className="w-6 h-6 text-[#00D9FF]" /> Contracts & Onboarding
            </h2>
            <div className="bg-slate-900 border border-white/10 rounded-xl p-8 text-center">
                 <h3 className="text-xl font-bold mb-4">Contract Generator</h3>
                 <p className="text-slate-400 mb-6">Auto-generate BCEA-compliant contracts for new hires.</p>
                 <Button className="bg-[#00D9FF] text-slate-950 font-bold">Create New Contract</Button>
            </div>
            
            <h3 className="text-lg font-bold mt-8 mb-4">Recent Contracts</h3>
            <div className="space-y-4">
                 {[1, 2, 3].map(i => (
                     <div key={i} className="flex justify-between items-center bg-slate-900 border border-white/10 p-4 rounded-xl">
                         <div>
                             <div className="font-bold text-white">Employment Contract - John Doe</div>
                             <div className="text-xs text-slate-500">Generated on Feb {i}, 2026</div>
                         </div>
                         <div className="flex gap-2">
                             <Button size="sm" variant="ghost"><Download className="w-4 h-4" /></Button>
                             <Button size="sm" variant="ghost"><Send className="w-4 h-4" /></Button>
                         </div>
                     </div>
                 ))}
            </div>
        </div>
    )
}
export default ContractsPage;