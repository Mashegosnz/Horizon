import React from 'react';
import { useEmployer } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { BarChart2, TrendingUp, Clock, Users } from 'lucide-react';

const AnalyticsDashboard = () => {
  const { user } = useEmployer();
  const isBasic = user.plan === 'Starter';

  return (
    <div className="space-y-8">
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-slate-900 p-6 rounded-xl border border-white/10">
             <div className="flex justify-between items-start mb-2">
                <div className="text-slate-400 text-sm">Time-to-Fill</div>
                <Clock className="w-4 h-4 text-[#00D9FF]" />
             </div>
             <div className="text-2xl font-bold">18 Days</div>
             <div className="text-green-400 text-xs">▼ 2 days from last month</div>
          </div>
          <div className="bg-slate-900 p-6 rounded-xl border border-white/10">
             <div className="flex justify-between items-start mb-2">
                <div className="text-slate-400 text-sm">Applications</div>
                <Users className="w-4 h-4 text-[#00D9FF]" />
             </div>
             <div className="text-2xl font-bold">142</div>
             <div className="text-green-400 text-xs">▲ 12% increase</div>
          </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-slate-900 p-6 rounded-xl border border-white/10 h-64 flex items-center justify-center relative">
             <div className="text-center">
                <BarChart2 className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                <p className="text-slate-400">Pipeline Breakdown Chart</p>
                <div className="text-xs text-[#00D9FF] mt-2">Coming Soon</div>
             </div>
          </div>
          <div className={`bg-slate-900 p-6 rounded-xl border border-white/10 h-64 flex items-center justify-center relative ${isBasic ? 'opacity-50' : ''}`}>
             {isBasic && (
                <div className="absolute inset-0 bg-slate-950/80 flex flex-col items-center justify-center z-10 rounded-xl">
                   <p className="mb-2 font-bold">Advanced Analytics Locked</p>
                   <Link to="/pricing"><Button size="sm">Upgrade to Growth</Button></Link>
                </div>
             )}
             <div className="text-center">
                <TrendingUp className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                <p className="text-slate-400">Cost-per-Hire Analysis</p>
                <div className="text-xs text-[#00D9FF] mt-2">Coming Soon</div>
             </div>
          </div>
       </div>
    </div>
  );
};

export default AnalyticsDashboard;