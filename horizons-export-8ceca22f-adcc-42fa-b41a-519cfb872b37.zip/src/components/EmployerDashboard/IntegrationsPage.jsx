import React from 'react';
import { useEmployer } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { CheckCircle, RefreshCw, Plug } from 'lucide-react';

const IntegrationsPage = () => {
    const { integrations, updateIntegration } = useEmployer();
    const { toast } = useToast();

    const TOOLS = [
        { id: 'sage', name: 'Sage VIP', category: 'Payroll', desc: 'Sync employee data & payslips.' },
        { id: 'simplepay', name: 'SimplePay', category: 'Payroll', desc: 'Automated payroll sync.' },
        { id: 'xero', name: 'Xero', category: 'Accounting', desc: 'General ledger sync.' },
        { id: 'slack', name: 'Slack', category: 'Communication', desc: 'HR notifications & approvals.' },
        { id: 'gcal', name: 'Google Calendar', category: 'Productivity', desc: 'Interview scheduling.' },
        { id: 'dropbox', name: 'Dropbox', category: 'Storage', desc: 'Document backup.' },
    ];

    const handleConnect = (id) => {
        toast({ title: "Connecting...", description: "Establishing secure connection." });
        setTimeout(() => {
            updateIntegration(id, 'connected');
            toast({ title: "Connected", description: `${id} is now active.` });
        }, 1500);
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <Plug className="w-6 h-6 text-[#00D9FF]" /> Integrations
            </h2>
            <p className="text-slate-400">Connect your existing tools to power autonomous workflows.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {TOOLS.map(tool => {
                    const status = integrations[tool.id]?.status;
                    const isConnected = status === 'connected';

                    return (
                        <div key={tool.id} className="bg-slate-900 border border-white/10 rounded-xl p-6 hover:border-[#00D9FF]/30 transition-colors">
                            <div className="flex justify-between items-start mb-4">
                                <div className="font-bold text-lg text-white">{tool.name}</div>
                                {isConnected ? (
                                    <span className="text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded text-xs font-bold flex items-center gap-1">
                                        <CheckCircle className="w-3 h-3" /> Active
                                    </span>
                                ) : (
                                    <span className="text-slate-500 bg-slate-800 px-2 py-1 rounded text-xs">Disconnected</span>
                                )}
                            </div>
                            <div className="text-xs text-[#00D9FF] mb-2 uppercase font-bold">{tool.category}</div>
                            <p className="text-sm text-slate-400 mb-6">{tool.desc}</p>
                            
                            {isConnected ? (
                                <div className="flex gap-2">
                                    <Button size="sm" variant="outline" className="w-full text-xs" onClick={() => handleConnect(tool.id)}>
                                        <RefreshCw className="w-3 h-3 mr-2" /> Re-sync
                                    </Button>
                                    <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300" onClick={() => updateIntegration(tool.id, 'disconnected')}>
                                        Disconnect
                                    </Button>
                                </div>
                            ) : (
                                <Button size="sm" className="w-full bg-[#00D9FF] text-slate-950 font-bold" onClick={() => handleConnect(tool.id)}>
                                    Connect
                                </Button>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default IntegrationsPage;