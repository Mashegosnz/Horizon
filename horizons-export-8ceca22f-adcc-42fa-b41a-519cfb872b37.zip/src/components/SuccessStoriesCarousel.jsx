import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, PlayCircle, Quote, Briefcase, Building } from 'lucide-react';
import { Button } from '@/components/ui/button';

const stories = [
  {
    id: 1,
    name: "Michael T.",
    role: "Senior Developer",
    company: "FinTech Solutions",
    quote: "The automated verification meant I skipped two rounds of interviews. I was hired in record time.",
    image: "https://images.unsplash.com/photo-1575383596664-30f4489f9786?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 2,
    name: "Sarah L.",
    role: "UX Designer",
    company: "Creative Agency",
    quote: "Indira's video profile feature let me show my presentation skills, which my CV never could.",
    image: "https://images.unsplash.com/photo-1635521071003-d9a00f967e0b?q=80&w=1000&auto=format&fit=crop"
  },
  {
    id: 3,
    name: "David K.",
    role: "Project Manager",
    company: "BuildCorp",
    quote: "I found a role that perfectly matched my salary expectations and culture fit without endless searching.",
    image: "https://images.unsplash.com/photo-1590769620285-6926a01c2a58?q=80&w=1000&auto=format&fit=crop"
  }
];

const SuccessStoriesCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      handleNext();
    }, 6000);
    return () => clearInterval(timer);
  }, [currentIndex]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % stories.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + stories.length) % stories.length);
  };

  return (
    <section className="py-16 md:py-24 bg-slate-950 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-8 lg:px-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">Success Stories</h2>
          <div className="w-20 h-1 bg-cyan-500 mx-auto rounded-full shadow-[0_0_15px_rgba(6,182,212,0.8)]" />
        </motion.div>

        <div className="max-w-5xl mx-auto relative group">
          {/* Navigation Buttons */}
          <button 
            onClick={handlePrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-16 z-20 p-3 rounded-full bg-slate-900 border border-white/10 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950 transition-all shadow-lg opacity-0 group-hover:opacity-100 backdrop-blur-md"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <button 
            onClick={handleNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-16 z-20 p-3 rounded-full bg-slate-900 border border-white/10 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950 transition-all shadow-lg opacity-0 group-hover:opacity-100 backdrop-blur-md"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="relative overflow-hidden min-h-[450px] bg-slate-900 rounded-xl border border-white/5 shadow-2xl hover:shadow-cyan-500/10 transition-shadow duration-500">
            <AnimatePresence mode='wait'>
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5, ease: "easeInOut" }}
                className="absolute inset-0 p-8 md:p-12 flex flex-col md:flex-row items-center gap-8 md:gap-12"
              >
                {/* Image Placeholder */}
                <div className="w-full md:w-5/12 aspect-[3/4] md:aspect-square bg-slate-800 rounded-lg relative overflow-hidden shadow-xl border border-white/10 group-hover:border-cyan-500/30 transition-colors duration-500">
                  <img 
                    src={stories[currentIndex].image} 
                    alt={stories[currentIndex].name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent flex items-end p-6">
                    <div className="w-full">
                       <h3 className="text-white font-bold text-xl mb-1">{stories[currentIndex].name}</h3>
                       <p className="text-cyan-400 text-sm font-medium">{stories[currentIndex].role}</p>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="w-full md:w-7/12 flex flex-col justify-center text-left">
                  <div className="mb-8">
                     <Quote className="w-12 h-12 text-cyan-500/20 mb-4" />
                     <blockquote className="text-xl md:text-2xl text-slate-200 font-light leading-relaxed tracking-wide">
                       "{stories[currentIndex].quote}"
                     </blockquote>
                  </div>

                  <div className="flex flex-wrap items-center gap-4">
                    <div className="px-5 py-2.5 rounded-lg bg-slate-950/50 border border-white/10 flex items-center gap-2.5">
                       <Building className="w-4 h-4 text-cyan-400" />
                       <span className="text-sm font-medium text-white">{stories[currentIndex].company}</span>
                    </div>
                    
                    <Button variant="ghost" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10 gap-2">
                       <PlayCircle className="w-5 h-5" />
                       Watch Intro
                    </Button>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
          
          {/* Dots Indicator */}
          <div className="flex justify-center gap-3 mt-10">
            {stories.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  idx === currentIndex ? 'w-10 bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.6)]' : 'w-2 bg-slate-800 hover:bg-slate-700'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SuccessStoriesCarousel;