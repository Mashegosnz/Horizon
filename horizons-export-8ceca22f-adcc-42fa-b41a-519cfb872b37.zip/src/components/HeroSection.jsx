import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const HeroSection = () => {
  const scrollToFeatures = () => {
    const featuresSection = document.getElementById('features');
    if (featuresSection) {
      featuresSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-deep-space">
      
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1703355685639-d558d1b0f63e"
          alt="Modern futuristic workspace"
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-deep-space via-deep-space/90 to-deep-purple/80 mix-blend-multiply" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-deep-purple/40 via-deep-space/60 to-deep-space" />
      </div>

      {/* Floating Elements - Cosmic Particles */}
      <motion.div
        className="absolute top-20 left-10 w-20 h-20 rounded-full bg-electric-cyan/20 blur-xl mix-blend-screen"
        animate={{ y: [0, -20, 0], opacity: [0.5, 0.8, 0.5] }}
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-32 h-32 rounded-full bg-neon-blue/20 blur-xl mix-blend-screen"
        animate={{ y: [0, 20, 0], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto text-center">
          {/* Glassmorphism Card */}
          <motion.div
            className="glassmorphism rounded-2xl p-8 md:p-12 shadow-2xl border border-electric-cyan/20"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            {/* Logo/Brand - Links to Employer Home to keep context self-contained */}
            <Link to="/employers" className="inline-block">
              <motion.div
                className="flex flex-col items-center justify-center mb-8"
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2, type: 'spring' }}
              >
                {/* Lowercase cursive 'i' - Decorative & Striking */}
                <span className="font-['Great_Vibes'] text-7xl md:text-8xl text-electric-cyan opacity-90 leading-none mb-0.5
                  drop-shadow-[0_0_10px_rgba(0,217,255,0.7)] 
                  [text-shadow:_0_0_20px_rgba(0,217,255,0.5),_0_0_40px_rgba(0,217,255,0.3)]">
                  i
                </span>
                
                {/* 'Indira' below - Main Brand Name */}
                <span className="font-['Playfair_Display'] italic text-6xl md:text-7xl font-bold text-electric-cyan tracking-wide leading-none
                  drop-shadow-[0_0_15px_rgba(0,217,255,0.6)] 
                  [text-shadow:_0_0_30px_rgba(0,217,255,0.4),_0_0_60px_rgba(0,217,255,0.2)]">
                  Indira
                </span>
              </motion.div>
            </Link>

            {/* Animated Text Reveal */}
            <motion.h1
              className="text-5xl md:text-7xl lg:text-8xl font-black mb-8 leading-tight tracking-tight"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <span className="gradient-text">Autonomous HR</span>
              <br />
              <span className="text-metallic-silver drop-shadow-lg">for the Future</span>
            </motion.h1>

            <motion.p
              className="text-xl md:text-2xl text-metallic-silver/80 mb-10 max-w-3xl mx-auto font-light leading-relaxed"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              Transform your HR operations with next-generation AI automation. 
              Precision, speed, and intelligence for South African businesses.
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row gap-6 justify-center items-center"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <Button
                size="lg"
                onClick={scrollToFeatures}
                className="bg-electric-cyan text-deep-space hover:bg-neon-blue hover:text-white font-bold px-10 py-7 text-lg rounded-full shadow-neon hover:shadow-neon-blue transition-all duration-300 hover:scale-105 border-none"
              >
                Launch Platform
                <Rocket className="ml-2 h-5 w-5 animate-pulse" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent border-2 border-electric-cyan text-electric-cyan hover:bg-electric-cyan/10 hover:text-white hover:border-white font-bold px-10 py-7 text-lg rounded-full shadow-lg hover:shadow-neon transition-all duration-300 hover:scale-105"
              >
                View Pricing
              </Button>
            </motion.div>

            {/* Stats */}
            <motion.div
              className="grid grid-cols-3 gap-8 mt-16 pt-10 border-t border-electric-cyan/20"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 1 }}
            >
              <div className="group">
                <div className="text-3xl md:text-5xl font-bold text-electric-cyan mb-2 group-hover:text-white transition-colors">98%</div>
                <div className="text-sm font-medium text-metallic-silver/60 uppercase tracking-widest">Time Saved</div>
              </div>
              <div className="group">
                <div className="text-3xl md:text-5xl font-bold text-neon-blue mb-2 group-hover:text-white transition-colors">500+</div>
                <div className="text-sm font-medium text-metallic-silver/60 uppercase tracking-widest">Companies</div>
              </div>
              <div className="group">
                <div className="text-3xl md:text-5xl font-bold text-electric-cyan mb-2 group-hover:text-white transition-colors">24/7</div>
                <div className="text-sm font-medium text-metallic-silver/60 uppercase tracking-widest">Autonomous HR Support</div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
      >
        <ChevronDown className="h-8 w-8 text-electric-cyan animate-pulse" />
      </motion.div>
    </section>
  );
};

export default HeroSection;