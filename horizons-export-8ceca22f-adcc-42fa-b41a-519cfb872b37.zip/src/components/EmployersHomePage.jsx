import React from 'react';
import HeroSection from '@/components/HeroSection';
import ProblemSolution from '@/components/ProblemSolution';
import FeaturesOverview from '@/components/FeaturesOverview';
import PricingCalculator from '@/components/PricingCalculator';
import PricingTiers from '@/components/PricingTiers';
import CallToActionSection from '@/components/CallToActionSection';
import Footer from '@/components/Footer';
import { Helmet } from 'react-helmet';

const EmployersHomePage = () => {
  return (
    <div className="bg-charcoal">
      <Helmet>
        <title>Indira AI | Autonomous HR for Employers</title>
        <meta name="description" content="Streamline your HR operations with Indira's AI-powered automation. Recruitment, compliance, and payroll integration for modern businesses." />
      </Helmet>
      <HeroSection />
      <ProblemSolution />
      <FeaturesOverview />
      <PricingCalculator />
      <PricingTiers />
      <CallToActionSection />
      <Footer />
    </div>
  );
};

export default EmployersHomePage;