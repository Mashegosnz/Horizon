import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sparkles, Bot, ArrowRight } from 'lucide-react';

const WelcomeHero = () => {
  return (
    <section className="relative min-h-screen w-full overflow-hidden bg-slate-950 flex flex-col justify-center items-center">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-slate-950/80 z-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950 z-10" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_#020617_90%)] z-10" />
        <img
          src="https://images.unsplash.com/photo-1698561027165-50e4a5f86bef"
          alt="AI Robot Hand"
          className="w-full h-full object-cover opacity-60 scale-105"
        />
      </div>

      {/* Electric Cyan Glow Effects */}
      <motion.div 
        className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-[100px] mix-blend-screen pointer-events-none"
        animate={{ opacity: [0.3, 0.6, 0.3], scale: [1, 1.2, 1] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div 
        className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-[100px] mix-blend-screen pointer-events-none"
        animate={{ opacity: [0.3, 0.5, 0.3], scale: [1.2, 1, 1.2] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />

      {/* Content */}
      <div className="relative z-20 container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          {/* Logo / Brand Indicator */}
          <motion.div 
            className="flex justify-center items-center mb-10"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
             <span className="font-['Great_Vibes'] text-4xl text-cyan-400 drop-shadow-[0_0_15px_rgba(34,211,238,0.8)]">i</span>
             <span className="font-['Playfair_Display'] italic text-3xl font-bold text-white tracking-wide ml-1">Indira</span>
          </motion.div>

          <motion.h1 
            className="text-4xl md:text-6xl lg:text-7xl font-bold mb-8 leading-tight tracking-tight text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Welcome to <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-white to-cyan-400 animate-gradient-x drop-shadow-[0_0_20px_rgba(34,211,238,0.3)]">
              Authentic Opportunity
            </span>
          </motion.h1>

          <motion.p 
            className="text-lg md:text-xl text-slate-300 mb-12 max-w-2xl mx-auto font-light leading-relaxed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            Bridging the gap between human potential and artificial intelligence. 
            Select your path to begin.
          </motion.p>

          <div className="flex flex-col md:flex-row gap-6 justify-center items-center w-full max-w-3xl mx-auto">
            {/* Candidate Button */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="w-full md:w-auto"
            >
              <Link to="/candidates" className="w-full md:w-auto">
                <Button
                  size="xl"
                  className="w-full md:w-auto min-w-[280px] bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-8 px-8 text-lg rounded-xl shadow-[0_0_20px_rgba(34,211,238,0.4)] hover:shadow-[0_0_40px_rgba(34,211,238,0.6)] transition-all duration-300 group relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
                  <div className="flex flex-col items-center gap-1">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5" />
                      <span>Find Your Dream Job</span>
                    </div>
                    <span className="text-xs uppercase tracking-widest opacity-60 font-medium">For Candidates</span>
                  </div>
                </Button>
              </Link>
            </motion.div>

            {/* Employer Button */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.9 }}
              className="w-full md:w-auto"
            >
              <Link to="/employers" className="w-full md:w-auto">
                <Button
                  size="xl"
                  variant="outline"
                  className="w-full md:w-auto min-w-[280px] bg-slate-900/50 backdrop-blur-sm border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 hover:text-white hover:border-cyan-400 font-bold py-8 px-8 text-lg rounded-xl transition-all duration-300 group"
                >
                  <div className="flex flex-col items-center gap-1">
                    <div className="flex items-center gap-2">
                      <Bot className="w-5 h-5" />
                      <span>Autonomous Human Resources</span>
                    </div>
                    <span className="text-xs uppercase tracking-widest opacity-60 font-medium">For Employers</span>
                  </div>
                </Button>
              </Link>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Decorative Footer Elements */}
      <motion.div 
        className="absolute bottom-8 w-full flex justify-between px-8 text-xs text-slate-600 uppercase tracking-widest pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
      >
        <span>Indira AI Systems</span>
        <span>Est. 2024</span>
      </motion.div>
    </section>
  );
};

export default WelcomeHero;