
import React from 'react';
import { Button } from '@/components/ui/button';
import { BarChart2, Download } from 'lucide-react';
import { Link } from 'react-router-dom';

const ExecutiveAnalytics = () => {
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><BarChart2 className="w-6 h-6 text-[#00D9FF]" /> Executive Analytics</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Download className="w-4 h-4 mr-2" /> Download Board Report</Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
              <div className="text-sm text-slate-400 mb-2">Total Headcount</div>
              <div className="text-3xl font-bold text-white">350</div>
              <div className="text-xs text-emerald-500 mt-2">+5% from last quarter</div>
          </div>
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
              <div className="text-sm text-slate-400 mb-2">Average Time to Hire</div>
              <div className="text-3xl font-bold text-white">18 Days</div>
              <div className="text-xs text-emerald-500 mt-2">-2 days from last quarter</div>
          </div>
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
              <div className="text-sm text-slate-400 mb-2">Compliance Score</div>
              <div className="text-3xl font-bold text-[#00D9FF]">98%</div>
              <div className="text-xs text-slate-400 mt-2">Audit ready</div>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6 min-h-[300px] flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-tr from-[#00D9FF]/5 to-transparent"></div>
              <div className="text-center z-10">
                  <BarChart2 className="w-12 h-12 text-[#00D9FF]/50 mx-auto mb-4" />
                  <p className="text-slate-400">Hiring Trends Chart Visualization</p>
              </div>
          </div>
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6 min-h-[300px] flex items-center justify-center relative overflow-hidden">
               <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent"></div>
              <div className="text-center z-10">
                  <BarChart2 className="w-12 h-12 text-emerald-500/50 mx-auto mb-4" />
                  <p className="text-slate-400">Retention & Attrition Visualization</p>
              </div>
          </div>
      </div>

      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default ExecutiveAnalytics;
