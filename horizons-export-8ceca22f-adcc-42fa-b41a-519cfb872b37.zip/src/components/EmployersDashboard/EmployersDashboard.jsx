
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { useEmployer } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import Navigation from '@/components/Navigation';
import { Briefcase, Users, Calendar, FileText, CheckCircle, Folder, Bell, TrendingUp, GraduationCap, ShieldCheck, AlertTriangle, BarChart2 } from 'lucide-react';

const EmployersDashboard = () => {
    const { data } = useEmployerData();
    const { user } = useEmployer();
    const companyName = data.employers[0]?.company_name || 'Your Company';
    const plan = data.employers[0]?.package_id || 'growth'; // Mocking plan detection

    const allModules = [
        { id: 'requisitions', title: 'Job Requisitions', icon: Briefcase, stat: `${data.jobs.length} open roles`, link: '/employers/dashboard/requisitions', plans: ['starter', 'growth', 'enterprise'] },
        { id: 'candidates', title: 'Candidate Pipeline', icon: Users, stat: `${data.candidates.length} candidates`, link: '/employers/dashboard/candidates', plans: ['starter', 'growth', 'enterprise'] },
        { id: 'interviews', title: 'Interview Scheduler', icon: Calendar, stat: `${data.interviews.length} scheduled`, link: '/employers/dashboard/interviews', plans: ['growth', 'enterprise'] },
        { id: 'offers', title: 'Offer Letters', icon: FileText, stat: `${data.templates.length} templates`, link: '/employers/dashboard/offers', plans: ['starter', 'growth', 'enterprise'] },
        { id: 'onboarding', title: 'Onboarding Checklist', icon: CheckCircle, stat: `${data.onboarding.length} ongoing`, link: '/employers/dashboard/onboarding', plans: ['starter', 'growth', 'enterprise'] },
        { id: 'documents', title: 'HR Documents Vault', icon: Folder, stat: `${data.documents.length} files`, link: '/employers/dashboard/documents', plans: ['starter', 'growth', 'enterprise'] },
        { id: 'notifications', title: 'Notifications', icon: Bell, stat: `${data.notifications.length} new`, link: '/employers/dashboard/notifications', plans: ['starter', 'growth', 'enterprise'] },
        { id: 'performance', title: 'Performance Mgmt', icon: TrendingUp, stat: `${data.performance_cycles.length} active cycle`, link: '/employers/dashboard/performance', plans: ['growth', 'enterprise'] },
        { id: 'learning', title: 'L&D Recommendations', icon: GraduationCap, stat: `${data.training_recommendations.length} recommendations`, link: '/employers/dashboard/learning', plans: ['growth', 'enterprise'] },
        { id: 'bbbee', title: 'B-BBEE Dashboard', icon: ShieldCheck, stat: `Level 3`, link: '/employers/dashboard/bbbee', plans: ['growth', 'enterprise'] },
        { id: 'succession', title: 'Succession Planning', icon: Users, stat: `${data.succession_roles.length} key roles`, link: '/employers/dashboard/succession', plans: ['enterprise'] },
        { id: 'risk', title: 'Predictive Risk', icon: AlertTriangle, stat: `${data.risk_alerts.length} high-risk items`, link: '/employers/dashboard/risk', plans: ['enterprise'] },
        { id: 'analytics', title: 'Executive Analytics', icon: BarChart2, stat: 'Board-ready reports', link: '/employers/dashboard/analytics', plans: ['enterprise'] }
    ];

    const visibleModules = allModules.filter(m => {
        if (plan === 'enterprise') return true;
        if (plan === 'growth' && (m.plans.includes('starter') || m.plans.includes('growth'))) return true;
        if (plan === 'starter' && m.plans.includes('starter')) return true;
        return false;
    });

    return (
        <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col">
            <Navigation />
            <main className="flex-grow pt-24 pb-12 px-6">
                <div className="max-w-7xl mx-auto space-y-12">
                    <header className="flex justify-between items-end">
                        <div>
                            <h1 className="text-3xl font-bold mb-2">Welcome, {companyName}!</h1>
                            <p className="text-slate-400">Your autonomous HR department is running smoothly.</p>
                        </div>
                        {plan !== 'enterprise' && (
                            <Link to="/employers/pricing">
                                <Button className="bg-gradient-to-r from-[#00D9FF] to-blue-500 text-slate-950 font-bold border-none shadow-[0_0_15px_rgba(0,217,255,0.3)]">
                                    Upgrade to {plan === 'starter' ? 'Growth' : 'Enterprise'}
                                </Button>
                            </Link>
                        )}
                    </header>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {visibleModules.map(m => (
                            <Link key={m.id} to={m.link} className="block group">
                                <div className="bg-slate-900 border border-white/10 rounded-xl p-6 h-full transition-all duration-300 group-hover:border-[#00D9FF]/50 group-hover:shadow-2xl group-hover:shadow-[#00D9FF]/10 group-hover:-translate-y-1">
                                    <div className="w-12 h-12 rounded-lg bg-[#00D9FF]/10 flex items-center justify-center mb-6">
                                        <m.icon className="w-6 h-6 text-[#00D9FF]" />
                                    </div>
                                    <h3 className="font-bold text-xl mb-2 text-white group-hover:text-[#00D9FF] transition-colors">{m.title}</h3>
                                    <p className="text-slate-400 mb-6">{m.stat}</p>
                                    <div className="text-sm font-semibold text-[#00D9FF] flex items-center">
                                        View Module <span className="ml-2">→</span>
                                    </div>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default EmployersDashboard;
