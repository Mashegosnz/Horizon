
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { ShieldCheck, Download } from 'lucide-react';
import { Link } from 'react-router-dom';

const BbbeeDashboard = () => {
  const { data } = useEmployerData();
  const bee = data.bbbee_scorecard;

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><ShieldCheck className="w-6 h-6 text-[#00D9FF]" /> B-BBEE Scorecard</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Download className="w-4 h-4 mr-2" /> Download Report</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6 text-center">
              <div className="text-slate-400 mb-2 uppercase text-xs font-bold tracking-wider">Current Level</div>
              <div className="text-4xl font-black text-[#00D9FF]">{bee.current_level}</div>
          </div>
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6 text-center">
              <div className="text-slate-400 mb-2 uppercase text-xs font-bold tracking-wider">Total Score</div>
              <div className="text-4xl font-black text-white">{bee.score} <span className="text-lg text-slate-500 font-normal">/ 100</span></div>
          </div>
          <div className="bg-slate-900 border border-white/10 rounded-xl p-6 text-center flex flex-col justify-center">
              <Button variant="outline" className="w-full border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10">View Recommendations</Button>
          </div>
      </div>
      <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
          <h3 className="font-bold mb-4">Score Breakdown</h3>
          <div className="space-y-4">
              {['Ownership', 'Management Control', 'Skills Development', 'Enterprise & Supplier Development', 'Socio-Economic Development'].map((item, i) => (
                  <div key={i}>
                      <div className="flex justify-between text-sm mb-1">
                          <span className="text-slate-300">{item}</span>
                          <span className="text-white font-mono">{Math.floor(Math.random() * 20)} / 20</span>
                      </div>
                      <div className="w-full bg-slate-950 rounded-full h-2">
                          <div className="bg-[#00D9FF] h-2 rounded-full" style={{ width: `${Math.random() * 100}%` }}></div>
                      </div>
                  </div>
              ))}
          </div>
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default BbbeeDashboard;
