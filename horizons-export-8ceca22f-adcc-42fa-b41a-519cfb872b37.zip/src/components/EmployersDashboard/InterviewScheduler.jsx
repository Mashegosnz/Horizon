
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { Calendar, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

const InterviewScheduler = () => {
  const { data } = useEmployerData();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><Calendar className="w-6 h-6 text-[#00D9FF]" /> Interview Scheduler</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Plus className="w-4 h-4 mr-2" /> Schedule Interview</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.interviews.map(int => {
              const cand = data.candidates.find(c => c.candidate_id === int.candidate_id);
              return (
                <div key={int.interview_id} className="bg-slate-900 border border-white/10 rounded-xl p-6">
                    <div className="flex justify-between mb-4">
                        <span className="font-bold text-white">{cand?.name || 'Unknown Candidate'}</span>
                        <span className={`text-xs px-2 py-1 rounded font-bold ${int.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-blue-500/10 text-blue-500'}`}>{int.status}</span>
                    </div>
                    <div className="text-sm text-slate-400 space-y-2 mb-4">
                        <div><span className="text-slate-500">Date:</span> {new Date(int.scheduled_date).toLocaleString()}</div>
                        <div><span className="text-slate-500">Interviewer:</span> {int.interviewer_name}</div>
                        {int.notes && <div><span className="text-slate-500">Notes:</span> {int.notes}</div>}
                    </div>
                    <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="w-full border-white/10">Reschedule</Button>
                        <Button size="sm" variant="outline" className="w-full border-white/10 text-red-400">Cancel</Button>
                    </div>
                </div>
              )
          })}
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default InterviewScheduler;
