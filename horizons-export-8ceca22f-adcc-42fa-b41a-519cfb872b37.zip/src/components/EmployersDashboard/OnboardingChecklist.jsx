
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { CheckCircle, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

const OnboardingChecklist = () => {
  const { data } = useEmployerData();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><CheckCircle className="w-6 h-6 text-[#00D9FF]" /> Onboarding Checklists</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Plus className="w-4 h-4 mr-2" /> Create New Checklist</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {data.onboarding.map(chk => (
              <div key={chk.checklist_id} className="bg-slate-900 border border-white/10 rounded-xl p-6">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className="font-bold text-lg">{chk.employee_name}</h3>
                      <span className="text-[#00D9FF] font-bold">{chk.completion}%</span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-2 mb-6">
                      <div className="bg-[#00D9FF] h-2 rounded-full" style={{ width: `${chk.completion}%` }}></div>
                  </div>
                  <div className="space-y-3">
                      {chk.tasks.map((task, i) => (
                          <div key={i} className="flex items-center gap-3 text-sm text-slate-300">
                              <div className={`w-4 h-4 rounded border flex items-center justify-center ${task.done ? 'bg-emerald-500 border-emerald-500' : 'border-slate-500'}`}>
                                  {task.done && <CheckCircle className="w-3 h-3 text-slate-950" />}
                              </div>
                              {task.name}
                          </div>
                      ))}
                  </div>
              </div>
          ))}
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default OnboardingChecklist;
