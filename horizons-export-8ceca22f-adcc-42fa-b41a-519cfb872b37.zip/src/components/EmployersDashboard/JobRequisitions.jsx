
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { Plus, Briefcase } from 'lucide-react';
import { Link } from 'react-router-dom';

const JobRequisitions = () => {
  const { data } = useEmployerData();
  const jobs = data.jobs;

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><Briefcase className="w-6 h-6 text-[#00D9FF]" /> Job Requisitions</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Plus className="w-4 h-4 mr-2" /> Create New Requisition</Button>
      </div>
      <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
        <table className="w-full text-left text-sm text-slate-300">
          <thead className="bg-slate-950 text-slate-400 uppercase text-xs">
            <tr>
              <th className="px-6 py-4">Job Title</th>
              <th className="px-6 py-4">Location</th>
              <th className="px-6 py-4">Salary Range</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4">Created Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {jobs.map(job => (
              <tr key={job.job_id} className="hover:bg-white/5 transition-colors">
                <td className="px-6 py-4 font-bold text-white">{job.title}</td>
                <td className="px-6 py-4">{job.location}</td>
                <td className="px-6 py-4">{job.salary_range}</td>
                <td className="px-6 py-4"><span className="px-2 py-1 rounded bg-emerald-500/10 text-emerald-500 text-xs font-bold">{job.status}</span></td>
                <td className="px-6 py-4">{new Date(job.created_at).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-6">
        <Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link>
      </div>
    </div>
  );
};
export default JobRequisitions;
