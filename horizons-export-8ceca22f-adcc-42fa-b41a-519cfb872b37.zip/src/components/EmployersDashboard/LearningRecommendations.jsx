
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { GraduationCap, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const LearningRecommendations = () => {
  const { data } = useEmployerData();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><GraduationCap className="w-6 h-6 text-[#00D9FF]" /> L&D Recommendations</h2>
        <Button variant="outline" className="border-white/10">View Full Catalog</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.training_recommendations.map(rec => (
              <div key={rec.recommendation_id} className="bg-slate-900 border border-white/10 rounded-xl p-6 flex flex-col">
                  <div className="w-10 h-10 bg-[#00D9FF]/10 text-[#00D9FF] rounded flex items-center justify-center mb-4"><GraduationCap className="w-5 h-5" /></div>
                  <h3 className="font-bold text-lg text-white mb-2">{rec.title}</h3>
                  <p className="text-sm text-slate-400 mb-6 flex-grow">{rec.description}</p>
                  <Button className="w-full bg-white/5 hover:bg-white/10 text-white">Assign to Team <ArrowRight className="w-4 h-4 ml-2" /></Button>
              </div>
          ))}
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default LearningRecommendations;
