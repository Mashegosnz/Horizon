
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';

const RiskDashboard = () => {
  const { data } = useEmployerData();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><AlertTriangle className="w-6 h-6 text-red-500" /> Predictive Risk Dashboard</h2>
        <Button variant="outline" className="border-white/10">View All Alerts</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {data.risk_alerts.map(alert => (
              <div key={alert.alert_id} className="bg-slate-900 border border-red-500/20 rounded-xl p-6 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-10"><AlertTriangle className="w-24 h-24 text-red-500" /></div>
                  <div className="flex items-center gap-2 mb-4">
                      <span className={`w-3 h-3 rounded-full ${alert.severity === 'High' ? 'bg-red-500' : 'bg-orange-500'}`} />
                      <span className="text-sm font-bold uppercase tracking-wider text-slate-400">{alert.severity} Risk</span>
                  </div>
                  <h3 className="font-bold text-xl text-white mb-2">{alert.title}</h3>
                  <p className="text-slate-400 text-sm mb-6">Identified on {new Date(alert.created_at).toLocaleDateString()}</p>
                  <Button className="w-full bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20">Review Mitigation Steps</Button>
              </div>
          ))}
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default RiskDashboard;
