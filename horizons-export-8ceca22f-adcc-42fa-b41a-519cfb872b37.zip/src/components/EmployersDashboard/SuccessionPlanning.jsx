
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { Users, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

const SuccessionPlanning = () => {
  const { data } = useEmployerData();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><Users className="w-6 h-6 text-[#00D9FF]" /> Succession Planning</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Plus className="w-4 h-4 mr-2" /> Add Key Role</Button>
      </div>
      <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
        <table className="w-full text-left text-sm text-slate-300">
          <thead className="bg-slate-950 text-slate-400 uppercase text-xs">
            <tr>
              <th className="px-6 py-4">Key Role</th>
              <th className="px-6 py-4">Primary Successor</th>
              <th className="px-6 py-4">Readiness Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {data.succession_roles.map(role => (
              <tr key={role.role_id} className="hover:bg-white/5 transition-colors">
                <td className="px-6 py-4 font-bold text-white">{role.title}</td>
                <td className="px-6 py-4">{role.successor_name}</td>
                <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded text-xs font-bold ${role.status.includes('Ready') ? 'bg-emerald-500/10 text-emerald-500' : 'bg-yellow-500/10 text-yellow-500'}`}>
                        {role.status}
                    </span>
                </td>
                <td className="px-6 py-4 text-right"><Button size="sm" variant="ghost" className="text-[#00D9FF]">Edit</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default SuccessionPlanning;
