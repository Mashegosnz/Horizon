
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { TrendingUp, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

const PerformanceManagement = () => {
  const { data } = useEmployerData();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><TrendingUp className="w-6 h-6 text-[#00D9FF]" /> Performance Management</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Plus className="w-4 h-4 mr-2" /> Create New Cycle</Button>
      </div>
      <div className="bg-slate-900 border border-white/10 rounded-xl p-6">
          <h3 className="font-bold text-lg mb-4">Active Cycles</h3>
          {data.performance_cycles.map(cycle => (
              <div key={cycle.cycle_id} className="border border-white/10 rounded-lg p-4 bg-slate-950 flex justify-between items-center">
                  <div>
                      <div className="font-bold text-white">{cycle.name}</div>
                      <div className="text-sm text-slate-500">Started: {new Date(cycle.created_at).toLocaleDateString()}</div>
                  </div>
                  <div className="flex items-center gap-4">
                      <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 rounded-full text-xs font-bold">{cycle.status}</span>
                      <Button variant="outline" className="border-white/10">View Details</Button>
                  </div>
              </div>
          ))}
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default PerformanceManagement;
