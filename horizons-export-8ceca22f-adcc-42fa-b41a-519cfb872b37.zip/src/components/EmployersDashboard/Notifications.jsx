
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { Bell, Check } from 'lucide-react';
import { Link } from 'react-router-dom';

const Notifications = () => {
  const { data } = useEmployerData();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><Bell className="w-6 h-6 text-[#00D9FF]" /> Notifications</h2>
        <Button variant="outline" className="border-white/10"><Check className="w-4 h-4 mr-2" /> Mark All as Read</Button>
      </div>
      <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
          <div className="divide-y divide-white/10">
              {data.notifications.map(notif => (
                  <div key={notif.notification_id} className="p-4 flex justify-between items-center hover:bg-white/5 transition-colors">
                      <div className="flex items-center gap-4">
                          <div className={`w-2 h-2 rounded-full ${notif.type === 'compliance' ? 'bg-red-500' : 'bg-[#00D9FF]'}`} />
                          <div>
                              <div className="text-white text-sm">{notif.message}</div>
                              <div className="text-xs text-slate-500">{new Date(notif.created_at).toLocaleString()}</div>
                          </div>
                      </div>
                      <Button size="sm" variant="ghost" className="text-slate-400 hover:text-white">Dismiss</Button>
                  </div>
              ))}
          </div>
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default Notifications;
