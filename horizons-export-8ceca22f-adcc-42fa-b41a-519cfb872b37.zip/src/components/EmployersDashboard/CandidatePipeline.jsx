
import React, { useState } from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { Users, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';

const CandidatePipeline = () => {
  const { data } = useEmployerData();
  const [filter, setFilter] = useState('All');
  const stages = ['All', 'Applied', 'Shortlisted', 'Interview', 'Offer'];
  
  const filtered = filter === 'All' ? data.candidates : data.candidates.filter(c => c.stage === filter);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><Users className="w-6 h-6 text-[#00D9FF]" /> Candidate Pipeline</h2>
        <div className="flex gap-2">
            {stages.map(s => (
                <Button key={s} size="sm" variant={filter === s ? 'default' : 'outline'} onClick={() => setFilter(s)} className={filter !== s ? 'border-white/10' : ''}>
                    {s}
                </Button>
            ))}
        </div>
      </div>
      <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
        <table className="w-full text-left text-sm text-slate-300">
          <thead className="bg-slate-950 text-slate-400 uppercase text-xs">
            <tr>
              <th className="px-6 py-4">Name</th>
              <th className="px-6 py-4">Email</th>
              <th className="px-6 py-4">Phone</th>
              <th className="px-6 py-4">Stage</th>
              <th className="px-6 py-4">Applied Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {filtered.map(c => (
              <tr key={c.candidate_id} className="hover:bg-white/5 transition-colors">
                <td className="px-6 py-4 font-bold text-white">{c.name}</td>
                <td className="px-6 py-4">{c.email}</td>
                <td className="px-6 py-4">{c.phone}</td>
                <td className="px-6 py-4"><span className="px-2 py-1 rounded bg-[#00D9FF]/10 text-[#00D9FF] text-xs font-bold">{c.stage}</span></td>
                <td className="px-6 py-4">{new Date(c.created_at).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default CandidatePipeline;
