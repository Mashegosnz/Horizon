
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { Folder, Upload } from 'lucide-react';
import { Link } from 'react-router-dom';

const DocumentsVault = () => {
  const { data } = useEmployerData();
  const categories = ['Contracts', 'Policies', 'Compliance', 'Other'];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><Folder className="w-6 h-6 text-[#00D9FF]" /> HR Documents Vault</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Upload className="w-4 h-4 mr-2" /> Upload Document</Button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map(cat => {
              const count = data.documents.filter(d => d.type === cat).length;
              return (
                  <div key={cat} className="bg-slate-900 border border-white/10 rounded-xl p-6 flex flex-col items-center justify-center text-center hover:bg-slate-800 cursor-pointer transition-colors">
                      <Folder className="w-12 h-12 text-[#00D9FF] mb-4" />
                      <h3 className="font-bold text-lg mb-1">{cat}</h3>
                      <p className="text-slate-400 text-sm">{count} files</p>
                  </div>
              )
          })}
      </div>
      <div className="mt-12 bg-slate-900 border border-white/10 rounded-xl p-6">
          <h3 className="font-bold mb-4">Recent Uploads</h3>
          <div className="space-y-2">
              {data.documents.slice(0,5).map(doc => (
                  <div key={doc.document_id} className="flex justify-between items-center p-3 bg-slate-950 rounded border border-white/5 text-sm text-slate-300">
                      <div className="flex items-center gap-3"><Folder className="w-4 h-4 text-slate-500" /> {doc.name}</div>
                      <div className="text-xs text-slate-500">{new Date(doc.created_at).toLocaleDateString()}</div>
                  </div>
              ))}
          </div>
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default DocumentsVault;
