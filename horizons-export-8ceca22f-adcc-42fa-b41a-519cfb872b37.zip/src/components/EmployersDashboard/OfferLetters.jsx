
import React from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { FileText, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

const OfferLetters = () => {
  const { data } = useEmployerData();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2"><FileText className="w-6 h-6 text-[#00D9FF]" /> Offer Letters</h2>
        <Button className="bg-[#00D9FF] text-slate-950"><Plus className="w-4 h-4 mr-2" /> Create New Template</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {data.templates.map(tpl => (
              <div key={tpl.template_id} className="bg-slate-900 border border-white/10 rounded-xl p-6 hover:border-[#00D9FF]/50 transition-colors">
                  <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center mb-4"><FileText className="text-slate-400" /></div>
                  <h3 className="font-bold text-lg mb-2">{tpl.name}</h3>
                  <p className="text-xs text-slate-500 mb-6">Last updated: {new Date(tpl.created_at).toLocaleDateString()}</p>
                  <Button variant="outline" className="w-full border-white/10">Use Template</Button>
              </div>
          ))}
      </div>
      <div className="mt-6"><Link to="/employers/dashboard"><Button variant="outline" className="border-white/10">Back to Dashboard</Button></Link></div>
    </div>
  );
};
export default OfferLetters;
