import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Folder, Video, Briefcase, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const features = [
  {
    icon: FileText,
    title: "Universal Smart CV",
    description: "Build a single, powerful digital CV that evolves with your career. Update once, apply everywhere."
  },
  {
    icon: Folder,
    title: "Secure Document Hub",
    description: "Store, manage, and share your verified credentials, ID, and certificates with military-grade encryption."
  },
  {
    icon: Video,
    title: "Video Profile Studio",
    description: "Record professional introductions that showcase your communication skills and personality to employers."
  },
  {
    icon: Briefcase,
    title: "Immediate Job Matches",
    description: "Receive instant notifications for roles that match your verified skills, experience, and salary expectations."
  }
];

const CareerDashboardPreview = () => {
  return (
    <section id="career-dashboard" className="py-16 md:py-24 bg-slate-900 relative">
      <div className="container mx-auto px-4 md:px-8 lg:px-16">
        <div className="text-center mb-16 md:mb-20">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Your Career <span className="text-cyan-400 drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]">Command Center</span>
          </motion.h2>
          <motion.p 
            className="text-slate-300 text-lg max-w-2xl mx-auto font-light"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Everything you need to manage your professional identity and accelerate your career growth, all in one dashboard.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="bg-slate-950 p-8 rounded-xl border border-white/5 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10 group flex flex-col items-start"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 rounded-lg bg-slate-900 border border-white/10 flex items-center justify-center mb-6 group-hover:bg-cyan-950/30 group-hover:border-cyan-500/30 transition-all duration-300">
                <feature.icon className="w-6 h-6 text-cyan-400" />
              </div>
              <h3 className="text-lg font-bold text-white mb-3 group-hover:text-cyan-300 transition-colors">{feature.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-6 flex-grow">
                {feature.description}
              </p>
              <div className="flex items-center text-cyan-400 text-sm font-medium group-hover:translate-x-1 transition-transform cursor-pointer">
                Learn more <ChevronRight className="w-4 h-4 ml-1" />
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
             <Button className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-10 py-6 rounded-lg text-lg shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 hover:scale-105 transition-all duration-300">
                 Explore Dashboard Features
             </Button>
        </div>
      </div>
    </section>
  );
};

export default CareerDashboardPreview;