import React from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  FileCheck, 
  BarChart3, 
  Wallet, 
  Target, 
  Heart 
} from 'lucide-react';

const FeaturesOverview = () => {
  const features = [
    {
      icon: Users,
      title: 'AI-Powered Recruitment',
      description: 'Automate candidate screening, interview scheduling, and scoring with advanced AI that understands SA labour market dynamics.',
      gradient: 'from-electric-cyan to-neon-blue'
    },
    {
      icon: FileCheck,
      title: 'Compliance Automation',
      description: 'Stay compliant with BBBEE, Employment Equity Act, and labour laws with automatic reporting and alerts.',
      gradient: 'from-neon-blue to-deep-purple'
    },
    {
      icon: BarChart3,
      title: 'Employee Analytics',
      description: 'Real-time insights on performance, engagement, and retention with predictive analytics and actionable recommendations.',
      gradient: 'from-electric-cyan to-deep-purple'
    },
    {
      icon: Wallet,
      title: 'Payroll Integration',
      description: 'Seamless integration with South African payroll systems, automatic tax calculations, and UIF/SDL management.',
      gradient: 'from-neon-blue to-electric-cyan'
    },
    {
      icon: Target,
      title: 'Performance Management',
      description: 'Track OKRs, conduct reviews, and identify development needs with autonomous HR performance insights.',
      gradient: 'from-deep-purple to-neon-blue'
    },
    {
      icon: Heart,
      title: 'Talent Retention',
      description: 'Predict flight risk, measure engagement, and receive proactive recommendations to retain top talent with autonomous HR strategies.',
      gradient: 'from-electric-cyan to-white'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 40, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: 'easeOut'
      }
    }
  };

  return (
    <section id="features" className="py-24 bg-deep-space relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-1/4 left-0 w-[600px] h-[600px] bg-electric-cyan/5 rounded-full blur-[120px]" />
      <div className="absolute bottom-1/4 right-0 w-[600px] h-[600px] bg-neon-blue/5 rounded-full blur-[120px]" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">Cosmic Capabilities</span>
            <span className="text-metallic-silver"> for Modern HR</span>
          </h2>
          <p className="text-xl text-metallic-silver/70 max-w-3xl mx-auto">
            Everything you need to transform your HR operations, all powered by next-gen AI.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ scale: 1.03, y: -5 }}
              className="group"
            >
              <div className="h-full bg-dark-charcoal/80 rounded-2xl p-8 shadow-lg hover:shadow-neon transition-all duration-300 border border-white/5 hover:border-electric-cyan/50 backdrop-blur-xl relative overflow-hidden">
                {/* Glow effect on hover */}
                <div className="absolute inset-0 bg-gradient-to-br from-electric-cyan/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                {/* Icon with gradient background */}
                <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${feature.gradient} p-0.5 mb-6 group-hover:scale-110 transition-transform duration-300`}>
                   <div className="w-full h-full bg-dark-charcoal rounded-[10px] flex items-center justify-center">
                      <feature.icon className="h-8 w-8 text-white" />
                   </div>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-metallic-silver mb-3 group-hover:text-electric-cyan transition-colors duration-300">
                  {feature.title}
                </h3>

                {/* Description */}
                <p className="text-metallic-silver/60 leading-relaxed">
                  {feature.description}
                </p>

                {/* Hover Effect Line */}
                <div className="mt-8 h-0.5 bg-gradient-to-r from-electric-cyan to-neon-blue rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturesOverview;