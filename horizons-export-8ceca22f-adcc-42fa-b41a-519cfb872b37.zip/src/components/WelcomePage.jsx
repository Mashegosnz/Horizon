import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ChevronDown, Sparkles, Bot } from 'lucide-react';
import { Helmet } from 'react-helmet';

const WelcomePage = () => {
  const navigate = useNavigate();

  const handleCandidateNavigation = () => {
    // Navigates to the main Candidate Platform
    navigate('/candidates');
  };

  const handleEmployerNavigation = () => {
    navigate('/home');
  };

  return (
    <>
      <Helmet>
        <title>Welcome to Indira | Authentic Opportunity</title>
        <meta name="description" content="Welcome to Indira - Where autonomous HR meets authentic opportunity. Find your dream job or transform your HR operations." />
      </Helmet>

      <div className="relative h-screen w-full overflow-hidden bg-deep-space flex flex-col justify-center items-center">
        {/* Dynamic Background */}
        <div className="absolute inset-0 z-0">
          {/* Fallback Image */}
          <img
            src="https://images.unsplash.com/photo-1695811636867-9d8e14ec3197"
            alt="Futuristic Background"
            className="w-full h-full object-cover opacity-40 mix-blend-overlay"
          />
          
          {/* Animated Gradients / Neon Atmosphere */}
          <div className="absolute inset-0 bg-gradient-to-b from-deep-space via-transparent to-deep-space opacity-90" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(0,217,255,0.1),_rgba(26,31,77,0.8))]" />
          
          {/* "Drawing" Effect Simulation using SVG */}
          <svg className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] opacity-20 pointer-events-none" viewBox="0 0 200 200">
             <motion.path
               d="M100,60 C100,60 90,80 80,100 C70,120 70,140 100,140 C130,140 130,120 120,100"
               fill="none"
               stroke="#00D9FF"
               strokeWidth="2"
               strokeLinecap="round"
               initial={{ pathLength: 0, opacity: 0 }}
               animate={{ pathLength: [0, 1], opacity: [0, 0.5, 0] }}
               transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
             />
             <motion.circle
               cx="100" cy="50" r="4"
               fill="#00D9FF"
               initial={{ scale: 0, opacity: 0 }}
               animate={{ scale: [0, 1.5, 0], opacity: [0, 1, 0] }}
               transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
             />
          </svg>
        </div>

        {/* Header with Logo */}
        <motion.header 
          className="absolute top-0 left-0 p-6 z-20 w-full flex justify-between items-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex flex-col items-center">
             <span className="font-['Great_Vibes'] text-3xl text-electric-cyan drop-shadow-[0_0_10px_rgba(0,217,255,0.8)]">i</span>
             <span className="font-['Playfair_Display'] italic text-2xl font-bold text-electric-cyan tracking-wide -mt-2">Indira</span>
          </div>
        </motion.header>

        {/* Main Content */}
        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.h1
            className="text-4xl md:text-6xl lg:text-7xl font-black mb-8 leading-tight tracking-tight"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <span className="text-white drop-shadow-lg">Welcome to </span>
            <br className="md:hidden" />
            <span className="gradient-text font-['Playfair_Display'] italic pr-2">Authentic</span>
            <span className="text-electric-cyan drop-shadow-[0_0_20px_rgba(0,217,255,0.5)]">Opportunity</span>
          </motion.h1>

          <motion.p
            className="text-lg md:text-2xl text-metallic-silver/80 mb-16 max-w-2xl mx-auto font-light"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Bridging the gap between human potential and artificial intelligence.
          </motion.p>

          <div className="flex flex-col md:flex-row gap-6 justify-center items-center w-full max-w-4xl mx-auto">
            {/* Candidate Button - Navigates to Candidates Platform */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="w-full md:w-auto"
            >
              <Button
                size="xl"
                onClick={handleCandidateNavigation}
                className="w-full md:w-auto bg-dark-charcoal/80 backdrop-blur-md border border-electric-cyan text-electric-cyan hover:bg-electric-cyan hover:text-deep-space font-bold py-8 px-10 text-xl rounded-2xl shadow-[0_0_15px_rgba(0,217,255,0.15)] hover:shadow-[0_0_30px_rgba(0,217,255,0.6)] transition-all duration-300 group relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
                <div className="flex flex-col items-center gap-2">
                  <div className="flex items-center gap-3">
                    <Sparkles className="w-6 h-6" />
                    <span>Find Your Dream Job</span>
                  </div>
                  <span className="text-xs uppercase tracking-widest opacity-60 font-normal">For Candidates</span>
                </div>
              </Button>
            </motion.div>

            {/* Employer Button - Navigates to Home Page */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="w-full md:w-auto"
            >
              <Button
                size="xl"
                onClick={handleEmployerNavigation}
                className="w-full md:w-auto bg-electric-cyan text-deep-space hover:bg-white hover:text-deep-space font-bold py-8 px-10 text-xl rounded-2xl shadow-[0_0_20px_rgba(0,217,255,0.4)] hover:shadow-[0_0_40px_rgba(0,217,255,0.8)] transition-all duration-300 group relative overflow-hidden border-none"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
                 <div className="flex flex-col items-center gap-2">
                  <div className="flex items-center gap-3">
                    <Bot className="w-6 h-6" />
                    <span>Autonomous HR</span>
                  </div>
                  <span className="text-xs uppercase tracking-widest opacity-70 font-normal">For Employers</span>
                </div>
              </Button>
            </motion.div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-20"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1, y: [0, 10, 0] }}
          transition={{ duration: 2, delay: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ChevronDown className="h-8 w-8 text-electric-cyan animate-pulse" />
        </motion.div>
      </div>
    </>
  );
};

export default WelcomePage;