import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { CheckCircle2, Clock, CalendarDays, ArrowRight } from 'lucide-react';

const TimelineItem = ({ title, items }) => (
  <div className="relative pl-8 pb-12 last:pb-0 border-l border-[#00D9FF]/30 ml-4">
    <div className="absolute -left-[9px] top-0 w-[18px] h-[18px] rounded-full bg-slate-950 border-2 border-[#00D9FF] shadow-[0_0_10px_rgba(0,217,255,0.5)]" />
    <h3 className="text-xl font-bold text-white mb-6 -mt-1.5">{title}</h3>
    <ul className="space-y-4">
      {items.map((item, index) => (
        <motion.li 
          key={index}
          initial={{ opacity: 0, x: -10 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1 }}
          className="flex items-start gap-3 bg-slate-900/50 p-4 rounded-lg border border-white/5 hover:border-[#00D9FF]/20 transition-colors"
        >
          <CheckCircle2 className="w-5 h-5 text-[#00D9FF] flex-shrink-0 mt-0.5" />
          <span className="text-slate-300 text-sm">{item}</span>
        </motion.li>
      ))}
    </ul>
  </div>
);

const HowItWorksPractice = () => {
  return (
    <section className="py-24 px-6 bg-slate-950 relative">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="mb-4">How It Works in Practice</h2>
          <p className="text-slate-400 text-lg">From sign-up to fully autonomous operations in record time.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          {/* Day 1 */}
          <div>
            <div className="flex items-center gap-3 mb-8 text-[#00D9FF]">
              <Clock className="w-6 h-6" />
              <span className="text-lg font-bold uppercase tracking-widest">Day 1: Implementation</span>
            </div>
            <TimelineItem 
              title="Live in Hours, Not Months"
              items={[
                "Company profile & branding setup",
                "Digital contract template upload",
                "Historical employee record import",
                "Payroll system integration handshake",
                "Automated Skills Development plan generation",
                "24/7 HR Assistant goes live"
              ]}
            />
          </div>

          {/* Week 1 */}
          <div>
             <div className="flex items-center gap-3 mb-8 text-[#00D9FF]">
              <CalendarDays className="w-6 h-6" />
              <span className="text-lg font-bold uppercase tracking-widest">Week 1: Operations</span>
            </div>
            <TimelineItem 
              title="Core Ops Running Autonomously"
              items={[
                "Full compliance audit & risk report",
                "Market compensation benchmarking",
                "Workforce demographics & B-BBEE analysis",
                "Automated employee check-ins activated",
                "Talent pipeline sourcing begins",
                "First autonomous interview scheduled"
              ]}
            />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center pt-8 border-t border-white/10">
          <Link to="/pricing">
            <Button size="lg" className="w-full sm:w-auto min-w-[200px]">
              See Plans & Pricing <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
          <Button size="lg" variant="outline" className="w-full sm:w-auto min-w-[200px]">
             Book a Demo
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksPractice;