
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Helmet } from 'react-helmet';
import { Bot, ShieldCheck, ArrowRight, FileText, Banknote, Users, Scale, Zap } from 'lucide-react';
import ThreeReasonsBar from '@/components/ThreeReasonsBar';

const HomePage = () => {
  return (
    <div className="min-h-screen bg-slate-950 flex flex-col font-sans text-white">
      <Helmet>
        <title>Indira AI | Autonomous HR for South Africa</title>
        <meta name="description" content="Your Fully Autonomous HR Department. From hiring to exit, Indira runs your HR end-to-end – BCEA, EE, B-BBEE, SETAs and more." />
      </Helmet>
      
      <Navigation />

      <main className="flex-grow">
        {/* Full Screen Hero */}
        <section className="relative w-full min-h-[90vh] flex flex-col items-center justify-center px-6 overflow-hidden pt-20">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1585753035830-8205de3dd213?q=80&w=2070&auto=format&fit=crop" 
              alt="Autonomous Technology" 
              className="w-full h-full object-cover opacity-30"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-950/90 to-slate-950" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_#020617_100%)] opacity-80" />
          </div>

          <div className="relative z-10 max-w-5xl mx-auto text-center space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#00D9FF]/10 border border-[#00D9FF]/20 text-[#00D9FF] text-sm font-semibold mb-4 shadow-[0_0_15px_rgba(0,217,255,0.3)]"
            >
              <Bot className="w-4 h-4" /> 
              <span className="tracking-wide uppercase text-xs font-bold">The Future of Work is Autonomous</span>
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-white text-5xl md:text-7xl leading-tight tracking-tight drop-shadow-2xl font-extrabold"
            >
              Indira: Your Fully <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D9FF] to-white">Autonomous HR Department</span>
            </motion.h1>
            
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-lg md:text-2xl text-slate-300 font-light max-w-4xl mx-auto leading-relaxed"
            >
              From hiring to exit, Indira runs your HR end-to-end – <span className="text-white font-medium">BCEA, EE, B-BBEE, SETAs</span> and more – with AI-driven automation built for South Africa. Once plugged in, it runs on autopilot.
            </motion.h2>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-6 justify-center pt-8"
            >
              <Link to="/employers">
                <Button size="lg" className="w-full sm:w-auto min-w-[280px] text-lg h-16 shadow-[0_0_20px_rgba(0,217,255,0.4)] border-none font-bold bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90">
                  <Zap className="w-5 h-5 mr-2" /> For Employers: Switch On Autonomous HR
                </Button>
              </Link>
              <Link to="/candidates">
                <Button size="lg" variant="outline" className="w-full sm:w-auto min-w-[240px] text-lg h-16 border-[#00D9FF]/50 text-white hover:bg-[#00D9FF]/10">
                  For Candidates: Find Your Dream Job
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* 3 Reasons Bar */}
        <ThreeReasonsBar />

        {/* Capabilities Teaser */}
        <section id="compliance-section" className="py-24 px-6 bg-slate-950 relative">
           <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                 <h2 className="mb-4 text-3xl font-bold">When We Say <span className="text-[#00D9FF]">Fully Automated</span>, We Mean It</h2>
                 <p className="text-slate-400 text-lg max-w-2xl mx-auto">
                    Indira acts as your proactive HR partner, managing the entire employee lifecycle from recruitment to offboarding. Plug and play.
                 </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                 <div className="bg-slate-900 border border-white/10 rounded-xl p-8 hover:border-[#00D9FF]/30 transition-colors">
                    <div className="w-12 h-12 bg-[#00D9FF]/10 rounded-lg flex items-center justify-center mb-6">
                       <Bot className="w-6 h-6 text-[#00D9FF]" />
                    </div>
                    <h3 className="mb-4 text-xl font-bold">It Hires & Manages for You</h3>
                    <p className="text-slate-400">
                       Indira sources talent, schedules interviews, and manages onboarding docs. Once hired, it tracks leave, performance, and training needs automatically.
                    </p>
                 </div>
                 <div className="bg-slate-900 border border-white/10 rounded-xl p-8 hover:border-[#00D9FF]/30 transition-colors">
                    <div className="w-12 h-12 bg-[#00D9FF]/10 rounded-lg flex items-center justify-center mb-6">
                       <Scale className="w-6 h-6 text-[#00D9FF]" />
                    </div>
                    <h3 className="mb-4 text-xl font-bold">It Protects Your Business</h3>
                    <p className="text-slate-400">
                       Predictive analytics identify compliance risks (CCMA, BCEA, EE Act) and pay equity gaps before they become costly liabilities.
                    </p>
                 </div>
              </div>
           </div>
        </section>

        {/* Feature Teaser Cards */}
        <section id="automation-section" className="py-20 px-6 bg-slate-900/30 relative">
          <div className="max-w-7xl mx-auto">
             <div className="text-center mb-16">
                 <h2 className="mb-4 text-3xl font-bold">Why Choose Autonomous HR?</h2>
                 <p className="text-slate-400">Replace administrative burden with strategic intelligence.</p>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { icon: FileText, title: "Contracts & Compliance", desc: "Auto-generates BCEA-compliant contracts and monitors legislative updates." },
                  { icon: Banknote, title: "Payroll Integration", desc: "Seamlessly integrates with payroll systems for automated salary benchmarking and slips." },
                  { icon: ShieldCheck, title: "Risk & B-BBEE", desc: "Predictive compliance audits for POPIA, EE Act, and B-BBEE scorecards." },
                  { icon: Users, title: "Performance Cycles", desc: "Runs automated check-ins and generates 360° feedback reports." }
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="bg-slate-950 p-6 rounded-xl border border-white/5 hover:border-[#00D9FF]/40 transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[#00D9FF]/10"
                  >
                    <div className="w-12 h-12 bg-[#00D9FF]/10 rounded-lg flex items-center justify-center mb-4">
                      <item.icon className="w-6 h-6 text-[#00D9FF]" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                    <p className="text-sm text-slate-400">{item.desc}</p>
                  </motion.div>
                ))}
             </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 px-6 bg-[#00D9FF]/5 relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80')] bg-cover bg-center opacity-5 mix-blend-overlay"></div>
          <div className="max-w-4xl mx-auto text-center relative z-10">
            <h2 className="mb-6 text-4xl font-bold">Ready to Automate Your HR?</h2>
            <p className="text-xl text-slate-300 mb-8">
              Join forward-thinking South African companies using Indira to reduce admin by 80% and compliance risks by 95%.
            </p>
            <Link to="/employers/pricing">
              <Button size="lg" className="h-16 px-8 text-xl shadow-[0_0_20px_rgba(0,217,255,0.3)] bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 font-bold">
                Get Started Now <ArrowRight className="ml-2 w-6 h-6" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;
