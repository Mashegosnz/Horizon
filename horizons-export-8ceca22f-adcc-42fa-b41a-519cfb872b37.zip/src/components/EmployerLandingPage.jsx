
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Bot, ShieldCheck, Zap, BarChart, CheckCircle } from 'lucide-react';

const EmployerLandingPage = () => {
  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
         <div className="absolute inset-0 z-0">
             <img src="https://images.unsplash.com/photo-1686061592689-312bbfb5c055?q=80&w=2070&auto=format&fit=crop" alt="Abstract Data" className="w-full h-full object-cover opacity-20 mix-blend-overlay" />
             <div className="absolute inset-0 bg-gradient-to-b from-slate-950/90 via-slate-950/80 to-slate-950" />
         </div>

         <div className="container mx-auto px-6 relative z-10 text-center">
             <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00D9FF]/10 text-[#00D9FF] text-sm font-bold mb-6 border border-[#00D9FF]/20">
                 <Zap className="w-4 h-4" /> 24/7 Autonomous HR
             </motion.div>
             
             <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 leading-tight drop-shadow-lg">
                 Autonomous HR for <br />
                 <span className="text-white">South African Businesses</span>
             </motion.h1>

             <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto mb-12 drop-shadow-md">
                 Indira automates your HR, compliance, and people operations. Focus on growth while we handle BCEA, EE, B-BBEE, and more on autopilot.
             </motion.p>

             <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="flex flex-col sm:flex-row gap-6 justify-center">
                 <Link to="/employers/pricing">
                     <Button size="lg" className="h-16 px-10 text-xl font-bold bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90 shadow-[0_0_30px_rgba(0,217,255,0.3)]">
                         Choose Plan
                     </Button>
                 </Link>
                 <Link to="/employers/capabilities">
                     <Button size="lg" variant="outline" className="h-16 px-10 text-xl border-white/20 hover:bg-white/10 backdrop-blur-sm">
                         Learn More
                     </Button>
                 </Link>
             </motion.div>
         </div>
      </section>

      {/* Features */}
      <section className="py-24 px-6 bg-slate-900/50">
          <div className="container mx-auto max-w-6xl">
              <div className="text-center mb-16">
                  <h2 className="text-3xl font-bold mb-4">Everything You Need, Fully Automated</h2>
                  <p className="text-slate-400">Replace administrative burden with strategic intelligence.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                      { icon: Bot, title: "End-to-End Automation", desc: "From drafting contracts to managing leave and payroll syncing, it runs continuously." },
                      { icon: ShieldCheck, title: "SA Compliance Native", desc: "Built for South Africa. Predicts BCEA risks and tracks B-BBEE scorecards instantly." },
                      { icon: BarChart, title: "Executive Analytics", desc: "Board-ready reports on attrition, performance, and pay equity generated in seconds." }
                  ].map((f, i) => (
                      <div key={i} className="bg-slate-950 p-8 rounded-2xl border border-white/10 hover:border-[#00D9FF]/30 transition-all hover:-translate-y-2 hover:shadow-2xl">
                          <div className="w-14 h-14 bg-[#00D9FF]/10 text-[#00D9FF] rounded-xl flex items-center justify-center mb-6"><f.icon className="w-7 h-7" /></div>
                          <h3 className="text-xl font-bold mb-3">{f.title}</h3>
                          <p className="text-slate-400">{f.desc}</p>
                      </div>
                  ))}
              </div>
          </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-6 bg-slate-950">
          <div className="container mx-auto max-w-6xl">
              <h2 className="text-3xl font-bold text-center mb-12">Trusted by Forward-Thinking SA Companies</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-slate-900 border border-white/10 p-8 rounded-2xl relative">
                      <div className="text-5xl text-[#00D9FF]/20 absolute top-4 left-6">"</div>
                      <p className="text-lg text-slate-300 italic mb-6 relative z-10 pt-6">Indira acts as a team of 5 HR experts. We cleared our CCMA backlog and improved our B-BBEE level without hiring consultants.</p>
                      <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center font-bold">TM</div>
                          <div><div className="font-bold">Thabo M.</div><div className="text-sm text-[#00D9FF]">Operations Director, BuildSA</div></div>
                      </div>
                  </div>
                  <div className="bg-slate-900 border border-white/10 p-8 rounded-2xl relative">
                      <div className="text-5xl text-[#00D9FF]/20 absolute top-4 left-6">"</div>
                      <p className="text-lg text-slate-300 italic mb-6 relative z-10 pt-6">The payroll integration alone saved us days of admin. Highly recommend Indira for any scaling tech business.</p>
                      <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center font-bold">SL</div>
                          <div><div className="font-bold">Sarah L.</div><div className="text-sm text-[#00D9FF]">CEO, FinTech Dynamics</div></div>
                      </div>
                  </div>
              </div>
          </div>
      </section>

      {/* Final CTA */}
      <section className="py-32 px-6 bg-[#00D9FF]/5 relative text-center">
          <div className="max-w-3xl mx-auto relative z-10">
              <h2 className="text-4xl font-bold mb-6">Ready to transform your HR?</h2>
              <p className="text-xl text-slate-400 mb-10">Join companies automating their HR operations today.</p>
              <Link to="/employers/pricing">
                  <Button size="lg" className="h-16 px-12 text-xl font-bold bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90">
                      Get Started <CheckCircle className="w-5 h-5 ml-2" />
                  </Button>
              </Link>
          </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default EmployerLandingPage;
