import React from 'react';
import { motion } from 'framer-motion';
import { User, FileText, Folder, Video, Briefcase, Target, ArrowRight } from 'lucide-react';

const steps = [
  { id: 1, icon: User, title: "Quick Sign-Up", label: "Create your secure account in seconds." },
  { id: 2, icon: FileText, title: "Universal Smart CV", label: "Build a dynamic profile that stands out." },
  { id: 3, icon: Folder, title: "Document Hub", label: "Upload and verify your credentials." },
  { id: 4, icon: Video, title: "Video Profile Studio", label: "Record your professional introduction." },
  { id: 5, icon: Briefcase, title: "Profile Dashboard", label: "Track profile completion and status." },
  { id: 6, icon: Target, title: "Immediate Matches", label: "Get matched with top employers instantly." },
];

const CandidatesTimeline = () => {
  return (
    <section className="py-16 md:py-24 bg-slate-950 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-8 lg:px-16">
        <div className="text-center mb-20">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            The Path to <span className="text-cyan-400 drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]">Hired</span>
          </motion.h2>
          <motion.p 
            className="text-slate-300 text-lg"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Your streamlined journey from candidate to career success.
          </motion.p>
        </div>

        <div className="relative max-w-7xl mx-auto">
          {/* Connecting Line (Desktop) */}
          <div className="hidden lg:block absolute top-16 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent z-0" />
          
          {/* Connecting Line (Mobile) */}
          <div className="lg:hidden absolute top-0 left-10 h-full w-0.5 bg-gradient-to-b from-cyan-500/10 via-cyan-500/20 to-transparent z-0" />

          <div className="grid grid-cols-1 lg:grid-cols-6 gap-8 lg:gap-4 relative z-10">
            {steps.map((step, index) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="flex lg:flex-col items-center gap-6 lg:gap-8 lg:text-center group relative"
              >
                {/* Icon Circle */}
                <div className="relative w-20 h-20 lg:w-32 lg:h-32 flex-shrink-0 flex items-center justify-center">
                  <div className="absolute inset-0 bg-slate-900 rounded-full border border-white/10 group-hover:border-cyan-500/50 group-hover:shadow-[0_0_25px_rgba(6,182,212,0.25)] transition-all duration-300 z-20" />
                  <div className="absolute inset-2 bg-slate-950 rounded-full z-20 flex items-center justify-center">
                     <step.icon className="w-8 h-8 lg:w-10 lg:h-10 text-cyan-400 group-hover:text-white group-hover:scale-110 transition-all duration-300" />
                  </div>
                  
                  {/* Step Number Badge */}
                  <div className="absolute top-0 right-0 lg:top-1 lg:right-2 w-7 h-7 bg-cyan-500 rounded-full flex items-center justify-center text-slate-950 font-bold text-xs z-30 shadow-lg shadow-cyan-500/30 border-2 border-slate-900">
                    {step.id}
                  </div>
                </div>

                {/* Text Content */}
                <div className="flex-1 lg:flex-none bg-slate-900/40 p-5 rounded-xl border border-white/5 lg:bg-transparent lg:p-0 lg:border-0 backdrop-blur-sm lg:backdrop-blur-none hover:bg-slate-900/60 transition-colors lg:hover:bg-transparent">
                  <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-cyan-400 transition-colors">{step.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed">{step.label}</p>
                </div>
                
                {/* Arrow for Desktop flow */}
                {index < steps.length - 1 && (
                   <div className="hidden lg:block absolute top-16 -right-1/2 text-cyan-500/20 z-0 transform translate-x-1/2">
                      <ArrowRight className="w-5 h-5" />
                   </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CandidatesTimeline;