import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Linkedin, Twitter, Facebook } from 'lucide-react';
const Footer = () => {
  const currentYear = new Date().getFullYear();
  const quickLinks = [{
    name: 'Features',
    href: '#features'
  }, {
    name: 'Pricing',
    href: '#pricing'
  }, {
    name: 'About Us',
    href: '#about'
  }, {
    name: 'Contact',
    href: '#contact'
  }];
  const legalLinks = [{
    name: 'Privacy Policy',
    href: '#privacy'
  }, {
    name: 'Terms of Service',
    href: '#terms'
  }, {
    name: 'POPIA Compliance',
    href: '#popia'
  }];
  const socialLinks = [{
    icon: Linkedin,
    href: '#',
    label: 'LinkedIn'
  }, {
    icon: Twitter,
    href: '#',
    label: 'Twitter'
  }, {
    icon: Facebook,
    href: '#',
    label: 'Facebook'
  }];
  return <footer className="bg-deep-space border-t border-white/5 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-electric-cyan to-transparent opacity-50" />
      
      <div className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Company Info */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-electric-cyan to-neon-blue flex items-center justify-center shadow-neon">
                <span className="text-xl font-bold text-white">I</span>
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">Indira</span>
            </div>
            <p className="text-metallic-silver/60 mb-8 leading-relaxed">
              Autonomous HR for South African businesses. Transform your HR operations with cutting-edge automation.
            </p>
            <div className="flex gap-4">
              {socialLinks.map((social, index) => <a key={index} href={social.href} aria-label={social.label} className="w-10 h-10 rounded-lg bg-dark-charcoal border border-white/10 hover:border-electric-cyan hover:bg-electric-cyan/10 flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-neon">
                  <social.icon className="h-5 w-5 text-metallic-silver hover:text-electric-cyan transition-colors" />
                </a>)}
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: 0.1
        }}>
            <p className="text-lg font-bold text-white mb-6 uppercase tracking-wider text-sm">Quick Links</p>
            <ul className="space-y-4">
              {quickLinks.map((link, index) => <li key={index}>
                  <a href={link.href} className="text-metallic-silver/60 hover:text-electric-cyan transition-colors duration-300 flex items-center gap-2 group">
                    <span className="w-1.5 h-1.5 bg-electric-cyan rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-[0_0_5px_#00d9ff]" />
                    {link.name}
                  </a>
                </li>)}
            </ul>
          </motion.div>

          {/* Legal */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: 0.2
        }}>
            <p className="text-lg font-bold text-white mb-6 uppercase tracking-wider text-sm">Legal</p>
            <ul className="space-y-4">
              {legalLinks.map((link, index) => <li key={index}>
                  <a href={link.href} className="text-metallic-silver/60 hover:text-electric-cyan transition-colors duration-300 flex items-center gap-2 group">
                    <span className="w-1.5 h-1.5 bg-electric-cyan rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-[0_0_5px_#00d9ff]" />
                    {link.name}
                  </a>
                </li>)}
            </ul>
          </motion.div>

          {/* Contact */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: 0.3
        }}>
            <p className="text-lg font-bold text-white mb-6 uppercase tracking-wider text-sm">Contact Us</p>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-metallic-silver/60 group">
                <Mail className="h-5 w-5 text-electric-cyan flex-shrink-0 mt-0.5 group-hover:drop-shadow-[0_0_5px_rgba(0,217,255,0.5)] transition-all" />
                <span className="group-hover:text-white transition-colors">service@indira.co.za</span>
              </li>
              <li className="flex items-start gap-3 text-metallic-silver/60 group">
                <Phone className="h-5 w-5 text-electric-cyan flex-shrink-0 mt-0.5 group-hover:drop-shadow-[0_0_5px_rgba(0,217,255,0.5)] transition-all" />
                <span className="group-hover:text-white transition-colors">+27 11 123 4567</span>
              </li>
              <li className="flex items-start gap-3 text-metallic-silver/60 group">
                <MapPin className="h-5 w-5 text-electric-cyan flex-shrink-0 mt-0.5 group-hover:drop-shadow-[0_0_5px_rgba(0,217,255,0.5)] transition-all" />
                <span className="group-hover:text-white transition-colors">Sandton, Johannesburg<br />South Africa</span>
              </li>
            </ul>
          </motion.div>
        </div>

        {/* Bottom Bar */}
        <motion.div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6" initial={{
        opacity: 0
      }} whileInView={{
        opacity: 1
      }} viewport={{
        once: true
      }} transition={{
        duration: 0.6,
        delay: 0.4
      }}>
          <p className="text-metallic-silver/40 text-sm text-center md:text-left font-mono">
            © {currentYear} Indira AI. All rights reserved.
          </p>
          <p className="text-metallic-silver/40 text-sm text-center md:text-right font-mono flex items-center gap-2">
            Built with <span className="text-electric-cyan">⚡</span> for the Future
          </p>
        </motion.div>
      </div>
    </footer>;
};
export default Footer;