import React from 'react';
import { motion } from 'framer-motion';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle, ArrowRight, Calendar, CreditCard, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import { PLANS, getPlanSavings } from '@/context/EmployerContext';

const SubscriptionConfirmation = () => {
  const [searchParams] = useSearchParams();
  const planKey = searchParams.get('plan') || 'Starter';
  const billingPeriod = searchParams.get('billing') || 'monthly';
  
  const plan = PLANS[planKey];
  const price = billingPeriod === 'monthly' ? plan.monthlyPrice : plan.yearlyPrice;
  const savings = billingPeriod === 'yearly' ? getPlanSavings(planKey) : null;
  const nextBillingDate = new Date();
  nextBillingDate.setDate(nextBillingDate.getDate() + (billingPeriod === 'yearly' ? 365 : 30));

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col">
       <Navigation />
       
       <main className="flex-grow flex items-center justify-center p-6 relative overflow-hidden pt-24 pb-12">
         {/* Background glow */}
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#00D9FF]/5 rounded-full blur-[120px] pointer-events-none" />

         <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="max-w-2xl w-full bg-slate-900 border border-white/10 rounded-2xl p-8 md:p-12 shadow-2xl relative z-10"
         >
            <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-8 text-emerald-500 ring-1 ring-emerald-500/30">
               <CheckCircle className="w-10 h-10" />
            </div>
            
            <h1 className="text-3xl font-bold text-white mb-2 text-center">Subscription Confirmed!</h1>
            <p className="text-lg text-slate-400 mb-10 text-center">
               You're all set. Your autonomous HR environment is ready.
            </p>

            <div className="bg-slate-950 border border-white/5 rounded-xl p-6 mb-8 space-y-4">
                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                    <span className="text-slate-400">Plan</span>
                    <span className="text-white font-bold text-lg">{plan.name}</span>
                </div>
                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                    <span className="text-slate-400">Billing Period</span>
                    <div className="text-right">
                        <span className="text-white font-bold capitalize block">{billingPeriod}</span>
                        <span className="text-xs text-slate-500 block">Next billing: {nextBillingDate.toLocaleDateString()}</span>
                    </div>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">Price</span>
                    <div className="text-right">
                        <span className="text-[#00D9FF] font-bold text-xl">R{price.toLocaleString()}</span>
                        <span className="text-xs text-slate-500 block">
                            per {billingPeriod === 'monthly' ? 'month' : 'year'}, billed {billingPeriod}
                        </span>
                    </div>
                </div>
                {savings && (
                    <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3 text-center">
                        <span className="text-emerald-400 text-sm font-bold">
                            🎉 You saved R{savings.amount.toLocaleString()} with annual billing!
                        </span>
                    </div>
                )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
                <div className="flex flex-col items-center text-center p-4 bg-slate-950/50 rounded-lg border border-white/5">
                    <Calendar className="w-6 h-6 text-slate-400 mb-2" />
                    <span className="text-xs text-slate-400">Cancel anytime</span>
                </div>
                <div className="flex flex-col items-center text-center p-4 bg-slate-950/50 rounded-lg border border-white/5">
                    <CreditCard className="w-6 h-6 text-slate-400 mb-2" />
                    <span className="text-xs text-slate-400">Secure payment</span>
                </div>
                <div className="flex flex-col items-center text-center p-4 bg-slate-950/50 rounded-lg border border-white/5">
                    <ShieldCheck className="w-6 h-6 text-slate-400 mb-2" />
                    <span className="text-xs text-slate-400">Money-back guarantee</span>
                </div>
            </div>

            <div className="space-y-4">
                <Link to={`/employer-signup?plan=${planKey}&billing=${billingPeriod}`}>
                   <Button className="w-full h-14 text-lg shadow-lg shadow-[#00D9FF]/20">
                      Set up Employer Account <ArrowRight className="ml-2 w-5 h-5" />
                   </Button>
                </Link>
                <div className="text-center">
                    <Link to="/pricing" className="text-sm text-slate-500 hover:text-slate-300 transition-colors">
                       Change plan
                    </Link>
                </div>
            </div>
         </motion.div>
       </main>
    </div>
  );
};

export default SubscriptionConfirmation;