import React from 'react';
import { Helmet } from 'react-helmet';
import Navigation from '@/components/Navigation';
import IndiraCapabilities from '@/components/IndiraCapabilities';
import IndiraExperienceLevels from '@/components/IndiraExperienceLevels';
import HowItWorksPractice from '@/components/HowItWorksPractice';
import Footer from '@/components/Footer';
import { Link } from 'react-router-dom';
import { ChevronRight, ShieldAlert, FileText, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const IndiraCapabilitiesPage = () => {
  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white">
      <Helmet>
        <title>Capabilities | Indira Jobs - Fully Automated HR</title>
        <meta name="description" content="Explore the full capabilities of Indira's autonomous HR system for South African businesses." />
      </Helmet>
      
      <Navigation />

      <main className="pt-24">
        {/* Breadcrumb / Header */}
        <div className="bg-slate-900 border-b border-white/5 py-12 px-6">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="mb-4">When We Say <span className="text-[#00D9FF]">Fully Automated</span>, We Mean It</h1>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">
                Indira is not a passive tool. It is an active agent that hires, manages compliance, and optimizes your workforce strategy.
            </p>
          </div>
        </div>

        {/* Feature Blocks */}
        <section className="py-20 px-6 max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="bg-slate-900 border border-white/10 rounded-xl p-8">
                    <FileText className="w-10 h-10 text-[#00D9FF] mb-6" />
                    <h3 className="mb-4">Complete Employee Lifecycle</h3>
                    <p className="text-slate-400 mb-6">From generating the first offer letter to processing the final exit settlement. Indira manages documents, leave, performance reviews, and training assignments automatically.</p>
                    <div className="text-xs font-bold text-[#00D9FF] uppercase">Automated by Indira</div>
                </div>
                <div className="bg-slate-900 border border-white/10 rounded-xl p-8">
                    <ShieldAlert className="w-10 h-10 text-[#00D9FF] mb-6" />
                    <h3 className="mb-4">SA Compliance & Risk</h3>
                    <p className="text-slate-400 mb-6">Stay safe with automated updates for BCEA, LRA, and EE Act. Indira monitors your compliance status in real-time and alerts you to risks like pay equity gaps.</p>
                    <div className="text-xs font-bold text-[#00D9FF] uppercase">Automated by Indira</div>
                </div>
                <div className="bg-slate-900 border border-white/10 rounded-xl p-8">
                    <BarChart3 className="w-10 h-10 text-[#00D9FF] mb-6" />
                    <h3 className="mb-4">Strategic HR Insights</h3>
                    <p className="text-slate-400 mb-6">Turn data into decisions. Track B-BBEE scorecard progress, predict employee turnover, and optimize your skills development spending with AI-driven analytics.</p>
                    <div className="text-xs font-bold text-[#00D9FF] uppercase">AI-Powered</div>
                </div>
            </div>
        </section>

        <IndiraCapabilities />
        
        <div className="bg-slate-900 py-12">
           <div className="max-w-7xl mx-auto px-6 h-px bg-white/10" />
        </div>

        <IndiraExperienceLevels />

        <div className="bg-slate-950 py-12">
           <div className="max-w-7xl mx-auto px-6 h-px bg-white/10" />
        </div>

        <HowItWorksPractice />
        
        <div className="py-24 text-center">
            <Link to="/pricing">
                <Button size="lg">View Plans & Pricing</Button>
            </Link>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default IndiraCapabilitiesPage;