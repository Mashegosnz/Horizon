
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Check } from 'lucide-react';

const EmployersSignupPage = () => {
    const [searchParams] = useSearchParams();
    const purchaseId = searchParams.get('purchase_id');
    const { data } = useEmployerData();
    const purchase = data.purchases.find(p => p.purchase_id === purchaseId);
    
    const navigate = useNavigate();
    const { toast } = useToast();

    const [form, setForm] = useState({ 
        email: purchase?.email || '', 
        fullName: '', 
        phone: purchase?.phone || '', 
        password: '', 
        confirmPassword: '' 
    });

    // Simple strength logic
    const strength = form.password.length === 0 ? 0 : form.password.length < 8 ? 1 : /[A-Z]/.test(form.password) && /[0-9]/.test(form.password) ? 3 : 2;
    const strengthColors = ['bg-slate-800', 'bg-red-500', 'bg-yellow-500', 'bg-emerald-500'];
    const strengthText = ['', 'Weak', 'Fair', 'Strong'];

    const handleSubmit = (e) => {
        e.preventDefault();
        if (form.password !== form.confirmPassword) {
            return toast({ title: "Error", description: "Passwords do not match.", variant: "destructive" });
        }
        if (strength < 2) {
            return toast({ title: "Error", description: "Please use a stronger password.", variant: "destructive" });
        }
        
        toast({ title: "Account Created!", description: "Let's set up your profile." });
        navigate(`/employers/profile-setup?purchase_id=${purchaseId}`);
    };

    return (
        <div className="min-h-screen bg-slate-950 font-sans text-white flex items-center justify-center p-6">
            <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#00D9FF] to-blue-500" />
                <div className="text-center mb-8">
                    <h1 className="text-2xl font-bold mb-2">Create Your Account</h1>
                    <p className="text-slate-400 text-sm">You're one step away from autonomous HR.</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <input required placeholder="Full Name" value={form.fullName} onChange={e=>setForm({...form, fullName: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white focus:border-[#00D9FF] outline-none" />
                    <input type="email" required placeholder="Email Address" value={form.email} onChange={e=>setForm({...form, email: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white focus:border-[#00D9FF] outline-none" />
                    <input type="tel" required placeholder="Phone Number" value={form.phone} onChange={e=>setForm({...form, phone: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white focus:border-[#00D9FF] outline-none" />
                    
                    <div>
                        <input type="password" required placeholder="Password" value={form.password} onChange={e=>setForm({...form, password: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white focus:border-[#00D9FF] outline-none" />
                        <div className="flex items-center gap-2 mt-2">
                            <div className="flex gap-1 flex-1">
                                {[1,2,3].map(i => <div key={i} className={`h-1 flex-1 rounded-full ${i <= strength ? strengthColors[strength] : 'bg-slate-800'}`} />)}
                            </div>
                            <span className="text-xs text-slate-500 w-10 text-right">{strengthText[strength]}</span>
                        </div>
                    </div>
                    
                    <input type="password" required placeholder="Confirm Password" value={form.confirmPassword} onChange={e=>setForm({...form, confirmPassword: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white focus:border-[#00D9FF] outline-none" />
                    
                    <Button type="submit" className="w-full bg-[#00D9FF] text-slate-950 font-bold mt-6 h-12">Create Account</Button>
                </form>

                <div className="mt-6 text-center text-sm text-slate-400">
                    Already have an account? <Link to="/employers/login" className="text-[#00D9FF] hover:underline">Log in</Link>
                </div>
            </div>
        </div>
    );
};
export default EmployersSignupPage;
