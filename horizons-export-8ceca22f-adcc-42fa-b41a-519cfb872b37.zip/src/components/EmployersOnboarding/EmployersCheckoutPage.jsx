
import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ShieldCheck, Loader2 } from 'lucide-react';
import Navigation from '@/components/Navigation';

const EmployersCheckoutPage = () => {
    const [searchParams] = useSearchParams();
    const planId = searchParams.get('plan') || 'starter';
    const { data, addPurchase } = useEmployerData();
    const plan = data.packages.find(p => p.id === planId) || data.packages[0];
    const navigate = useNavigate();
    const { toast } = useToast();

    const [form, setForm] = useState({ companyName: '', email: '', phone: '', fullName: '', paymentMethod: 'payfast', terms: false });
    const [loading, setLoading] = useState(false);

    const price = plan.monthlyPrice;
    const vat = price * 0.15;
    const total = price + vat;

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);
        // Simulate payment processing
        setTimeout(() => {
            const purchaseId = `purch_${Date.now()}`;
            addPurchase({
                purchase_id: purchaseId, package_id: plan.id, company_name: form.companyName, 
                email: form.email, phone: form.phone, amount: total, currency: 'ZAR', 
                status: 'paid', payment_method: form.paymentMethod, created_at: new Date().toISOString()
            });
            toast({ title: "Payment Successful!", description: "Your subscription is active." });
            navigate(`/employers/signup?purchase_id=${purchaseId}`);
            setLoading(false);
        }, 2000);
    };

    return (
        <div className="min-h-screen bg-slate-950 font-sans text-white">
            <Navigation />
            <div className="pt-32 pb-20 px-6 max-w-6xl mx-auto">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    
                    {/* Order Summary */}
                    <div className="order-2 lg:order-1 space-y-6">
                        <div className="bg-slate-900 border border-white/10 rounded-2xl p-8 sticky top-32">
                            <h2 className="text-2xl font-bold mb-6">Order Summary</h2>
                            <div className="flex justify-between items-center pb-6 border-b border-white/10 mb-6">
                                <div>
                                    <div className="font-bold text-xl">{plan.name}</div>
                                    <div className="text-sm text-slate-400">Monthly billing</div>
                                </div>
                                <div className="text-2xl font-bold text-[#00D9FF]">R{price.toLocaleString()}</div>
                            </div>
                            <div className="space-y-3 text-slate-300 mb-6">
                                <div className="flex justify-between"><span>Subtotal</span><span>R{price.toLocaleString()}</span></div>
                                <div className="flex justify-between"><span>VAT (15%)</span><span>R{vat.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</span></div>
                            </div>
                            <div className="flex justify-between items-center pt-6 border-t border-white/10 text-xl font-bold text-white mb-8">
                                <span>Total Due</span>
                                <span>R{total.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-emerald-500 bg-emerald-500/10 p-3 rounded-lg">
                                <ShieldCheck className="w-5 h-5" /> Secured by bank-grade encryption
                            </div>
                        </div>
                    </div>

                    {/* Billing Form */}
                    <div className="order-1 lg:order-2">
                        <h1 className="text-3xl font-bold mb-8">Billing Details</h1>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="text-sm text-slate-400">Company Name *</label>
                                    <input required value={form.companyName} onChange={e=>setForm({...form, companyName: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg p-3 outline-none focus:border-[#00D9FF] text-white" />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm text-slate-400">Full Name *</label>
                                    <input required value={form.fullName} onChange={e=>setForm({...form, fullName: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg p-3 outline-none focus:border-[#00D9FF] text-white" />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm text-slate-400">Email Address *</label>
                                    <input type="email" required value={form.email} onChange={e=>setForm({...form, email: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg p-3 outline-none focus:border-[#00D9FF] text-white" />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm text-slate-400">Phone Number *</label>
                                    <input type="tel" required value={form.phone} onChange={e=>setForm({...form, phone: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg p-3 outline-none focus:border-[#00D9FF] text-white" />
                                </div>
                            </div>
                            
                            <div className="pt-6">
                                <label className="text-sm text-slate-400 block mb-4">Payment Method</label>
                                <div className="grid grid-cols-2 gap-4">
                                    <label className={`cursor-pointer border rounded-lg p-4 flex items-center gap-3 transition-colors ${form.paymentMethod === 'payfast' ? 'border-[#00D9FF] bg-[#00D9FF]/5' : 'border-white/10 bg-slate-900'}`}>
                                        <input type="radio" name="payment" checked={form.paymentMethod === 'payfast'} onChange={() => setForm({...form, paymentMethod: 'payfast'})} className="accent-[#00D9FF]" />
                                        <span className="font-bold">PayFast (ZA)</span>
                                    </label>
                                    <label className={`cursor-pointer border rounded-lg p-4 flex items-center gap-3 transition-colors ${form.paymentMethod === 'paypal' ? 'border-[#00D9FF] bg-[#00D9FF]/5' : 'border-white/10 bg-slate-900'}`}>
                                        <input type="radio" name="payment" checked={form.paymentMethod === 'paypal'} onChange={() => setForm({...form, paymentMethod: 'paypal'})} className="accent-[#00D9FF]" />
                                        <span className="font-bold">PayPal</span>
                                    </label>
                                </div>
                            </div>

                            <label className="flex items-start gap-3 mt-6 cursor-pointer">
                                <input type="checkbox" required checked={form.terms} onChange={e=>setForm({...form, terms: e.target.checked})} className="mt-1 accent-[#00D9FF]" />
                                <span className="text-sm text-slate-400">I agree to the Terms of Service and authorize this recurring payment.</span>
                            </label>

                            <div className="flex gap-4 pt-6">
                                <Button type="button" variant="outline" onClick={() => navigate('/employers/pricing')} className="flex-1 border-white/10 hover:bg-white/5">Back</Button>
                                <Button type="submit" disabled={loading} className="flex-2 w-full bg-[#00D9FF] text-slate-950 font-bold hover:bg-[#00D9FF]/90">
                                    {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Processing...</> : `Complete Purchase (R${total.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})})`}
                                </Button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    );
};
export default EmployersCheckoutPage;
