
import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useEmployerData } from '@/context/EmployerDataContext';
import { useEmployer } from '@/context/EmployerContext'; // System Auth
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { CheckCircle, Upload } from 'lucide-react';

const EmployersProfileSetupWizard = () => {
    const [searchParams] = useSearchParams();
    const purchaseId = searchParams.get('purchase_id');
    const { data, addEmployerProfile } = useEmployerData();
    const { login } = useEmployer(); // Mocking login completion
    const purchase = data.purchases.find(p => p.purchase_id === purchaseId);
    
    const navigate = useNavigate();
    const { toast } = useToast();

    const [step, setStep] = useState(1);
    const [form, setForm] = useState({
        companyName: purchase?.company_name || '', industry: 'Technology', size: '1-50', website: '',
        hrName: '', hrEmail: '', hrPhone: '',
        employees: '', locations: '', primaryLocation: '', payroll: 'None',
    });

    const handleNext = (e) => {
        e.preventDefault();
        if (step < 4) setStep(step + 1);
        else handleComplete();
    };

    const handleComplete = () => {
        // Create profile in data context
        addEmployerProfile({
            employer_id: `emp_${Date.now()}`,
            purchase_id: purchaseId,
            package_id: purchase?.package_id || 'starter',
            company_name: form.companyName,
            status: 'complete'
        });
        
        // Mock system login so ProtectedRoute passes
        try {
           login('mock@company.com', 'password'); // assuming mock doesn't crash
        } catch(e) { /* ignore mock error */ }

        toast({ title: "Setup Complete!", description: "Your HR department is ready." });
        navigate('/employers/dashboard');
    };

    return (
        <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col items-center justify-center p-6">
            <div className="w-full max-w-2xl bg-slate-900 border border-white/10 rounded-2xl p-8 shadow-2xl">
                
                {/* Progress */}
                <div className="mb-8">
                    <div className="flex justify-between text-xs font-bold text-slate-500 mb-2 px-1">
                        <span>Step {step} of 4</span>
                        <span className="text-[#00D9FF]">{Math.round((step/4)*100)}%</span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-2">
                        <div className="bg-[#00D9FF] h-2 rounded-full transition-all duration-500" style={{ width: `${(step/4)*100}%` }}></div>
                    </div>
                </div>

                <form onSubmit={handleNext}>
                    {step === 1 && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                            <h2 className="text-2xl font-bold mb-4">Company Details</h2>
                            <input required placeholder="Company Name" value={form.companyName} onChange={e=>setForm({...form, companyName: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none" />
                            <select value={form.industry} onChange={e=>setForm({...form, industry: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none">
                                <option>Technology</option><option>Retail</option><option>Finance</option><option>Other</option>
                            </select>
                            <select value={form.size} onChange={e=>setForm({...form, size: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none">
                                <option>1-50</option><option>51-200</option><option>201-500</option><option>500+</option>
                            </select>
                            <input placeholder="Website (Optional)" value={form.website} onChange={e=>setForm({...form, website: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none" />
                        </div>
                    )}

                    {step === 2 && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                            <h2 className="text-2xl font-bold mb-4">HR Contacts</h2>
                            <input required placeholder="Primary HR Contact Name" value={form.hrName} onChange={e=>setForm({...form, hrName: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none" />
                            <input required type="email" placeholder="HR Email Address" value={form.hrEmail} onChange={e=>setForm({...form, hrEmail: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none" />
                            <input required type="tel" placeholder="HR Phone Number" value={form.hrPhone} onChange={e=>setForm({...form, hrPhone: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none" />
                        </div>
                    )}

                    {step === 3 && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                            <h2 className="text-2xl font-bold mb-4">Workforce Info</h2>
                            <div className="grid grid-cols-2 gap-4">
                                <input required type="number" placeholder="Total Employees" value={form.employees} onChange={e=>setForm({...form, employees: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none" />
                                <input required type="number" placeholder="Locations Count" value={form.locations} onChange={e=>setForm({...form, locations: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none" />
                            </div>
                            <input required placeholder="Primary Location (e.g. Cape Town)" value={form.primaryLocation} onChange={e=>setForm({...form, primaryLocation: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none" />
                            <select value={form.payroll} onChange={e=>setForm({...form, payroll: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white outline-none">
                                <option>Sage</option><option>Pastel</option><option>SimplePay</option><option>Custom</option><option>None</option>
                            </select>
                        </div>
                    )}

                    {step === 4 && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                            <h2 className="text-2xl font-bold mb-4">Upload HR Policies (Optional)</h2>
                            <div className="border-2 border-dashed border-white/20 rounded-xl p-12 flex flex-col items-center justify-center text-center cursor-pointer hover:border-[#00D9FF]/50 transition-colors bg-slate-950/50">
                                <Upload className="w-10 h-10 text-slate-400 mb-4" />
                                <p className="font-bold text-white mb-1">Drag and drop or click to upload</p>
                                <p className="text-xs text-slate-500 mb-4">PDF, DOCX accepted.</p>
                                <p className="text-xs text-slate-400 bg-white/5 px-3 py-1 rounded-full">Examples: Employee handbook, Code of conduct</p>
                            </div>
                        </div>
                    )}

                    <div className="flex justify-between mt-8 pt-6 border-t border-white/10">
                        {step > 1 ? (
                            <Button type="button" variant="ghost" onClick={() => setStep(step-1)}>Back</Button>
                        ) : <div />}
                        <Button type="submit" className="bg-[#00D9FF] text-slate-950 font-bold px-8">
                            {step === 4 ? <><CheckCircle className="w-4 h-4 mr-2" /> Complete Setup</> : 'Next Step'}
                        </Button>
                    </div>
                </form>
            </div>
        </div>
    );
};
export default EmployersProfileSetupWizard;
