
import React, { useState, useEffect } from 'react';
import { useEmployerData } from '@/context/EmployerDataContext';
import { Button } from '@/components/ui/button';
import { CheckCircle, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import Navigation from '@/components/Navigation';

const EmployersPricingPage = () => {
    const { data } = useEmployerData();
    const [isYearly, setIsYearly] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Simulate data loading
        const timer = setTimeout(() => setLoading(false), 500);
        return () => clearTimeout(timer);
    }, []);

    if (loading) return <div className="min-h-screen bg-slate-950 pt-24 text-center text-[#00D9FF]">Loading pricing...</div>;
    if (!data.packages) return <div className="min-h-screen bg-slate-950 pt-24 text-center text-red-500">Unable to load pricing. Please refresh the page.</div>;

    return (
        <div className="min-h-screen bg-slate-950 font-sans text-white">
            <Navigation />
            
            {/* Hero */}
            <section className="relative pt-32 pb-20 px-6 text-center overflow-hidden">
                <div className="absolute inset-0 z-0">
                    <img src="https://images.unsplash.com/photo-1697638164340-6c5fc558bdf2?q=80&w=2070&auto=format&fit=crop" alt="Abstract tech" className="w-full h-full object-cover opacity-10 mix-blend-overlay" />
                    <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-950 to-slate-950" />
                </div>
                <div className="relative z-10 max-w-4xl mx-auto">
                    <h1 className="text-5xl md:text-6xl font-extrabold mb-6 tracking-tight">Choose Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D9FF] to-white">Autonomous HR Plan</span></h1>
                    <p className="text-xl text-slate-400 mb-12">Select the plan that fits your business size and HR needs.</p>
                    
                    {/* Toggle */}
                    <div className="inline-flex items-center p-1.5 bg-slate-900 border border-white/10 rounded-full">
                        <button onClick={() => setIsYearly(false)} className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all ${!isYearly ? 'bg-[#00D9FF] text-slate-950' : 'text-slate-400 hover:text-white'}`}>Monthly</button>
                        <button onClick={() => setIsYearly(true)} className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all flex items-center gap-2 ${isYearly ? 'bg-[#00D9FF] text-slate-950' : 'text-slate-400 hover:text-white'}`}>
                            Yearly <span className="bg-emerald-500 text-white text-[10px] px-2 py-0.5 rounded-full">Save ~15%</span>
                        </button>
                    </div>
                </div>
            </section>

            {/* Pricing Cards */}
            <section className="py-16 px-6 relative z-10">
                <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
                    {data.packages.map((pkg) => (
                        <div key={pkg.id} className={`relative bg-slate-900 border rounded-2xl p-8 flex flex-col transition-all duration-300 ${pkg.id === 'growth' ? 'border-[#00D9FF]/50 shadow-[0_0_30px_rgba(0,217,255,0.15)] md:-mt-4 md:mb-4' : 'border-white/10 hover:border-white/30'}`}>
                            {pkg.id === 'growth' && <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#00D9FF] text-slate-950 text-xs font-bold px-4 py-1 rounded-full uppercase tracking-wider">Most Popular</div>}
                            {pkg.id === 'enterprise' && <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-slate-800 text-slate-300 border border-white/10 text-xs font-bold px-4 py-1 rounded-full uppercase tracking-wider">For Large Orgs</div>}
                            
                            <h3 className="text-2xl font-bold mb-2">{pkg.name}</h3>
                            <p className="text-sm text-slate-400 mb-6 h-10">{pkg.id === 'starter' ? 'Core HR Admin + Compliance on Autopilot' : pkg.id === 'growth' ? 'Complete HR Toolkit + Strategic Insights' : 'Complete HR Department in a Box'}</p>
                            
                            <div className="mb-8">
                                <span className="text-5xl font-extrabold">R{isYearly ? pkg.yearlyPrice.toLocaleString() : pkg.monthlyPrice.toLocaleString()}</span>
                                <span className="text-slate-500">/{isYearly ? 'yr' : 'mo'}</span>
                            </div>

                            <Link to={`/employers/checkout?plan=${pkg.id}`} className="mt-auto block mb-8">
                                <Button className={`w-full h-12 text-lg font-bold shadow-[0_0_15px_rgba(0,217,255,0.3)] ${pkg.id === 'growth' ? 'bg-[#00D9FF] text-slate-950 hover:bg-[#00D9FF]/90' : 'bg-slate-800 text-white hover:bg-slate-700'}`}>
                                    Choose {pkg.name.split(' ')[1]}
                                </Button>
                            </Link>

                            <div className="space-y-4 text-sm text-slate-300">
                                <div className="font-semibold text-white border-b border-white/10 pb-2">Includes:</div>
                                <div className="flex items-center gap-3"><CheckCircle className="w-4 h-4 text-[#00D9FF]" /> Up to {pkg.employees} employees</div>
                                <div className="flex items-center gap-3"><CheckCircle className="w-4 h-4 text-[#00D9FF]" /> {pkg.adminSeats} admin seats</div>
                                {pkg.features.map((f, i) => (
                                    <div key={i} className="flex items-center gap-3"><CheckCircle className="w-4 h-4 text-[#00D9FF]" /> {f}</div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* FAQ */}
            <section className="py-24 px-6 bg-slate-900/50">
                <div className="max-w-3xl mx-auto">
                    <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
                    <div className="space-y-6">
                        {['What\'s included?', 'Can I change plans?', 'What\'s your cancellation policy?'].map((q, i) => (
                            <div key={i} className="bg-slate-950 border border-white/10 p-6 rounded-xl">
                                <h4 className="font-bold flex items-center gap-2 mb-2"><HelpCircle className="w-5 h-5 text-[#00D9FF]" /> {q}</h4>
                                <p className="text-slate-400 text-sm ml-7">Our plans are designed to scale with you. You get full access to the core autonomous engine on all plans, with advanced features unlocking as you grow. You can upgrade, downgrade, or cancel at any time directly from your dashboard.</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </div>
    );
};
export default EmployersPricingPage;
