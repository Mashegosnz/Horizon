import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, PlayCircle, Briefcase, Building } from 'lucide-react';

const stories = [
  {
    id: 1,
    name: "Lerato M.",
    role: "Full Stack Developer",
    company: "TechFlow CPT",
    statsBefore: "8 months searching",
    statsAfter: "Hired in 10 days",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=1000&auto=format&fit=crop", 
    quote: "Indira allowed me to showcase my actual coding skills, not just list them. The video profile was a game changer."
  },
  {
    id: 2,
    name: "Sipho N.",
    role: "Process Engineer",
    company: "AutoMfg SA",
    statsBefore: "Unnoticed applications",
    statsAfter: "3 Interview Offers",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=1000&auto=format&fit=crop",
    quote: "The verification badge made employers trust my qualifications immediately. I didn't have to prove myself from scratch."
  },
  {
    id: 3,
    name: "Jessica D.",
    role: "Digital Marketer",
    company: "Growth Agency",
    statsBefore: "Freelancing only",
    statsAfter: "Permanent Role",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1000&auto=format&fit=crop",
    quote: "I found a company culture that actually fits my personality. The AI matching is surprisingly accurate."
  },
  {
    id: 4,
    name: "David K.",
    role: "Data Analyst",
    company: "FinServ Corp",
    statsBefore: "Wrong industry fit",
    statsAfter: "25% Salary Increase",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1000&auto=format&fit=crop",
    quote: "It was seamless. Uploaded my docs, did the video, and the dashboard showed me matches the next day."
  },
  {
    id: 5,
    name: "Thandiwe Z.",
    role: "Operations Manager",
    company: "Logistics Pro",
    statsBefore: "Stagnant career",
    statsAfter: "Senior Promotion",
    image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?q=80&w=1000&auto=format&fit=crop",
    quote: "Employers saw my potential for leadership through the soft skills assessment. Highly recommended."
  }
];

const CandidatesSuccessStories = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      handleNext();
    }, 6000);
    return () => clearInterval(timer);
  }, [currentIndex]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % stories.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + stories.length) % stories.length);
  };

  return (
    <section className="py-24 bg-slate-950 relative">
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Success Stories</h2>
          <div className="w-24 h-1 bg-cyan-500 mx-auto rounded-full shadow-[0_0_10px_rgba(34,211,238,0.8)]" />
        </motion.div>

        <div className="max-w-6xl mx-auto relative">
          {/* Navigation Buttons */}
          <button 
            onClick={handlePrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 z-20 p-3 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950 transition-all shadow-lg"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <button 
            onClick={handleNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 z-20 p-3 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950 transition-all shadow-lg"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="relative overflow-hidden min-h-[500px] md:min-h-[400px] bg-slate-900 rounded-2xl border border-cyan-500/20 shadow-2xl">
            <AnimatePresence mode='wait'>
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0 p-8 md:p-12 flex flex-col md:flex-row items-center gap-8 md:gap-12"
              >
                {/* Video/Image Placeholder */}
                <div className="w-full md:w-1/2 aspect-video bg-slate-800 rounded-xl relative overflow-hidden group border border-white/10">
                  <img 
                    src={stories[currentIndex].image} 
                    alt={stories[currentIndex].name}
                    className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity duration-500"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-cyan-500/20 backdrop-blur-sm border border-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 cursor-pointer">
                      <PlayCircle className="w-8 h-8 text-cyan-400 fill-current" />
                    </div>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <p className="text-white font-bold text-lg drop-shadow-md">{stories[currentIndex].name}</p>
                    <p className="text-cyan-400 text-sm flex items-center gap-2">
                      <Briefcase className="w-3 h-3" /> {stories[currentIndex].role}
                    </p>
                  </div>
                </div>

                {/* Content */}
                <div className="w-full md:w-1/2 flex flex-col justify-center text-left">
                  <div className="mb-6">
                    <h3 className="text-3xl font-bold text-white mb-2">{stories[currentIndex].name}</h3>
                    <div className="flex items-center gap-2 text-cyan-400 font-medium">
                      <Building className="w-4 h-4" />
                      <span>{stories[currentIndex].role} at {stories[currentIndex].company}</span>
                    </div>
                  </div>

                  <blockquote className="text-slate-300 text-lg italic mb-8 border-l-4 border-cyan-500 pl-4 leading-relaxed">
                    "{stories[currentIndex].quote}"
                  </blockquote>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-950 p-4 rounded-lg border border-red-500/20">
                      <p className="text-slate-500 text-xs uppercase tracking-wider mb-1">Before</p>
                      <p className="text-red-400 font-bold">{stories[currentIndex].statsBefore}</p>
                    </div>
                    <div className="bg-slate-950 p-4 rounded-lg border border-green-500/20">
                      <p className="text-slate-500 text-xs uppercase tracking-wider mb-1">After</p>
                      <p className="text-green-400 font-bold">{stories[currentIndex].statsAfter}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
          
          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 mt-8">
            {stories.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  idx === currentIndex ? 'w-8 bg-cyan-500' : 'w-2 bg-slate-700 hover:bg-slate-600'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CandidatesSuccessStories;