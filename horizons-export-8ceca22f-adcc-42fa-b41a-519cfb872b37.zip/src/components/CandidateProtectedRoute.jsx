
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useCandidate } from '@/context/CandidateContext';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

const CandidateProtectedRoute = ({ children }) => {
  const { candidateUser, loading } = useCandidate();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-[#00D9FF]">
        <Loader2 className="w-8 h-8 animate-spin mb-4" />
        <p>Loading your portal...</p>
      </div>
    );
  }

  if (!candidateUser) {
    return <Navigate to="/candidates/login" state={{ from: location }} replace />;
  }

  return children;
};

export default CandidateProtectedRoute;
