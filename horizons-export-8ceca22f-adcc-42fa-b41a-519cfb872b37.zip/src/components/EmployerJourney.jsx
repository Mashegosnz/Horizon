import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ChevronDown, Plus, Search, BarChart3, Users, Home, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CandidateCard from '@/components/ui/CandidateCard';
import MetricCard from '@/components/ui/MetricCard';
import ComingSoonBadge from '@/components/ui/ComingSoonBadge';
import PlatformNavigation from '@/components/CandidatePlatform/PlatformNavigation';
import Footer from '@/components/Footer';

const Section = ({ title, description, children, id, className }) => (
  <section id={id} className={`py-24 border-b border-white/5 ${className}`}>
    <div className="container mx-auto px-4 md:px-8">
      <div className="mb-12 max-w-3xl">
        <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">{title}</h2>
        <p className="text-xl text-slate-300 font-light leading-relaxed">{description}</p>
      </div>
      {children}
    </div>
  </section>
);

const EmployerJourney = () => {
  const section1Ref = useRef(null);
  const section2Ref = useRef(null);
  const section3Ref = useRef(null);

  const scrollToRef = (ref) => ref.current?.scrollIntoView({ behavior: 'smooth' });

  return (
    <>
      <Helmet>
        <title>Employer Platform | Indira AI</title>
      </Helmet>

      <div className="bg-slate-950 min-h-screen text-slate-200 selection:bg-cyan-500 selection:text-slate-950 font-sans">
        {/* Using standard navigation but could be employer specific */}
        <PlatformNavigation />

        {/* Hero Section */}
        <section className="relative h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
             <img 
               src="https://images.unsplash.com/photo-1686061592689-312bbfb5c055" 
               alt="Employer Dashboard" 
               className="w-full h-full object-cover opacity-30"
             />
             <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-950/60 to-slate-950" />
          </div>
          
          <div className="container relative z-10 px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
                Autonomous <span className="text-cyan-400">HR Intelligence</span>
              </h1>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-10 font-light">
                Streamline your hiring, automate compliance, and find the perfect talent with AI-driven precision.
              </p>
              <div className="flex flex-col md:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => scrollToRef(section1Ref)}
                  size="lg" 
                  className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-8 py-6 rounded-lg text-lg shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 transition-all"
                >
                  View Dashboard Demo
                </Button>
                <Link to="/">
                  <Button variant="outline" size="lg" className="border-white/10 text-white hover:bg-white/5 hover:text-cyan-400 px-8 py-6 rounded-lg text-lg">
                    <Home className="mr-2 w-5 h-5" /> Back to Home
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
          
          <motion.div 
            className="absolute bottom-10 left-1/2 -translate-x-1/2 text-cyan-400 animate-bounce cursor-pointer"
            onClick={() => scrollToRef(section1Ref)}
          >
            <ChevronDown className="w-8 h-8" />
          </motion.div>
        </section>

        {/* Section 1: Job Creation */}
        <div ref={section1Ref}>
          <Section 
            title="Smart Job Creation" 
            description="Create comprehensive job specifications in seconds. Our AI suggests requirements, skills, and market-related salary ranges based on your needs."
          >
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
               <div className="lg:col-span-2 bg-slate-900 border border-white/5 rounded-xl p-8 relative overflow-hidden group hover:border-cyan-500/30 transition-all">
                  <div className="flex justify-between items-center mb-6">
                     <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <Plus className="w-5 h-5 text-cyan-400" /> New Job Posting
                     </h3>
                     <ComingSoonBadge />
                  </div>
                  <div className="space-y-4 opacity-70">
                     <div className="h-10 bg-slate-950 rounded border border-white/5 w-full" />
                     <div className="grid grid-cols-2 gap-4">
                        <div className="h-10 bg-slate-950 rounded border border-white/5" />
                        <div className="h-10 bg-slate-950 rounded border border-white/5" />
                     </div>
                     <div className="h-32 bg-slate-950 rounded border border-white/5 w-full" />
                  </div>
                  <div className="mt-6 flex justify-end">
                     <Button className="bg-cyan-500/20 text-cyan-400 cursor-not-allowed">Auto-Generate Description</Button>
                  </div>
               </div>

               <div className="space-y-4">
                  <div className="bg-slate-900 border border-white/5 rounded-xl p-6">
                     <h4 className="text-white font-bold mb-4">Active Listings</h4>
                     <div className="space-y-3">
                        <div className="p-3 bg-slate-950 rounded border-l-2 border-green-500">
                           <p className="text-sm font-bold text-white">Senior React Dev</p>
                           <p className="text-xs text-slate-400">12 Candidates Applied</p>
                        </div>
                        <div className="p-3 bg-slate-950 rounded border-l-2 border-yellow-500">
                           <p className="text-sm font-bold text-white">Product Designer</p>
                           <p className="text-xs text-slate-400">Draft - Incomplete</p>
                        </div>
                     </div>
                  </div>
                  <Button 
                    onClick={() => scrollToRef(section2Ref)}
                    className="w-full py-6 border border-white/10 hover:bg-white/5 text-slate-300"
                    variant="outline"
                  >
                    Next: Find Candidates <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
               </div>
            </div>
          </Section>
        </div>

        {/* Section 2: Candidate Discovery */}
        <div ref={section2Ref}>
          <Section 
            title="Intelligent Discovery" 
            description="Stop sifting through hundreds of CVs. Our matching engine presents you with pre-verified, highly compatible candidates sorted by relevance."
            className="bg-slate-900/50"
          >
            <div className="mb-8 flex flex-wrap gap-4 items-center">
               <div className="relative flex-1 min-w-[300px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                  <input 
                     type="text" 
                     placeholder="Search by skill, role, or keyword..." 
                     className="w-full bg-slate-950 border border-white/10 rounded-lg py-3 pl-10 pr-4 text-white focus:outline-none focus:border-cyan-500 transition-colors"
                     disabled
                  />
               </div>
               <Button variant="outline" className="border-cyan-500/30 text-cyan-400">
                  <span className="flex items-center gap-2"><div className="w-2 h-2 bg-green-500 rounded-full" /> Verified Only</span>
               </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
               <CandidateCard 
                  name="Michael Chen"
                  role="Full Stack Engineer"
                  match={97}
                  skills={["React", "Node.js", "AWS"]}
                  image="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop"
               />
               <CandidateCard 
                  name="Zola Mthembu"
                  role="UI/UX Lead"
                  match={94}
                  skills={["Figma", "User Research", "Prototyping"]}
                  image="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=150&h=150&fit=crop"
               />
               <CandidateCard 
                  name="David Naidoo"
                  role="DevOps Specialist"
                  match={88}
                  skills={["Docker", "Kubernetes", "CI/CD"]}
                  image="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop"
               />
            </div>
            
            <div className="mt-8 flex justify-end">
               <Button 
                 onClick={() => scrollToRef(section3Ref)}
                 className="py-6 px-8 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
               >
                 View Analytics <ArrowRight className="ml-2 w-5 h-5" />
               </Button>
            </div>
          </Section>
        </div>

        {/* Section 3: Analytics */}
        <div ref={section3Ref}>
          <Section 
            title="Hiring Analytics" 
            description="Make data-driven decisions with real-time insights into your recruitment pipeline, time-to-hire, and budget efficiency."
          >
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                <MetricCard 
                   title="Time to Hire"
                   value="12 Days"
                   trend="15%"
                   trendUp={true}
                   icon={BarChart3}
                />
                <MetricCard 
                   title="Active Candidates"
                   value="45"
                   trend="8%"
                   trendUp={true}
                   icon={Users}
                />
                <MetricCard 
                   title="Cost per Hire"
                   value="R 8,500"
                   trend="20%"
                   trendUp={false} // Decreasing cost is good, visually styled in component
                   icon={BarChart3}
                />
                <MetricCard 
                   title="Offer Acceptance"
                   value="92%"
                   trend="5%"
                   trendUp={true}
                   icon={Users}
                />
             </div>
             
             <div className="bg-slate-900 border border-white/5 rounded-xl p-8 flex items-center justify-center min-h-[300px] relative overflow-hidden">
                <div className="text-center z-10">
                   <BarChart3 className="w-16 h-16 text-cyan-500/20 mx-auto mb-4" />
                   <h3 className="text-2xl font-bold text-white mb-2">Deep Analytics Dashboard</h3>
                   <ComingSoonBadge />
                </div>
                {/* Abstract Chart Background */}
                <div className="absolute inset-0 flex items-end justify-between px-8 pb-8 opacity-10 gap-4">
                   {[40, 70, 50, 90, 60, 80, 50, 70, 60, 90].map((h, i) => (
                      <div key={i} className="w-full bg-cyan-500 rounded-t" style={{ height: `${h}%` }} />
                   ))}
                </div>
             </div>

             <div className="mt-16 text-center">
               <Link to="/">
                 <Button size="lg" variant="outline" className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 px-10 py-6 text-lg">
                   <Home className="mr-2 w-5 h-5" /> Back to Home
                 </Button>
               </Link>
             </div>
          </Section>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default EmployerJourney;