import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { 
  ArrowRight, FileText, ShieldCheck, Sparkles, 
  ChevronRight, Upload, Video, User, Briefcase, ChevronLeft, CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import SectionDivider from '@/components/ui/SectionDivider';
import Badge from '@/components/ui/Badge';
import Card from '@/components/ui/Card';

const FeatureCard = ({ icon: Icon, title, desc }) => (
  <Card className="flex flex-col items-start h-full">
    <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center mb-6 text-cyan-400 group-hover:scale-110 transition-transform duration-300">
      <Icon className="w-6 h-6" />
    </div>
    <h3 className="text-xl font-bold text-white mb-3">{title}</h3>
    <p className="text-slate-400 leading-relaxed text-sm">{desc}</p>
  </Card>
);

const TimelineStep = ({ number, title, active }) => (
  <div className={`flex flex-col items-center gap-3 relative z-10 ${active ? 'opacity-100' : 'opacity-40'}`}>
    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-all duration-300 ${active ? 'bg-cyan-500 border-cyan-500 text-slate-950 scale-110 shadow-[0_0_15px_rgba(0,217,255,0.5)]' : 'bg-slate-900 border-slate-700 text-slate-500'}`}>
      {number}
    </div>
    <span className={`text-xs font-medium uppercase tracking-wider text-center max-w-[100px] ${active ? 'text-cyan-400' : 'text-slate-600'}`}>{title}</span>
  </div>
);

const StepContent = ({ title, description, children, onNext, onBack, isLast }) => (
  <motion.div 
    initial={{ opacity: 0, x: 20 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: -20 }}
    transition={{ duration: 0.4 }}
    className="w-full max-w-5xl mx-auto"
  >
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
      <div>
        <h2 className="text-3xl font-bold text-white mb-4">{title}</h2>
        <p className="text-lg text-slate-300 mb-8 font-light">{description}</p>
        
        <div className="flex gap-4 mt-8">
           {onBack && (
             <Button variant="outline" onClick={onBack} className="border-white/10 text-slate-400 hover:text-white">
               <ChevronLeft className="mr-2 w-4 h-4" /> Back
             </Button>
           )}
           {isLast ? (
             <Button className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-8 shadow-lg shadow-emerald-500/20">
                Finish <CheckCircle className="ml-2 w-4 h-4" />
             </Button>
           ) : (
             <Button onClick={onNext} className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-8 shadow-lg shadow-cyan-500/20">
               Next Step <ArrowRight className="ml-2 w-4 h-4" />
             </Button>
           )}
        </div>
      </div>
      
      <div className="relative">
         {/* Mockup Container */}
         <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden shadow-2xl min-h-[400px] flex flex-col">
            <div className="h-8 bg-slate-950 border-b border-white/5 flex items-center px-4 gap-2">
               <div className="w-3 h-3 rounded-full bg-red-500/20"></div>
               <div className="w-3 h-3 rounded-full bg-yellow-500/20"></div>
               <div className="w-3 h-3 rounded-full bg-green-500/20"></div>
            </div>
            <div className="flex-grow p-6 relative">
               {children}
            </div>
         </div>
         {/* Decorative Blur */}
         <div className="absolute -inset-4 bg-cyan-500/20 blur-3xl -z-10 rounded-full opacity-20 pointer-events-none" />
      </div>
    </div>
  </motion.div>
);

const CandidatesJourney = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const flowRef = useRef(null);

  const scrollToFlow = () => {
    flowRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, 4));
  const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 1));

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-300">
      <Helmet>
        <title>Candidates Journey | Indira AI</title>
        <meta name="description" content="Build your Smart CV, verify your documents, and get matched with top employers." />
      </Helmet>
      
      <Navigation />

      <main>
        {/* Section 1: Hero */}
        <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0">
             <div className="absolute inset-0 bg-slate-950/70 z-10" />
             <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950 z-10" />
             <img src="https://images.unsplash.com/photo-1607615896122-6c919f897e55" alt="Candidate Hero" className="w-full h-full object-cover" />
          </div>
          
          <div className="container px-6 relative z-20 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight"
            >
              Your Career, <span className="text-cyan-400 text-glow">Fully Expressed.</span><br/>
              Your Potential, <span className="text-white">Fully Seen.</span>
            </motion.h1>
            
            <motion.div
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               transition={{ delay: 0.4, duration: 0.8 }}
            >
               <Button onClick={scrollToFlow} size="lg" className="mt-8 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-10 py-6 text-xl rounded-xl shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 hover:scale-105 transition-all">
                  Start Your Profile
               </Button>
            </motion.div>
          </div>
        </section>

        {/* Section 2: Value Prop */}
        <section className="py-24 px-6 bg-slate-950">
           <div className="container mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                 <FeatureCard 
                    icon={FileText} 
                    title="Beyond the Resume" 
                    desc="Static documents can't capture your drive. Express your full potential through dynamic profiling." 
                 />
                 <FeatureCard 
                    icon={ShieldCheck} 
                    title="Verified & Authentic" 
                    desc="Stand out instantly. Our blockchain-backed verification for ID and qualifications builds trust." 
                 />
                 <FeatureCard 
                    icon={Sparkles} 
                    title="Intelligent Matching" 
                    desc="Stop applying into the void. Our AI connects you with opportunities that match your goals." 
                 />
              </div>
           </div>
        </section>

        <SectionDivider />

        {/* Section 3: Timeline */}
        <section className="py-24 px-6 bg-slate-950">
           <div className="container mx-auto">
              <h2 className="text-center text-3xl font-bold text-white mb-16">How It Works</h2>
              <div className="relative flex justify-between items-center max-w-4xl mx-auto">
                 {/* Connecting Line */}
                 <div className="absolute top-5 left-0 right-0 h-0.5 bg-slate-800 -z-0"></div>
                 
                 <TimelineStep number="1" title="Smart CV" active={true} />
                 <TimelineStep number="2" title="Doc Hub" active={true} />
                 <TimelineStep number="3" title="Video Studio" active={true} />
                 <TimelineStep number="4" title="Dashboard" active={true} />
                 <TimelineStep number="5" title="Matches" active={false} />
              </div>
           </div>
        </section>

        {/* Section 4: Interactive Flow */}
        <section ref={flowRef} className="py-24 px-6 bg-slate-900/30 border-y border-white/5">
           <div className="container mx-auto">
              <AnimatePresence mode='wait'>
                 {currentStep === 1 && (
                    <StepContent 
                       key="step1"
                       title="Step 1: Smart CV"
                       description="Our AI extracts your skills and experience to build a dynamic, living profile. Update it once, and it evolves with you."
                       onNext={nextStep}
                    >
                       {/* Smart CV Mockup */}
                       <div className="space-y-4">
                          <div className="flex justify-between items-center mb-4">
                             <h4 className="font-bold text-white">Profile Builder</h4>
                             <Badge variant="cyan">Coming Soon</Badge>
                          </div>
                          <div className="space-y-3 opacity-60 pointer-events-none">
                             <div className="h-10 bg-slate-800 rounded w-full border border-white/5" />
                             <div className="grid grid-cols-2 gap-3">
                                <div className="h-10 bg-slate-800 rounded border border-white/5" />
                                <div className="h-10 bg-slate-800 rounded border border-white/5" />
                             </div>
                             <div className="h-24 bg-slate-800 rounded w-full border border-white/5" />
                          </div>
                          <div className="flex items-center gap-2 text-cyan-400 text-sm mt-4">
                             <Sparkles className="w-4 h-4" /> AI Auto-Fill Enabled
                          </div>
                       </div>
                    </StepContent>
                 )}

                 {currentStep === 2 && (
                    <StepContent 
                       key="step2"
                       title="Step 2: Document Hub"
                       description="Securely upload your ID, degrees, and certificates. We verify them instantly, building immediate trust with employers."
                       onNext={nextStep}
                       onBack={prevStep}
                    >
                       {/* Document Hub Mockup */}
                       <div className="h-full flex flex-col justify-center items-center text-center space-y-6">
                          <div className="w-20 h-20 rounded-full border-2 border-dashed border-slate-600 flex items-center justify-center">
                             <Upload className="w-8 h-8 text-slate-500" />
                          </div>
                          <div>
                             <h4 className="text-white font-bold">Upload Documents</h4>
                             <p className="text-slate-400 text-sm">Drag & drop ID, transcripts, etc.</p>
                          </div>
                          <Badge variant="cyan">Coming Soon</Badge>
                       </div>
                    </StepContent>
                 )}

                 {currentStep === 3 && (
                    <StepContent 
                       key="step3"
                       title="Step 3: Video Profile Studio"
                       description="Showcase your personality and communication skills. Record a short intro that stands out before the interview."
                       onNext={nextStep}
                       onBack={prevStep}
                    >
                       {/* Video Studio Mockup */}
                       <div className="relative aspect-video bg-black rounded-lg overflow-hidden flex items-center justify-center border border-white/10">
                          <img src="https://images.unsplash.com/photo-1573165231977-3f0e27806045" alt="Video Preview" className="absolute inset-0 w-full h-full object-cover opacity-50" />
                          <div className="relative z-10 flex flex-col items-center gap-2">
                             <div className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                                <div className="w-4 h-4 bg-white rounded-sm" />
                             </div>
                             <Badge variant="outline" className="bg-black/50 backdrop-blur">REC 00:00</Badge>
                          </div>
                          <div className="absolute top-4 right-4">
                             <Badge variant="cyan">Coming Soon</Badge>
                          </div>
                       </div>
                    </StepContent>
                 )}

                 {currentStep === 4 && (
                    <StepContent 
                       key="step4"
                       title="Step 4: Profile Dashboard"
                       description="Track your visibility, manage your verified credentials, and see real-time job matches tailored to your profile."
                       onBack={prevStep}
                       isLast
                    >
                       {/* Dashboard Mockup */}
                       <div className="space-y-4">
                          <div className="flex items-center gap-3 mb-6">
                             <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center border border-cyan-500">
                                <User className="w-6 h-6 text-cyan-400" />
                             </div>
                             <div>
                                <h4 className="text-white font-bold">Thandiwe N.</h4>
                                <div className="w-32 h-1.5 bg-slate-800 rounded-full mt-1 overflow-hidden">
                                   <div className="h-full w-[75%] bg-cyan-500" />
                                </div>
                             </div>
                          </div>
                          
                          <h5 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">Top Matches</h5>
                          <div className="space-y-2">
                             {[1, 2, 3].map((i) => (
                                <div key={i} className="p-3 bg-slate-950 rounded border border-white/5 flex justify-between items-center">
                                   <div className="flex items-center gap-3">
                                      <Briefcase className="w-4 h-4 text-slate-500" />
                                      <div>
                                         <p className="text-sm font-bold text-white">Frontend Dev</p>
                                         <p className="text-xs text-slate-500">Cape Town • Remote</p>
                                      </div>
                                   </div>
                                   <Badge variant="success">9{i}% Match</Badge>
                                </div>
                             ))}
                          </div>
                          <div className="pt-2 text-center">
                             <Badge variant="cyan">Coming Soon</Badge>
                          </div>
                       </div>
                    </StepContent>
                 )}
              </AnimatePresence>
           </div>
        </section>

        {/* Section 5: Success Stories */}
        <section className="py-24 px-6 bg-slate-950">
           <div className="container mx-auto text-center max-w-4xl">
              <h2 className="text-3xl font-bold text-white mb-12">Success Stories</h2>
              <Card className="p-8 md:p-12 bg-slate-900/50">
                 <p className="text-2xl text-slate-200 italic font-light mb-8">"Indira's automated verification meant I skipped two rounds of interviews. I was hired in record time."</p>
                 <div className="flex items-center justify-center gap-4">
                    <img src="https://images.unsplash.com/photo-1493882552576-fce827c6161e" alt="User" className="w-12 h-12 rounded-full object-cover border-2 border-cyan-500" />
                    <div className="text-left">
                       <p className="text-white font-bold">Michael T.</p>
                       <p className="text-cyan-400 text-sm">Senior Developer</p>
                    </div>
                 </div>
              </Card>
           </div>
        </section>

        <Footer />
      </main>
    </div>
  );
};

export default CandidatesJourney;