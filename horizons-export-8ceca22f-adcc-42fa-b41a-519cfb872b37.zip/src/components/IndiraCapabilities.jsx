import React from 'react';
import { motion } from 'framer-motion';
import { Bot, ShieldCheck, TrendingUp, AlertTriangle, Scale, Users, FileCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const FeatureBlock = ({ icon: Icon, title, description, plan, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay }}
    className="bg-slate-900 border border-white/10 rounded-xl p-8 hover:border-[#00D9FF]/50 hover:shadow-[0_0_20px_rgba(0,217,255,0.1)] hover:scale-[1.02] transition-all duration-300 group h-full flex flex-col"
  >
    <div className="w-12 h-12 bg-[#00D9FF]/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-[#00D9FF]/20 transition-colors">
      <Icon className="w-6 h-6 text-[#00D9FF] drop-shadow-[0_0_8px_rgba(0,217,255,0.6)]" />
    </div>
    <h3 className="text-xl font-bold text-white mb-4">{title}</h3>
    <p className="text-slate-400 mb-6 flex-grow">{description}</p>
    <div className="mt-auto pt-4 border-t border-white/5">
      <span className="text-xs text-[#00D9FF] uppercase tracking-wider font-bold">Included in {plan}</span>
    </div>
  </motion.div>
);

const RiskCard = ({ icon: Icon, title, description }) => (
  <div className="bg-slate-950 border border-white/10 rounded-lg p-6 flex gap-4 hover:border-[#00D9FF]/30 transition-colors">
    <div className="mt-1 flex-shrink-0">
      <Icon className="w-5 h-5 text-[#00D9FF]" />
    </div>
    <div>
      <h4 className="text-white font-bold mb-1">{title}</h4>
      <p className="text-sm text-slate-400">{description}</p>
    </div>
  </div>
);

const IndiraCapabilities = () => {
  return (
    <section className="py-12 px-6 bg-slate-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* Section: Protection & Risk */}
        <div className="bg-slate-900/50 border border-white/10 rounded-2xl p-8 md:p-12 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00D9FF] to-transparent opacity-30" />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="mb-6">It Protects Your Business</h2>
              <p className="text-lg text-slate-300 mb-8">
                Predictive analytics don't just identify risks—they prevent them before they become CCMA cases or compliance fines.
              </p>
              <Link to="/pricing">
                <Button size="lg" className="w-full sm:w-auto">
                   Explore Enterprise Security
                </Button>
              </Link>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-4"
            >
              <RiskCard 
                icon={Scale}
                title="BCEA & LRA Compliance"
                description="Automatically updates employment contracts when labour laws change (e.g., National Minimum Wage)."
              />
              <RiskCard 
                icon={AlertTriangle}
                title="Employment Equity (EE) Alerts"
                description="Flags workforce demographics that drift from your B-BBEE targets or sector benchmarks."
              />
              <RiskCard 
                icon={FileCheck}
                title="POPIA Data Governance"
                description="Ensures all employee records and candidate data are stored and processed according to strict privacy laws."
              />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IndiraCapabilities;