import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useEmployer } from '@/context/EmployerContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { CheckCircle, ArrowRight, Upload, Users, Briefcase, Building, CreditCard, Settings, LayoutDashboard } from 'lucide-react';
import Navigation from '@/components/Navigation';

const steps = [
    { id: 1, title: 'Company Profile', icon: Building },
    { id: 2, title: 'Workforce Info', icon: Users },
    { id: 3, title: 'Connect Payroll', icon: CreditCard },
    { id: 4, title: 'Import Employees', icon: Upload },
    { id: 5, title: 'Enable Automations', icon: Settings },
];

const EmployerAccountSetup = () => {
    const [step, setStep] = useState(1);
    const { completeSetup, user } = useEmployer();
    const navigate = useNavigate();
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);

    const [data, setData] = useState({
        industry: '',
        location: '',
        hrContact: '',
        payrollSystem: '',
        automationLeaves: true,
        automationCompliance: true,
        automationPayroll: true,
        automationPerformance: true
    });

    const [payrollStatus, setPayrollStatus] = useState('idle'); // idle, connecting, connected

    const nextStep = () => {
        if (step < 5) setStep(step + 1);
        else handleFinish();
    };

    const handleConnectPayroll = () => {
        setPayrollStatus('connecting');
        setTimeout(() => {
            setPayrollStatus('connected');
            toast({ title: "Payroll Connected", description: "Successfully synced with system." });
        }, 1500);
    };

    const handleImport = () => {
        toast({ title: "Importing...", description: "Processing employee data." });
        setTimeout(() => {
            toast({ title: "Success", description: "12 Employees imported." });
            nextStep();
        }, 1500);
    };

    const handleFinish = async () => {
        setLoading(true);
        await new Promise(resolve => setTimeout(resolve, 1000));
        completeSetup(data);
        toast({ title: "Setup Complete", description: "Your dashboard is ready." });
        navigate('/employer-dashboard');
    };

    return (
        <div className="min-h-screen bg-slate-950 font-sans text-white flex flex-col">
            <Navigation />
            <div className="flex-grow pt-24 pb-12 px-6 flex flex-col items-center">
                <div className="max-w-4xl w-full">
                    {/* Progress */}
                    <div className="flex justify-between items-center mb-12 relative">
                        <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-900 -z-10" />
                        <div className="absolute top-1/2 left-0 h-1 bg-[#00D9FF] -z-10 transition-all duration-300" style={{ width: `${(step - 1) * 25}%` }} />
                        
                        {steps.map((s) => (
                            <div key={s.id} className="flex flex-col items-center gap-2 bg-slate-950 px-2 z-10">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 transition-all ${step >= s.id ? 'bg-[#00D9FF] border-[#00D9FF] text-slate-950' : 'bg-slate-900 border-white/10 text-slate-500'}`}>
                                    {step > s.id ? <CheckCircle className="w-6 h-6" /> : <s.icon className="w-5 h-5" />}
                                </div>
                                <span className={`text-xs font-medium ${step >= s.id ? 'text-white' : 'text-slate-500'}`}>{s.title}</span>
                            </div>
                        ))}
                    </div>

                    {/* Content */}
                    <div className="bg-slate-900 border border-white/10 rounded-2xl p-8 md:p-12 shadow-2xl min-h-[400px]">
                        <AnimatePresence mode="wait">
                            <motion.div
                                key={step}
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-6"
                            >
                                {step === 1 && (
                                    <>
                                        <h2 className="text-2xl font-bold mb-6">Company Profile</h2>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div>
                                                <label className="block text-sm text-slate-400 mb-1">Company Name</label>
                                                <input disabled value={user?.companyName || ''} className="w-full bg-slate-950 border border-white/10 rounded p-3 text-slate-500 cursor-not-allowed" />
                                            </div>
                                            <div>
                                                <label className="block text-sm text-slate-400 mb-1">Industry</label>
                                                <select className="w-full bg-slate-950 border border-white/10 rounded p-3" value={data.industry} onChange={e => setData({...data, industry: e.target.value})}>
                                                    <option>Technology</option>
                                                    <option>Finance</option>
                                                    <option>Retail</option>
                                                    <option>Manufacturing</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label className="block text-sm text-slate-400 mb-1">Head Office Location</label>
                                                <input className="w-full bg-slate-950 border border-white/10 rounded p-3" placeholder="e.g. Sandton, Johannesburg" value={data.location} onChange={e => setData({...data, location: e.target.value})} />
                                            </div>
                                            <div>
                                                <label className="block text-sm text-slate-400 mb-1">Primary HR Contact</label>
                                                <input className="w-full bg-slate-950 border border-white/10 rounded p-3" placeholder="Full Name" value={data.hrContact} onChange={e => setData({...data, hrContact: e.target.value})} />
                                            </div>
                                        </div>
                                    </>
                                )}

                                {step === 2 && (
                                    <>
                                        <h2 className="text-2xl font-bold mb-6">Workforce Information</h2>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div>
                                                <label className="block text-sm text-slate-400 mb-1">Current Payroll System</label>
                                                <select className="w-full bg-slate-950 border border-white/10 rounded p-3" value={data.payrollSystem} onChange={e => setData({...data, payrollSystem: e.target.value})}>
                                                    <option value="">Select System</option>
                                                    <option value="Sage">Sage VIP / Pastel</option>
                                                    <option value="SimplePay">SimplePay</option>
                                                    <option value="PaySpace">PaySpace</option>
                                                    <option value="Xero">Xero</option>
                                                    <option value="Custom">Custom / Other</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label className="block text-sm text-slate-400 mb-1">Number of Locations</label>
                                                <input type="number" className="w-full bg-slate-950 border border-white/10 rounded p-3" placeholder="1" />
                                            </div>
                                        </div>
                                    </>
                                )}

                                {step === 3 && (
                                    <>
                                        <h2 className="text-2xl font-bold mb-6">Connect Payroll</h2>
                                        <div className="bg-slate-950 border border-white/10 rounded-xl p-8 text-center">
                                            <CreditCard className="w-12 h-12 text-[#00D9FF] mx-auto mb-4" />
                                            <h3 className="text-xl font-bold mb-2">Sync with {data.payrollSystem || 'Payroll'}</h3>
                                            <p className="text-slate-400 mb-6">We'll automatically import employees and payslips.</p>
                                            
                                            {payrollStatus === 'connected' ? (
                                                <div className="text-emerald-500 font-bold flex items-center justify-center gap-2">
                                                    <CheckCircle /> Connected Successfully
                                                </div>
                                            ) : (
                                                <Button onClick={handleConnectPayroll} disabled={payrollStatus === 'connecting'} className="bg-[#00D9FF] text-slate-950">
                                                    {payrollStatus === 'connecting' ? 'Connecting...' : 'Connect Now'}
                                                </Button>
                                            )}
                                        </div>
                                    </>
                                )}

                                {step === 4 && (
                                    <>
                                        <h2 className="text-2xl font-bold mb-6">Import Employees</h2>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div className="bg-slate-950 border border-white/10 rounded-xl p-6 text-center hover:border-[#00D9FF] cursor-pointer" onClick={handleImport}>
                                                <Upload className="w-10 h-10 text-slate-400 mx-auto mb-4" />
                                                <h3 className="font-bold mb-2">Upload CSV</h3>
                                                <p className="text-xs text-slate-500">Drag & drop or click to upload</p>
                                            </div>
                                            <div className="bg-slate-950 border border-white/10 rounded-xl p-6 text-center hover:border-[#00D9FF] cursor-pointer" onClick={handleImport}>
                                                <Users className="w-10 h-10 text-slate-400 mx-auto mb-4" />
                                                <h3 className="font-bold mb-2">Use Sample Data</h3>
                                                <p className="text-xs text-slate-500">Load 5 demo employees</p>
                                            </div>
                                        </div>
                                    </>
                                )}

                                {step === 5 && (
                                    <>
                                        <h2 className="text-2xl font-bold mb-6">Enable Core Automations</h2>
                                        <div className="space-y-4">
                                            {['automationLeaves', 'automationCompliance', 'automationPayroll', 'automationPerformance'].map(key => (
                                                <label key={key} className="flex items-center justify-between p-4 bg-slate-950 border border-white/10 rounded-lg cursor-pointer">
                                                    <div>
                                                        <div className="font-bold text-white capitalize">{key.replace('automation', '')} Automation</div>
                                                        <div className="text-xs text-slate-400">Enable autonomous monitoring</div>
                                                    </div>
                                                    <input 
                                                        type="checkbox" 
                                                        checked={data[key]} 
                                                        onChange={e => setData({...data, [key]: e.target.checked})} 
                                                        className="w-5 h-5 accent-[#00D9FF]" 
                                                    />
                                                </label>
                                            ))}
                                        </div>
                                    </>
                                )}
                            </motion.div>
                        </AnimatePresence>

                        <div className="flex justify-between mt-12 pt-6 border-t border-white/10">
                            {step > 1 && (
                                <Button variant="ghost" onClick={() => setStep(step - 1)}>Back</Button>
                            )}
                            <div className="ml-auto flex gap-4">
                                {step < 5 && <Button variant="ghost" onClick={nextStep}>Skip</Button>}
                                <Button onClick={nextStep} className="bg-[#00D9FF] text-slate-950 px-8">
                                    {step === 5 ? (loading ? 'Finalizing...' : 'Go to Dashboard') : 'Next'} <ArrowRight className="w-4 h-4 ml-2" />
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EmployerAccountSetup;