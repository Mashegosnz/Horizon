import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { CheckCircle, ArrowRight, User, FileText, Video, LayoutDashboard, Briefcase, Star, ChevronDown, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

const CandidatesPage = () => {
  const scrollRef = useRef(null);

  const scrollToNext = () => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white">
      <Helmet>
        <title>Candidates | Indira Jobs</title>
        <meta name="description" content="Build your authentic profile and get matched with top employers." />
      </Helmet>

      <Navigation />

      {/* Section 1: Hero */}
      <section className="min-h-screen flex flex-col items-center justify-center text-center px-6 relative">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1542744173-8e7e53415bb0')] bg-cover bg-center opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-slate-950/80" />
        
        <div className="relative z-10 max-w-4xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            Build Your <span className="text-[#00D9FF]">Authentic Profile</span>
          </motion.h1>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Stop sending static CVs into the void. Create a living, verified profile that showcases your true potential to South Africa's top employers.
          </p>
          <Button size="lg" onClick={scrollToNext}>
            Start Your Profile
          </Button>
        </div>
        
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-slate-500">
          <ChevronDown className="w-8 h-8" />
        </div>
      </section>

      {/* Section 2: Value Prop */}
      <section ref={scrollRef} className="py-24 px-6 bg-slate-900/50">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-slate-950 p-8 rounded-2xl border border-white/5 hover:border-[#00D9FF]/50 transition-colors">
            <div className="w-12 h-12 bg-[#00D9FF]/10 rounded-lg flex items-center justify-center mb-6">
              <FileText className="w-6 h-6 text-[#00D9FF]" />
            </div>
            <h3>Beyond Resume</h3>
            <p className="mt-4">Static documents can't capture your drive. Express your full potential through dynamic profiling.</p>
          </div>
          <div className="bg-slate-950 p-8 rounded-2xl border border-white/5 hover:border-[#00D9FF]/50 transition-colors">
            <div className="w-12 h-12 bg-[#00D9FF]/10 rounded-lg flex items-center justify-center mb-6">
              <Award className="w-6 h-6 text-[#00D9FF]" />
            </div>
            <h3>Verified & Authentic</h3>
            <p className="mt-4">Stand out instantly. Our blockchain-backed verification for ID and qualifications builds trust.</p>
          </div>
          <div className="bg-slate-950 p-8 rounded-2xl border border-white/5 hover:border-[#00D9FF]/50 transition-colors">
            <div className="w-12 h-12 bg-[#00D9FF]/10 rounded-lg flex items-center justify-center mb-6">
              <Star className="w-6 h-6 text-[#00D9FF]" />
            </div>
            <h3>Intelligent Matching</h3>
            <p className="mt-4">Stop applying into the void. Our AI connects you with opportunities that match your goals.</p>
          </div>
        </div>
      </section>

      {/* Section 3: How It Works */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h2>Your Journey to Success</h2>
        </div>
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row justify-between items-center relative gap-8">
          <div className="absolute top-1/2 left-0 right-0 h-1 bg-slate-800 -z-10 hidden md:block" />
          {[
            { step: 1, label: 'Sign Up', icon: User },
            { step: 2, label: 'Smart CV', icon: FileText },
            { step: 3, label: 'Doc Hub', icon: Award },
            { step: 4, label: 'Video Studio', icon: Video },
            { step: 5, label: 'Dashboard', icon: LayoutDashboard },
            { step: 6, label: 'Job Matches', icon: Briefcase },
          ].map((s) => (
            <div key={s.step} className="flex flex-col items-center bg-slate-950 p-4 rounded-xl border border-white/10 z-10 w-full md:w-auto">
              <div className="w-10 h-10 rounded-full bg-[#00D9FF] text-slate-950 font-bold flex items-center justify-center mb-3">
                {s.step}
              </div>
              <span className="font-semibold text-sm">{s.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Section 4: Smart CV */}
      <section className="py-24 px-6 bg-slate-900/30">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-[#00D9FF] font-bold mb-2 uppercase tracking-wide">Step 1</div>
            <h2>Smart CV</h2>
            <p className="mb-8 text-lg">Our AI extracts your skills and experience to build a dynamic, living profile. Update it once, and it evolves with you.</p>
            <Button size="lg">Next Step <ArrowRight className="ml-2 w-4 h-4" /></Button>
          </div>
          <div className="bg-slate-950 p-6 rounded-xl border border-white/10 relative">
            <div className="absolute top-4 right-4 bg-slate-800 text-xs px-2 py-1 rounded text-slate-400">Coming Soon</div>
            <div className="space-y-4 opacity-50">
              <div className="h-4 bg-slate-800 rounded w-1/3" />
              <div className="h-10 bg-slate-800 rounded w-full" />
              <div className="h-10 bg-slate-800 rounded w-full" />
              <div className="h-32 bg-slate-800 rounded w-full" />
            </div>
          </div>
        </div>
      </section>

      {/* Section 5: Document Hub */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center md:flex-row-reverse">
          <div className="order-2 md:order-1 bg-slate-950 p-6 rounded-xl border border-white/10 relative">
             <div className="absolute top-4 right-4 bg-slate-800 text-xs px-2 py-1 rounded text-slate-400">Coming Soon</div>
             <div className="grid grid-cols-2 gap-4 opacity-50">
                <div className="h-24 bg-slate-800 rounded flex items-center justify-center"><FileText className="w-8 h-8 text-slate-600" /></div>
                <div className="h-24 bg-slate-800 rounded flex items-center justify-center"><Award className="w-8 h-8 text-slate-600" /></div>
             </div>
          </div>
          <div className="order-1 md:order-2">
            <div className="text-[#00D9FF] font-bold mb-2 uppercase tracking-wide">Step 2</div>
            <h2>Document Hub</h2>
            <p className="mb-8 text-lg">Securely upload your ID, degrees, and certificates. We verify them instantly, building immediate trust with employers.</p>
            <Button size="lg" variant="outline">Next Step <ArrowRight className="ml-2 w-4 h-4" /></Button>
          </div>
        </div>
      </section>

      {/* Section 6: Video Studio */}
      <section className="py-24 px-6 bg-slate-900/30">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-[#00D9FF] font-bold mb-2 uppercase tracking-wide">Step 3</div>
            <h2>Video Profile Studio</h2>
            <p className="mb-8 text-lg">Showcase your personality and communication skills. Record a short intro that stands out before the interview.</p>
            <Button size="lg">Next Step <ArrowRight className="ml-2 w-4 h-4" /></Button>
          </div>
          <div className="bg-black aspect-video rounded-xl border border-white/10 relative flex items-center justify-center">
            <div className="absolute top-4 right-4 bg-slate-800 text-xs px-2 py-1 rounded text-slate-400">Coming Soon</div>
            <Video className="w-16 h-16 text-slate-700" />
          </div>
        </div>
      </section>

      {/* Section 7: Dashboard */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
           <div className="text-[#00D9FF] font-bold mb-2 uppercase tracking-wide">Step 4</div>
           <h2>Profile Dashboard</h2>
           <p className="mb-12 text-lg">Track your visibility and see real-time job matches.</p>
           
           <div className="bg-slate-950 border border-white/10 rounded-xl p-8 relative overflow-hidden">
              <div className="absolute top-4 right-4 bg-slate-800 text-xs px-2 py-1 rounded text-slate-400">Coming Soon</div>
              <div className="flex items-center gap-4 mb-8">
                 <div className="w-16 h-16 rounded-full bg-slate-800" />
                 <div className="text-left">
                    <div className="h-4 bg-slate-800 w-32 mb-2 rounded" />
                    <div className="h-3 bg-slate-800 w-24 rounded" />
                 </div>
              </div>
              <div className="space-y-4">
                 {[1,2,3].map(i => (
                    <div key={i} className="bg-slate-900 p-4 rounded flex justify-between items-center opacity-60">
                       <div className="h-4 bg-slate-800 w-48 rounded" />
                       <div className="h-6 w-16 bg-[#00D9FF]/20 rounded" />
                    </div>
                 ))}
              </div>
           </div>
        </div>
      </section>

      {/* Section 8: Success Stories */}
      <section className="py-24 px-6 bg-slate-900/30">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="mb-12">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: "Thabo", role: "Dev", quote: "Got hired in 3 days!" },
              { name: "Sarah", role: "Manager", quote: "The video profile changed everything." },
              { name: "Priya", role: "Designer", quote: "Finally, jobs that actually match me." },
            ].map((s, i) => (
              <div key={i} className="bg-slate-950 p-6 rounded-xl border border-white/5">
                <p className="italic text-slate-400 mb-4">"{s.quote}"</p>
                <div className="font-bold text-white">{s.name}</div>
                <div className="text-sm text-[#00D9FF]">{s.role}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default CandidatesPage;