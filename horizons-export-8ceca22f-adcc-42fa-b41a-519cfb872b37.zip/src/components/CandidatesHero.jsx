import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const images = [
  "https://images.unsplash.com/photo-1684563983781-ce52a026f139", // Cape Town tech
  "https://images.unsplash.com/photo-1610891015188-5369212db097", // Johannesburg manufacturing
  "https://images.unsplash.com/photo-1580281657702-257584239a55", // Durban healthcare
  "https://images.unsplash.com/photo-1697869162556-ab57db502c09"  // Northern Cape renewable energy
];

const CandidatesHero = ({ onStartProfileClick }) => {
  const [currentImage, setCurrentImage] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % images.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative h-screen w-full overflow-hidden bg-slate-950 flex flex-col justify-center items-center">
      {/* Dynamic Background */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentImage}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5 }}
            className="absolute inset-0 w-full h-full"
          >
            <img
              src={images[currentImage]}
              alt="South African Workplace"
              className="w-full h-full object-cover"
            />
          </motion.div>
        </AnimatePresence>
        
        {/* Overlay with Glow */}
        <div className="absolute inset-0 bg-slate-950/80 z-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent z-10" />
      </div>

      {/* Content */}
      <div className="relative z-20 container mx-auto px-4 md:px-8 lg:px-16 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-5xl mx-auto"
        >
          <motion.div 
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-sm font-medium mb-8 backdrop-blur-md shadow-[0_0_15px_rgba(6,182,212,0.15)]"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <Sparkles className="w-4 h-4" />
            <span className="tracking-widest uppercase text-xs font-bold">The Future of Hiring</span>
          </motion.div>

          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-8 leading-tight tracking-tight text-white drop-shadow-2xl">
            Your Career, <span className="text-cyan-400 drop-shadow-[0_0_30px_rgba(6,182,212,0.6)]">Fully Expressed.</span>
            <br />
            Your Potential, <span className="text-white">Fully Seen.</span>
          </h1>

          <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-3xl mx-auto font-normal leading-relaxed">
            Move beyond the resume. Connect with South Africa's top employers through intelligent matching and verified profiles.
          </p>

          <motion.div 
            className="flex justify-center items-center w-full"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              size="lg"
              onClick={onStartProfileClick}
              className="min-w-[200px] md:min-w-[240px] bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-6 px-8 md:py-8 md:px-10 text-lg md:text-xl rounded-lg shadow-lg shadow-cyan-500/50 hover:shadow-cyan-500/70 transition-all duration-300"
            >
              Start Your Profile
            </Button>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-20 cursor-pointer"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        transition={{ duration: 2, delay: 1, repeat: Infinity, ease: 'easeInOut' }}
        onClick={onStartProfileClick}
      >
        <ChevronDown className="h-8 w-8 text-cyan-400 animate-pulse drop-shadow-[0_0_10px_rgba(6,182,212,0.5)]" />
      </motion.div>
    </section>
  );
};

export default CandidatesHero;