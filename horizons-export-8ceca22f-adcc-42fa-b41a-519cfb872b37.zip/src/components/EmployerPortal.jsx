import React, { useRef } from 'react';
import { Helmet } from 'react-helmet';
import { 
  Plus, Search, BarChart3, MapPin, Users,
  CheckCircle, Filter, ArrowRight 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import Badge from '@/components/ui/Badge';
import Card from '@/components/ui/Card';
import MetricCard from '@/components/ui/MetricCard';

const CandidateRow = ({ name, role, skills, match }) => (
  <div className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-slate-950/50 border border-white/5 rounded-lg mb-3 hover:border-cyan-500/30 transition-colors">
    <div className="flex items-center gap-4 mb-3 md:mb-0">
      <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 font-bold">
        {name.charAt(0)}
      </div>
      <div>
        <h4 className="text-white font-bold text-sm">{name}</h4>
        <p className="text-slate-400 text-xs">{role}</p>
      </div>
    </div>
    <div className="flex flex-wrap gap-2 mb-3 md:mb-0">
      {skills.map(s => <span key={s} className="text-[10px] bg-slate-900 px-2 py-1 rounded text-slate-400">{s}</span>)}
    </div>
    <div className="flex items-center gap-4">
       <div className="text-right">
          <span className="block text-emerald-400 font-bold text-sm">{match}%</span>
          <span className="text-[10px] text-slate-500">Match Score</span>
       </div>
       <Button size="sm" variant="outline" className="h-8 text-xs border-cyan-500/30 text-cyan-400">View</Button>
    </div>
  </div>
);

const EmployerPortal = () => {
  const jobRef = useRef(null);
  const discoveryRef = useRef(null);
  const analyticsRef = useRef(null);

  const scrollTo = (ref) => ref.current?.scrollIntoView({ behavior: 'smooth' });

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-300">
      <Helmet>
        <title>Employer Portal | Indira AI</title>
        <meta name="description" content="Autonomous HR intelligence for modern businesses. Post jobs, discover verified talent, and analyze hiring metrics." />
      </Helmet>
      
      <Navigation />

      <main className="pt-20">
        {/* Dashboard Header */}
        <section className="bg-slate-900 border-b border-white/5 py-12 px-6">
           <div className="container mx-auto">
              <h1 className="text-4xl font-bold text-white mb-4">Employer Dashboard</h1>
              <p className="text-slate-400 max-w-2xl">Manage your recruitment pipeline with AI-driven insights. Streamline job creation, candidate discovery, and analytics in one unified platform.</p>
              
              <div className="flex flex-wrap gap-4 mt-8">
                 <Button onClick={() => scrollTo(jobRef)} className="bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400">
                    <Plus className="mr-2 w-4 h-4" /> Post a Job
                 </Button>
                 <Button onClick={() => scrollTo(discoveryRef)} variant="outline" className="border-white/10 text-white hover:bg-white/5">
                    <Search className="mr-2 w-4 h-4" /> Find Candidates
                 </Button>
                 <Button onClick={() => scrollTo(analyticsRef)} variant="outline" className="border-white/10 text-white hover:bg-white/5">
                    <BarChart3 className="mr-2 w-4 h-4" /> Analytics
                 </Button>
              </div>
           </div>
        </section>

        <div className="container mx-auto px-6 py-12 space-y-24">
           
           {/* Section 1: Job Creation */}
           <section ref={jobRef} className="scroll-mt-24">
              <div className="flex flex-col lg:flex-row gap-12">
                 <div className="lg:w-1/3">
                    <h2 className="text-3xl font-bold text-white mb-4">Smart Job Creation</h2>
                    <p className="text-slate-400 mb-6">Create comprehensive job specifications in seconds. Our AI suggests requirements, skills, and market-related salary ranges based on your needs.</p>
                    <ul className="space-y-3 mb-8">
                       {['AI-assisted descriptions', 'Market salary insights', 'One-click posting'].map(item => (
                          <li key={item} className="flex items-center gap-2 text-sm text-cyan-400">
                             <CheckCircle className="w-4 h-4" /> {item}
                          </li>
                       ))}
                    </ul>
                 </div>
                 <div className="lg:w-2/3">
                    <Card className="bg-slate-900/50 border-white/10">
                       <div className="flex justify-between items-center mb-6">
                          <h3 className="font-bold text-white">New Job Post</h3>
                          <Badge variant="cyan">Coming Soon</Badge>
                       </div>
                       <div className="space-y-4">
                          <div className="space-y-2">
                             <label className="text-xs uppercase text-slate-500 font-bold">Job Title</label>
                             <div className="h-10 bg-slate-950 border border-white/10 rounded px-3 flex items-center text-slate-400 text-sm">Senior React Developer</div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                             <div className="space-y-2">
                                <label className="text-xs uppercase text-slate-500 font-bold">Location</label>
                                <div className="h-10 bg-slate-950 border border-white/10 rounded px-3 flex items-center text-slate-400 text-sm"><MapPin className="w-4 h-4 mr-2" /> Johannesburg</div>
                             </div>
                             <div className="space-y-2">
                                <label className="text-xs uppercase text-slate-500 font-bold">Type</label>
                                <div className="h-10 bg-slate-950 border border-white/10 rounded px-3 flex items-center text-slate-400 text-sm">Full-time</div>
                             </div>
                          </div>
                          <div className="pt-4">
                             <Button className="w-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/50 hover:bg-cyan-500/30">
                                Post Job (Preview)
                             </Button>
                          </div>
                       </div>
                    </Card>
                 </div>
              </div>
           </section>

           {/* Section 2: Candidate Discovery */}
           <section ref={discoveryRef} className="scroll-mt-24">
              <div className="flex justify-between items-end mb-8">
                 <div>
                    <h2 className="text-3xl font-bold text-white mb-2">Candidate Discovery</h2>
                    <p className="text-slate-400">AI-matched candidates verified and ready to interview.</p>
                 </div>
                 <Badge variant="cyan" className="mb-2">Coming Soon</Badge>
              </div>

              <Card className="bg-slate-900 border-white/10">
                 {/* Filters Mockup */}
                 <div className="flex gap-4 mb-6 pb-6 border-b border-white/5 overflow-x-auto">
                    <Button variant="outline" size="sm" className="border-cyan-500/30 text-cyan-400 bg-cyan-500/5">
                       <Filter className="w-3 h-3 mr-2" /> All Filters
                    </Button>
                    {['Skills: React', 'Location: SA', 'Exp: 5+ Years'].map(f => (
                       <div key={f} className="px-3 py-1.5 rounded-full bg-slate-800 text-xs text-slate-300 border border-white/5 whitespace-nowrap">
                          {f}
                       </div>
                    ))}
                 </div>

                 {/* Candidate List */}
                 <div>
                    <CandidateRow name="Sarah Khumalo" role="Senior Frontend Dev" skills={['React', 'TypeScript', 'Tailwind']} match="98" />
                    <CandidateRow name="David Naidoo" role="Full Stack Engineer" skills={['Node.js', 'PostgreSQL', 'AWS']} match="94" />
                    <CandidateRow name="Jason Lee" role="UI/UX Designer" skills={['Figma', 'Prototyping']} match="89" />
                    <div className="mt-6 text-center">
                       <Button variant="ghost" className="text-cyan-400 hover:text-cyan-300">View All Matches <ArrowRight className="w-4 h-4 ml-2" /></Button>
                    </div>
                 </div>
              </Card>
           </section>

           {/* Section 3: Analytics */}
           <section ref={analyticsRef} className="scroll-mt-24 pb-24">
              <h2 className="text-3xl font-bold text-white mb-8">Hiring Analytics</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                 <MetricCard title="Active Roles" value="12" icon={Briefcase} trend="+2" trendUp={true} />
                 <MetricCard title="Total Candidates" value="348" icon={Users} trend="+15%" trendUp={true} />
                 <MetricCard title="Time to Hire" value="14 Days" icon={BarChart3} trend="-3 Days" trendUp={true} />
                 <MetricCard title="Offer Acceptance" value="94%" icon={CheckCircle} trend="+2%" trendUp={true} />
              </div>

              <Card className="h-80 bg-slate-900 border-white/10 flex items-center justify-center relative overflow-hidden group">
                 <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent z-10" />
                 {/* Fake Chart Bars */}
                 <div className="absolute bottom-0 left-0 right-0 h-full flex items-end justify-around px-8 pb-8 gap-4 opacity-20">
                    {[40, 65, 45, 80, 55, 90, 70, 85, 60, 95, 75, 50].map((h, i) => (
                       <div key={i} style={{ height: `${h}%` }} className="w-full bg-cyan-500 rounded-t-sm" />
                    ))}
                 </div>
                 <div className="relative z-20 text-center">
                    <BarChart3 className="w-12 h-12 text-cyan-500/50 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-white">Deep Insights Dashboard</h3>
                    <p className="text-slate-400 text-sm mb-4">Visualize your pipeline performance</p>
                    <Badge variant="cyan">Coming Soon</Badge>
                 </div>
              </Card>
           </section>

        </div>

        <Footer />
      </main>
    </div>
  );
};

// Helper Icon for metric card
const Briefcase = (props) => (
  <svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <rect width="20" height="14" x="2" y="7" rx="2" ry="2" />
    <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
  </svg>
)

export default EmployerPortal;