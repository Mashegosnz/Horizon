import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useEmployer } from '@/context/EmployerContext';
import { Link } from 'react-router-dom';
import { Briefcase, ArrowRight } from 'lucide-react';
import Navigation from '@/components/Navigation';

const EmployerSignUp = () => {
  const [searchParams] = useSearchParams();
  const planKey = searchParams.get('plan') || 'Starter';
  const billingPeriod = searchParams.get('billing') || 'monthly';
  
  const [formData, setFormData] = useState({
    companyName: '',
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    size: '1-10',
    plan: planKey,
    billingPeriod: billingPeriod
  });
  
  const { signup } = useEmployer();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    try {
      signup(formData);
      toast({
        title: "Account Created!",
        description: "Welcome to Indira. Your dashboard is ready.",
      });
      navigate('/employer-dashboard');
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col">
       <Navigation />
       
       <div className="flex-grow flex items-center justify-center p-6 pt-24">
          <motion.div 
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             className="w-full max-w-md"
          >
             <div className="bg-slate-900 border border-white/10 rounded-2xl p-8 shadow-2xl">
                 <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-white mb-2">Create Account</h2>
                    <p className="text-slate-400 text-sm">
                       Start your autonomous HR journey with the <span className="text-[#00D9FF] font-semibold">{planKey}</span> plan.
                    </p>
                 </div>

                 <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                           <label className="block text-xs font-medium text-slate-300 mb-1">First Name</label>
                           <input 
                              name="firstName"
                              required
                              className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white text-sm focus:border-[#00D9FF] outline-none transition-colors"
                              onChange={handleChange}
                           />
                        </div>
                        <div>
                           <label className="block text-xs font-medium text-slate-300 mb-1">Last Name</label>
                           <input 
                              name="lastName"
                              required
                              className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white text-sm focus:border-[#00D9FF] outline-none transition-colors"
                              onChange={handleChange}
                           />
                        </div>
                    </div>

                    <div>
                       <label className="block text-xs font-medium text-slate-300 mb-1">Company Name</label>
                       <input 
                          name="companyName"
                          required
                          className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white text-sm focus:border-[#00D9FF] outline-none transition-colors"
                          onChange={handleChange}
                       />
                    </div>

                    <div>
                       <label className="block text-xs font-medium text-slate-300 mb-1">Work Email</label>
                       <input 
                          name="email"
                          type="email"
                          required
                          className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white text-sm focus:border-[#00D9FF] outline-none transition-colors"
                          onChange={handleChange}
                       />
                    </div>

                    <div>
                       <label className="block text-xs font-medium text-slate-300 mb-1">Password</label>
                       <input 
                          name="password"
                          type="password"
                          required
                          className="w-full bg-slate-950 border border-white/10 rounded-lg p-3 text-white text-sm focus:border-[#00D9FF] outline-none transition-colors"
                          onChange={handleChange}
                       />
                    </div>

                    <Button type="submit" className="w-full h-12 text-base font-semibold mt-6 shadow-[0_0_20px_rgba(0,217,255,0.3)]">
                       Complete Setup <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                 </form>

                 <div className="mt-6 text-center text-xs text-slate-500">
                    Already have an account? <Link to="/employer-login" className="text-[#00D9FF] hover:underline">Log in</Link>
                 </div>
             </div>
          </motion.div>
       </div>
    </div>
  );
};

export default EmployerSignUp;