import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useEmployer } from '@/context/EmployerContext';
import { useToast } from '@/components/ui/use-toast';
import { Mail, Lock } from 'lucide-react';
import Navigation from '@/components/Navigation';

const EmployerLogin = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const { login } = useEmployer();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      login(formData.email, formData.password);
      toast({ title: "Welcome Back!", description: "Accessing dashboard..." });
      navigate('/employer-dashboard');
    } catch (error) {
      toast({ title: "Login Failed", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col font-sans text-white">
      <Navigation />
      <main className="flex-grow flex items-center justify-center py-24 px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl p-8 shadow-xl"
        >
          <div className="text-center mb-8">
            <h2 className="mb-2">Employer Log In</h2>
            <p className="text-slate-400 text-sm">Access your Indira Jobs dashboard</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-300">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-500" />
                <input 
                  type="email" 
                  className="w-full bg-slate-950 border border-white/10 rounded-lg py-3 pl-10 pr-4 text-white focus:border-[#00D9FF] outline-none transition-colors"
                  placeholder="name@company.com"
                  required
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-300">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-500" />
                <input 
                  type="password" 
                  className="w-full bg-slate-950 border border-white/10 rounded-lg py-3 pl-10 pr-4 text-white focus:border-[#00D9FF] outline-none transition-colors"
                  placeholder="••••••••"
                  required
                  value={formData.password}
                  onChange={e => setFormData({...formData, password: e.target.value})}
                />
              </div>
            </div>
            
            <Button className="w-full mt-4" disabled={loading}>
              {loading ? "Logging in..." : "Log In"}
            </Button>
            
            <p className="text-xs text-center text-slate-500 mt-4">
              In the full product, this would use secure authentication.
            </p>
            
            <div className="text-center mt-6 pt-6 border-t border-white/10">
              <p className="text-slate-400 text-sm">Don't have an account? <Link to="/employer-signup" className="text-[#00D9FF] hover:underline">Sign Up</Link></p>
            </div>
          </form>
        </motion.div>
      </main>
    </div>
  );
};

export default EmployerLogin;