import React from 'react';
import { motion } from 'framer-motion';
import { UserCheck, FileText, Network, ShieldCheck, Sparkles, FileSearch } from 'lucide-react';

const Card = ({ icon: Icon, title, description, delay }) => (
  <motion.div
    className="group relative p-8 rounded-xl bg-slate-900 border border-cyan-500/20 hover:border-cyan-400/50 transition-all duration-500 shadow-lg hover:shadow-2xl hover:shadow-cyan-500/20 hover:-translate-y-2 overflow-hidden"
    initial={{ opacity: 0, y: 50 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6, delay }}
  >
    {/* Glow Background Effect */}
    <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
    
    <div className="relative z-10 flex flex-col h-full">
      <div className="w-16 h-16 rounded-xl bg-slate-950 border border-cyan-500/30 flex items-center justify-center mb-6 group-hover:border-cyan-400 group-hover:shadow-[0_0_15px_rgba(34,211,238,0.4)] transition-all duration-300">
        <Icon className="w-8 h-8 text-cyan-400" />
      </div>
      
      <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-cyan-400 transition-colors">{title}</h3>
      <p className="text-slate-400 leading-relaxed group-hover:text-slate-200 transition-colors">
        {description}
      </p>
    </div>
  </motion.div>
);

const CandidatesValueProposition = () => {
  return (
    <section id="value-proposition" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Grid Pattern Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#083344_1px,transparent_1px),linear-gradient(to_bottom,#083344_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20 pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-3xl md:text-5xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Why Choose <span className="text-cyan-400">Indira?</span>
          </motion.h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            We're reimagining the hiring process to put human potential first, powered by secure verification and intelligent AI.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card 
            icon={FileSearch}
            title="Beyond the Resume"
            description="Static documents can't capture your drive. Express your full potential through dynamic profiling that highlights your personality, soft skills, and unique strengths."
            delay={0.1}
          />
          <Card 
            icon={ShieldCheck}
            title="Verified & Authentic"
            description="Stand out in a crowded market. Our blockchain-backed verification for ID and qualifications builds instant trust with employers, fast-tracking your application."
            delay={0.3}
          />
          <Card 
            icon={Network}
            title="Intelligent Matching"
            description="Stop applying into the void. Our AI connects you with opportunities that match not just your skills, but your career goals, culture fit, and salary expectations."
            delay={0.5}
          />
        </div>
      </div>
    </section>
  );
};

export default CandidatesValueProposition;