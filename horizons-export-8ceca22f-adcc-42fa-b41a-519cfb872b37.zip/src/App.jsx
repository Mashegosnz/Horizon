
import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { Helmet } from 'react-helmet';

// Providers
import { Toaster } from '@/components/ui/toaster';
import { EmployerProvider } from '@/context/EmployerContext';
import { EmployerDataProvider } from '@/context/EmployerDataContext';
import { CandidateProvider } from '@/context/CandidateContext';

// Core
import HomePage from '@/components/HomePage';
import ProtectedRoute from '@/components/ProtectedRoute';
import CandidateProtectedRoute from '@/components/CandidateProtectedRoute';

// Employers
import EmployerLandingPage from '@/components/EmployerLandingPage';
import EmployerLogin from '@/components/EmployerAuth/EmployerLogin';
import IndiraCapabilitiesPage from '@/components/IndiraCapabilitiesPage';
import EmployersPricingPage from '@/components/EmployersOnboarding/EmployersPricingPage';
import EmployersCheckoutPage from '@/components/EmployersOnboarding/EmployersCheckoutPage';
import EmployersSignupPage from '@/components/EmployersOnboarding/EmployersSignupPage';
import EmployersProfileSetupWizard from '@/components/EmployersOnboarding/EmployersProfileSetupWizard';
import EmployersDashboard from '@/components/EmployersDashboard/EmployersDashboard';
import JobRequisitions from '@/components/EmployersDashboard/JobRequisitions';
import EmployerCandidatePipeline from '@/components/EmployersDashboard/CandidatePipeline';
import InterviewScheduler from '@/components/EmployersDashboard/InterviewScheduler';
import OfferLetters from '@/components/EmployersDashboard/OfferLetters';
import OnboardingChecklist from '@/components/EmployersDashboard/OnboardingChecklist';
import DocumentsVault from '@/components/EmployersDashboard/DocumentsVault';
import Notifications from '@/components/EmployersDashboard/Notifications';
import PerformanceManagement from '@/components/EmployersDashboard/PerformanceManagement';
import LearningRecommendations from '@/components/EmployersDashboard/LearningRecommendations';
import BbbeeDashboard from '@/components/EmployersDashboard/BbbeeDashboard';
import SuccessionPlanning from '@/components/EmployersDashboard/SuccessionPlanning';
import RiskDashboard from '@/components/EmployersDashboard/RiskDashboard';
import ExecutiveAnalytics from '@/components/EmployersDashboard/ExecutiveAnalytics';

// Candidates Public
import CandidateLandingPage from '@/components/CandidatePlatform/CandidateLandingPage';
import CandidateSignup from '@/components/CandidatePlatform/Auth/CandidateSignup';
import CandidateLogin from '@/components/CandidatePlatform/Auth/CandidateLogin';
import { CandidateForgotPassword, CandidateResetPassword } from '@/components/CandidatePlatform/Auth/CandidateAuthExtras';
import CandidateProfileSetupWizard from '@/components/CandidatePlatform/CandidateProfileSetupWizard';

// Candidates Protected
import CandidateDashboard from '@/components/CandidatePlatform/Dashboard/CandidateDashboard';
import CandidatePortalJobBoard from '@/components/CandidatePlatform/Portal/CandidatePortalJobBoard';
import CandidateJobDetail from '@/components/CandidatePlatform/Portal/CandidateJobDetail';
import CandidateApplicationForm from '@/components/CandidatePlatform/Portal/CandidateApplicationForm';
import { CandidateApplications, CandidateSavedJobs, CandidateMessages, CandidateInterviews, CandidateDocuments, CandidateAssessments, CandidateNotifications, CandidateProfileEdit } from '@/components/CandidatePlatform/Dashboard/DashboardSubpages';
import { CandidateCVBuilder, CandidateInterviewPrep, CandidateCoaching, CandidateSkillsAssessments } from '@/components/CandidatePlatform/Portal/PortalTools';

const AppContent = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        {/* Core Route */}
        <Route path="/" element={<HomePage />} />
        
        {/* Employer Routes */}
        <Route path="/employers" element={<EmployerLandingPage />} />
        <Route path="/employers/login" element={<EmployerLogin />} />
        <Route path="/employers/capabilities" element={<IndiraCapabilitiesPage />} />
        <Route path="/employers/pricing" element={<EmployersPricingPage />} />
        <Route path="/employers/checkout" element={<EmployersCheckoutPage />} />
        <Route path="/employers/signup" element={<EmployersSignupPage />} />
        <Route path="/employers/profile-setup" element={<EmployersProfileSetupWizard />} />
        <Route path="/pricing" element={<EmployersPricingPage />} />

        {/* Protected Employer Routes */}
        <Route path="/employers/dashboard" element={<ProtectedRoute><EmployersDashboard /></ProtectedRoute>} />
        <Route path="/employers/dashboard/requisitions" element={<ProtectedRoute><JobRequisitions /></ProtectedRoute>} />
        <Route path="/employers/dashboard/candidates" element={<ProtectedRoute><EmployerCandidatePipeline /></ProtectedRoute>} />
        <Route path="/employers/dashboard/interviews" element={<ProtectedRoute><InterviewScheduler /></ProtectedRoute>} />
        <Route path="/employers/dashboard/offers" element={<ProtectedRoute><OfferLetters /></ProtectedRoute>} />
        <Route path="/employers/dashboard/onboarding" element={<ProtectedRoute><OnboardingChecklist /></ProtectedRoute>} />
        <Route path="/employers/dashboard/documents" element={<ProtectedRoute><DocumentsVault /></ProtectedRoute>} />
        <Route path="/employers/dashboard/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
        <Route path="/employers/dashboard/performance" element={<ProtectedRoute><PerformanceManagement /></ProtectedRoute>} />
        <Route path="/employers/dashboard/learning" element={<ProtectedRoute><LearningRecommendations /></ProtectedRoute>} />
        <Route path="/employers/dashboard/bbbee" element={<ProtectedRoute><BbbeeDashboard /></ProtectedRoute>} />
        <Route path="/employers/dashboard/succession" element={<ProtectedRoute><SuccessionPlanning /></ProtectedRoute>} />
        <Route path="/employers/dashboard/risk" element={<ProtectedRoute><RiskDashboard /></ProtectedRoute>} />
        <Route path="/employers/dashboard/analytics" element={<ProtectedRoute><ExecutiveAnalytics /></ProtectedRoute>} />

        {/* Candidate Public Routes */}
        <Route path="/candidates" element={<CandidateLandingPage />} />
        <Route path="/candidates/signup" element={<CandidateSignup />} />
        <Route path="/candidates/login" element={<CandidateLogin />} />
        <Route path="/candidates/forgot-password" element={<CandidateForgotPassword />} />
        <Route path="/candidates/reset-password" element={<CandidateResetPassword />} />

        {/* Candidate Protected Setup */}
        <Route path="/candidates/profile-setup" element={<CandidateProtectedRoute><CandidateProfileSetupWizard /></CandidateProtectedRoute>} />

        {/* Candidate Protected Dashboard */}
        <Route path="/candidates/dashboard" element={<CandidateProtectedRoute><CandidateDashboard /></CandidateProtectedRoute>} />
        <Route path="/candidates/dashboard/profile" element={<CandidateProtectedRoute><CandidateProfileEdit /></CandidateProtectedRoute>} />
        <Route path="/candidates/dashboard/applications" element={<CandidateProtectedRoute><CandidateApplications /></CandidateProtectedRoute>} />
        <Route path="/candidates/dashboard/saved-jobs" element={<CandidateProtectedRoute><CandidateSavedJobs /></CandidateProtectedRoute>} />
        <Route path="/candidates/dashboard/messages" element={<CandidateProtectedRoute><CandidateMessages /></CandidateProtectedRoute>} />
        <Route path="/candidates/dashboard/interviews" element={<CandidateProtectedRoute><CandidateInterviews /></CandidateProtectedRoute>} />
        <Route path="/candidates/dashboard/documents" element={<CandidateProtectedRoute><CandidateDocuments /></CandidateProtectedRoute>} />
        <Route path="/candidates/dashboard/assessments" element={<CandidateProtectedRoute><CandidateAssessments /></CandidateProtectedRoute>} />
        <Route path="/candidates/dashboard/notifications" element={<CandidateProtectedRoute><CandidateNotifications /></CandidateProtectedRoute>} />

        {/* Candidate Protected Portal Tools */}
        <Route path="/candidates/portal/jobs" element={<CandidateProtectedRoute><CandidatePortalJobBoard /></CandidateProtectedRoute>} />
        <Route path="/candidates/portal/jobs/:jobId" element={<CandidateProtectedRoute><CandidateJobDetail /></CandidateProtectedRoute>} />
        <Route path="/candidates/portal/jobs/:jobId/apply" element={<CandidateProtectedRoute><CandidateApplicationForm /></CandidateProtectedRoute>} />
        <Route path="/candidates/portal/cv-builder" element={<CandidateProtectedRoute><CandidateCVBuilder /></CandidateProtectedRoute>} />
        <Route path="/candidates/portal/interview-prep" element={<CandidateProtectedRoute><CandidateInterviewPrep /></CandidateProtectedRoute>} />
        <Route path="/candidates/portal/documents" element={<CandidateProtectedRoute><CandidateDocuments /></CandidateProtectedRoute>} />
        <Route path="/candidates/portal/coaching" element={<CandidateProtectedRoute><CandidateCoaching /></CandidateProtectedRoute>} />
        <Route path="/candidates/portal/assessments" element={<CandidateProtectedRoute><CandidateSkillsAssessments /></CandidateProtectedRoute>} />

      </Routes>
    </AnimatePresence>
  );
};

function App() {
  return (
    <Router>
      <EmployerProvider>
        <EmployerDataProvider>
          <CandidateProvider>
              <Helmet>
                 <title>Indira Jobs - Autonomous HR</title>
              </Helmet>
              <div className="bg-slate-950 text-white min-h-screen font-sans">
                 <AppContent />
                 <Toaster />
              </div>
          </CandidateProvider>
        </EmployerDataProvider>
      </EmployerProvider>
    </Router>
  );
}

export default App;
